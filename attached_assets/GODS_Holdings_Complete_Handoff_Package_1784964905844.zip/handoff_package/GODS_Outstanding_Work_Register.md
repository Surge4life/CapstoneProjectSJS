# G.O.D.S. Holdings — Outstanding Work Register
**Version:** July 2026 | **Status:** Pending SJS authorization on each item
**Purpose:** Complete record of work identified, started, or needed — all requiring SJS decision or action before Claude can proceed. Nothing here starts until SJS says go.

---

## CRITICAL PRIORITY — Fix Before Any External Contact

### OW-001: Live Site UDOC Copy Fix
**What:** Replace "Architecture designed. No code written. No clients engaged. Build commences at seed capital close." (appears 3x on site) with confirmed live-build language
**Exact replacement text:**
> "Capstone build live: 72 backend routes deployed and tested (gods-platform-core.onrender.com / Neon Postgres). Android build compiled and installed on device. Governance gate, EVA engine, and audit-chain issuing in production. Full commercial platform and enterprise multi-plane architecture build commences at seed capital close."
**Who acts:** SJS (edits index.html directly — text embedded in JS, cannot be simple paste)
**Urgency:** Before press pitch, before DFI outreach, before competition application
**Blocker:** Live site and investor documents now contradict — §5 of the competitive assessment resolved this, but the site itself still has the old text

### OW-002: Remove Nova X Quantum™ from Competitor Table
**What:** Delete the Nova X Quantum™ row from the UDOC competitor comparison table on the live site
**Why:** Research confirmed significant overclaim red flags in their own materials. Retaining this comparison costs G.O.D.S. credibility rather than adding it.
**Who acts:** SJS (edit index.html — find the competitor table section)
**Urgency:** Before any investor or journalist sees the site

### OW-003: Unemployment Statistics Standardisation
**What:** Align live site unemployment figures with Stats SA Q1 2026 primary source
- Change 32.9% → 32.7% (official national)
- Change 62.4% → 60.9% (official youth 15–24)
**Note:** The site may be using the expanded rate (LU3) which is 43.7%, or a different publication timing. Either is acceptable — the key is that all materials use ONE primary figure consistently labelled.
**Who acts:** SJS (2 number changes in index.html)

### OW-004: Document Count Clarification
**What:** Add a one-line note explaining 73 vs 103 (both appear on the same page unexplained)
- 73 = formally registered documents in the master data room index
- 103 = total institutional documents including all versions and supporting files
**Who acts:** SJS (add one explanatory sentence near the document count display)

---

## HIGH PRIORITY — Document Corrections

### OW-005: C-08 TAM Rewrite
**What:** The March 2026 C-08 Market Analysis document states UDOC's global TAM as USD 43B by 2030. The June 2026 competitive assessment (multi-sourced) puts the same market at ~$2.6–5.9B by 2030–2035. A 7–15x gap between two G.O.D.S. own documents will not survive investor diligence.
**Who acts:** Claude (once SJS authorises — rewrite C-08 UDOC TAM section using the sourced June 2026 figures)
**Authorization needed:** SJS to confirm he wants C-08 updated to reflect the competitive report's sourced figure

### OW-006: Original "G.O.D.S vs The World" SAQA Correction
**What:** The original UDOC-only "G.O.D.S vs The World" report incorrectly states S.E.T.H.S. is "built on an accredited basis (SAQA 118707, NQF5)." SAQA 118707 NQF5 is SJS's personal Software Developer qualification (Terraco/Progression), not a S.E.T.H.S. accreditation. This document is superseded by the Complete Four-Division Assessment but may still be circulating.
**Who acts:** Claude (correct and produce updated version once SJS authorises)
**Authorization needed:** SJS to confirm this document is still in active use and needs correcting

---

## STANDARD PRIORITY — Technical Fixes

### OW-007: Pledge Counter Frontend Bug
**What:** The World Pledge form records submissions correctly (email notifications fire, backend logs them). However, the pledge count display on the site does not update when new pledges come in.
**Root cause hypothesis:** The count is either (a) hardcoded in index.html rather than fetched dynamically on page load, or (b) there is an API call to the backend pledge count endpoint that is failing silently (CORS issue, wrong endpoint URL, or missing error handler).
**What's needed to debug:** SJS to provide the exact section of index.html that renders the pledge count (search for where a number or counter displays near the World Pledge section). Claude will diagnose and provide exact fix.
**Authorization needed:** SJS to share the relevant code section

### OW-008: Live Site Navigation Enhancements
**What:** (From Q2 task list) Build a proper data room navigation interface, improved from the current static document list
**Scope:** TBD — Claude needs SJS to confirm what "better data room navigation" means in practice before designing
**Authorization needed:** SJS to define the specific navigation experience he wants

---

## STANDARD PRIORITY — New Documents / Frameworks

### OW-009: Founder Role Definition Document
**What:** SJS anticipates holding shares and the title "Executive Associate" not CEO if G.O.D.S. is funded. He has consciously separated "Founder/sole architect" (fully documented) from "qualified to run day-to-day multinational operations" (not claimed). He asked for a document defining what he WOULD lead post-registration — but never got it.
**Proposed scope:** Founder & Chief Systems Architect / Chairman of Constitutional Design / permanent non-operational design authority — with specific accountabilities, board-level authority, and separation from operational management
**Note:** This should be developed WITH SJS, not written for him — it's his role to define. Claude produces the framework once SJS articulates what he wants to own.
**Authorization needed:** Dedicated session when SJS is ready — not to be rushed

### OW-010: GBS-SETHS Additional Notes Incorporation
**What:** SJS attempted to share additional GBS-SETHS and G.O.D.S. notes multiple times. The attached documents (docs 63–68) came through empty every time due to a platform issue. The physical notebook photos provided were personal historical documents, not framework notes.
**What's needed:** SJS to paste the additional notes directly as body text (not as attached documents) in a new session. Claude will incorporate into a GBS-SETHS v2.1 update.
**Authorization needed:** SJS to re-send notes as body text

### OW-011: GBS Franchise Framework Definition
**What:** SJS requested a "GBS for franchisees" framework — a structured, adoptable/licensable version of G.O.D.S.-as-General-Belief-System. GBS-SETHS v2.0 contains the franchise model (5 layers, licensing economics, governance). But SJS may want a specific standalone franchisee-facing document.
**What's needed before starting:** SJS to confirm: is this (a) a geographic licensing document for a national operator, (b) an operator manual for running a local S.E.T.H.S. cohort, or (c) a methodology licensing document for an NGO/government body wanting to adopt the GBS approach?
**Authorization needed:** One clarifying answer, then Claude builds

### OW-012: Production Eco-System Build (Q2 priority)
**What:** Building production-grade code for G.O.D.S. eco-system integration into the live Render build. SJS mentioned this as "Question 2" in an early session — what to build next after the GBS framework.
**Options identified:**
- World Pledge form: backend integration (pledges already recording but count not displaying)
- Data room navigation interface: proper searchable/navigable document experience
- Mobile gateway updates: Android APK improvements for UDOC and G.O.D.S. platform access
- EVA/GIS engine: production-grade implementation of the G.O.D.S. Intelligence System
**Authorization needed:** SJS to confirm which piece comes first

---

## DEFERRED — Brand Decision Required

### OW-013: Brand Visual Register Decision
**What:** Three visual registers exist in the project and they disagree:
1. Brand Manual v1.0 (March 2026) — the only legally authoritative one; navy/gold, no effects, strictly clean
2. g-02_g_o_d_s_logo.jpeg — clean compass mark reference sheet; used in all Claude-built documents
3. Cosmic/gradient AI-generated concept boards — labeled "Pitch Archetype variations" by SJS himself; contradict the no-effects rule
**What's needed:** SJS to confirm which visual direction is correct for future collateral. If the Brand Manual wins, the concept boards stay exploratory/internal. If the cosmic register is preferred, the Brand Manual needs updating to allow effects.
**Authorization needed:** One word from SJS: "Manual" or "Cosmic" or "Hybrid + define the rules"

---

## DATA ROOM DISCREPANCIES — Need SJS Input

The GODS_DataRoom_Reference.md catalogs four discrepancies between SJS's own documents:
1. T.S. naming trail: "Transition Systems" (v1 data room) → unnamed (v2) → "Technological Sector" (SJS confirmed July 2026)
2. Patent count: 3 different figures across 3 different documents (4 core/19 embodiments; 5 portfolio filings; 24 claim families incl. zk-SOV)
3. T.S. sector count: B-08 legal template lists 5 SPV types vs E-06 blueprint and live site listing 7 subsidiaries
4. World Problems count: "10 global problems" (v1) vs "Eight structural crises" (v2)

None of these are individually fatal — together they are the largest credibility risk if a serious counterparty cross-references documents. Resolving them requires SJS's confirmation of the authoritative figure for each. Claude will then update all affected documents.

---

## SUMMARY COUNTS

| Priority | Count | Requires |
|---|---|---|
| Critical (fix before external contact) | 4 | SJS to edit site directly |
| High (document corrections) | 2 | Claude + SJS authorization |
| Standard technical | 2 | Claude + code from SJS |
| New documents/frameworks | 4 | Claude + SJS directional input |
| Brand/data room decisions | 5 | SJS decision only |
| **Total outstanding** | **17** | |
