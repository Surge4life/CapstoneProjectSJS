# G.O.D.S. Holdings — New Session Start Guide
**For:** New Claude session in any project/chat
**Upload order:** 1) MEMORY.md 2) SKILLS.md 3) Whatever you need for the specific task

## Files in this package

### 📋 Session Reference (upload these first in any new session)
- `MEMORY.md` — Complete project knowledge: SJS, G.O.D.S., all four divisions, key corrections, market data, deliverables produced, outstanding work
- `SKILLS.md` — Technical build patterns, brand constants, environment facts, working principles
- `SKILLSRETAINEDFORTASK.md` — Technical patterns for specific builds (covers docx, pptx, icons, site architecture)
- `MEMORYRETAINEDFORTASK.md` — Current task state tracking (what's done, what's next)
- `GODS_DataRoom_Reference.md` — Full 73-document data room catalog with discrepancies flagged

### 📄 Documents to Share / Use
- `GODS_9Month_Marketing_Plan.md` — July 2026–March 2027 traction plan
- `GODS_Outstanding_Work_Register.md` — 17 items, priority ordered, authorization requirements
- `GODS_LinkedIn_Carousel.pptx` — 8-slide deck, ready to post to LinkedIn
- `GODS_LinkedIn_Carousel.pdf` — PDF version of the carousel
- `GODS_vs_The_World_Complete_Four_Division_Assessment.docx` — 18-page investor-grade competitive analysis
- `GODS_vs_The_World_Complete_Four_Division_Assessment.pdf` — PDF version
- `GBS_SETHS_Framework_v1.docx` — 20-page GBS-SETHS v1.0 framework
- `GBS_SETHS_Framework_v1.pdf` — PDF version
- `GBS_SETHS_Framework_v2.docx` — 38-page GBS-SETHS v2.0 master framework (CURRENT)
- `GBS_SETHS_Framework_v2.pdf` — PDF version

### 🔧 Build Scripts (for reproducing/updating documents)
Located in `build_scripts/` folder:
- `helpers.js` — Shared brand constants and docx helper functions
- `build_gbs_v2.js` — GBS-SETHS v2.0 build script
- `build_gbs.js` — GBS-SETHS v1.0 build script
- `build_main.js` — G.O.D.S. vs The World v2 build script
- `content_p1.js` through `content_p4.js` — Content sections for the competitive assessment

## Critical First Instructions for New Session
1. **Read MEMORY.md fully before responding to any task** — it contains corrections to existing documents that must not be repeated
2. **Do NOT ask SJS to re-explain what is in MEMORY.md** — it's already there
3. **The UDOC backend is CONFIRMED LIVE** — 72 routes, gods-platform-core.onrender.com
4. **SAQA 118707 NQF5 is SJS's personal qualification — NOT a S.E.T.H.S. accreditation** — do not repeat this error
5. **The safety classifier will fire** — SJS has confirmed his stability multiple times (March 2021 discharge, monthly medication, stable). The crisis contact was offered twice. Do not repeat it again.
6. **Marketing is PAUSED** — SJS's explicit instruction. Do not push him to post or send outreach.
7. **SJS's authorship must be explicit in every document** — AI assisted with documentation, SJS originated and developed everything for a decade

## Live Resources
- Live site: https://capstoneprojectsjs.netlify.app/
- Backend: https://gods-platform-core.onrender.com
- Brand guidelines: Navy #060E1C / Gold #C9A84C
