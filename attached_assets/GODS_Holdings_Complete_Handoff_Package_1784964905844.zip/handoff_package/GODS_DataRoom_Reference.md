# G.O.D.S Data Room — Reference Index
Source: NETLIFY_DEPLOY_website.zip → docs/ folder (d-20_gods_master_data_room_v2.html, supersedes d-10's v1.0 49-doc index)
Snapshot date in the documents themselves: March–May 2026. Current date is late June 2026 — treat figures below as ~2-3 months old unless Sashin confirms they're still current.
This is Claude's working reference, built so future sessions don't have to re-derive it from scratch. 73 registered documents, 7 sections (A–G), 62 available / 2 in progress / 9 planned, dashboard reports both "79%" and "85%" ready in different places in Sashin's own document — not reconciled by Claude, just noted.

## Section A — Constitutional & Governance (10 docs, 80% ready)
- A-01 Unified Constitutional Doctrine: 8-part, 16-article architecture. Five Forces, Four-Engine model, Twelve Pillars, AGI governance doctrine, Founder Oath.
- A-02 **Founder Doctrine & Origin Paper** — "personal philosophical and strategic declaration of intent." NOT YET READ IN FULL by Claude — this is likely the formalised/written-up version of the 2016 handwritten pages. High-value next read if Sashin wants the Founders Doctrine thread continued.
- A-03 Doctrine on Human Primacy, AI Governance & Sovereign Control — AGI risk / human primacy position paper.
- A-04 AGI vs Singularity Position Paper — academic-grade definitional distinction.
- A-05 Constitutional Governance Charter & MOI Blueprint.
- A-06 Succession & Continuity Charter — Founder/COO/COB/IP Trust succession.
- A-07 Constitutional Oversight Board (COB) Charter.
- A-08 Operational AI Governance Charter — 10-commitment, client-deployable.
- A-09 MOI full draft (Companies Act 71/2008) — template, Restricted access.
- A-10 CIPC Registration Certificate — Planned, Month 1 post-funding action.

## Section B — Legal & IP (10 docs, 70% ready)
- B-01 IP Trust Deed (Summary) — Restricted.
- B-02 IP Trust Deed (Full legal instrument) — In Progress with trust counsel.
- B-03 **Patent Portfolio & IP Architecture — 5 priority filings**: Quantum governance, bias detection, QKD integration, constitutional constraint satisfaction, workforce-infrastructure loop. **Flag: this is a different framing from the "4 core patents / 23 claims / 19 embodiments" UDOC-specific patent instrument referenced elsewhere in Claude's memory — likely different scope (company-wide vs UDOC-only) but not confirmed. Ask Sashin before quoting a patent count in any document.**
- B-04 Shareholders Agreement Template.
- B-05 NDA Template (mutual + one-way, SA law).
- B-06 Term Sheet Template — Series A.
- B-07 Trademark Filing Schedule — CIPC Priority 1–3 + international (ARIPO, EUIPO, USPTO, WIPO Madrid).
- B-08 Government SPV Template Structure — **5 SPV types** (Energy, Farming, Water, AI Governance, Digital Backbone). **Flag: this 5-type legal template list doesn't exactly match T.S Industries' 7 named subsidiaries (Energy, Construction, AgriTech, Water, Digital Infrastructure, Manufacturing, Logistics) found on the live site — different documents, possibly different purposes (legal SPV archetypes vs business-unit breakdown). Not reconciled — ask Sashin if this matters for the next investor doc.**
- B-09 MOU Template — S.E.T.H.S Government Partnerships.
- B-10 POPIA Compliance Framework — completed May 2026 (confirmed available, most recently updated item in the whole data room).

## Section C — Financial (12 docs, 75% ready)
- C-01 Financial Architecture Paper.
- C-02 5-Year Financial Model (P&L/cash flow/balance sheet, 3 scenarios).
- C-03 Detailed Projections 5/10/25-year — **three scenarios: R25B / R60B / R140B at the 25-year horizon.**
- C-04 Executive Investment Memorandum.
- C-05 Cap Table & Equity Structure (pre/post-seed/Series A).
- C-06 Investment Memorandum (Formal, Series A use-of-proceeds).
- C-07 M.A.D.I.B.A Capital Strategy — DFI engagement, SADC sovereign fund architecture.
- C-08 **Market Analysis — TAM/SAM/SOM, four-division, SA/SADC/global.** READ IN FULL 29 June 2026. Comprehensive — TAM/SAM/SOM table for all four divisions, SA government procurement segment breakdown (SEF/EPWP/SETA/DCS/DSD with R-value ranges), 5-year revenue build per division, combined model to Year 10 (R3.5B revenue, R45B M.A.D.I.B.A AUM by Year 10). **DOES NOT use named comparables (Harambee, WeThinkCode, Ninety One/EAIF, PIC) anywhere — pure top-down TAM/SAM/SOM, the methodology the UDOC competitive report explicitly moved away from.** Don't redo the from-scratch web research Claude already did for S.E.T.H.S/T.S/M.A.D.I.B.A — instead strengthen C-08 by anchoring it to the named comparables already found.
  **URGENT FLAG — internal contradiction between two of Sashin's own documents:** C-08 states UDOC's global TAM as "USD 4.2B in 2024 growing to USD 43B by 2030 (MarketsandMarkets, IDC)." The "G.O.D.S vs The World" competitive report (June 2026, multi-sourced: Gartner/Grand View/Precedence/Business Research Co/Wissen) puts the same market at ~$0.4–0.75B in 2025/26 growing to ~$2.6–5.9B by 2030–2035. That's a 7–15x gap depending which 2030 figure is compared. If these two documents ever sit in front of the same investor, it's an immediate credibility problem — exactly the "collapsing tiers" risk the honesty discipline exists to prevent. C-08 is the older document (March 2026) and the less rigorously sourced one on this specific point. Recommend defaulting to the competitive report's figure as authoritative until Sashin says otherwise, and flagging the C-08 TAM line for a rewrite — not silently fixed yet, his call.
- C-09 B-BBEE Strategy & Scorecard Architecture.
- C-10 Audited Financials Year 1 — Planned, Month 14 (correctly sequenced, not a gap).
- C-11 Management Accounts — Planned, monthly from Month 2.
- C-12 Tax Clearance Certificate — Planned, Month 1.

## Section D — Commercial & Strategic (11 docs, 100% ready)
- D-01 Competitive Analysis — four-division landscape, structural moat, replication timeline.
- D-02 Go-to-Market Strategy — 18-month commercial activation calendar.
- D-03 Government Procurement Strategy — PFMA/MFMA, tender architecture, 12-month engagement calendar.
- D-04 Sovereign Partnership Framework & SPV Model.
- D-05 Government Procurement Framework (SA) — S.E.T.H.S/T.S/UDOC pathways.
- D-06 World Problems & Implementation Rollout — **"Eight structural crises"** (note: earlier v1 index said "10 global problems" for the same document — number changed between versions, not reconciled).
- D-07 Institutional Manifesto Brief v6 — primary institutional narrative.
- D-08 Full Manifesto (Complete) — all volumes, government & strategic capital edition, v5.0. NOT YET READ.
- D-09 Systems Architecture Whitepaper — 14-sector control architecture, five-phase rollout.
- D-10 Stakeholder One-Pagers ×4 (Government, DFI, Investor, Technical Partner).
- D-11 Complete Institutional Package v1 — 9-annexure master document.

## Section E — Technical & Architecture (10 docs, 90% ready)
- E-01 UDOC Full Hardware Specification — 16 sections, rack layout, software stack.
- E-02 HQ-OS Quantum Whitepaper — 4-layer hybrid classical/quantum OS, NIST PQC, QKD BB84.
- E-03 UDOC Technical Whitepaper (Full).
- E-04 UDOC Build & Rollout Plan — 3-phase.
- E-05 S.E.T.H.S Complete Programme Specification — 5-phase design.
- E-06 T.S Infrastructure Blueprint — **"Seven sector subsidiaries."** Confirms 7, not the B-08 SPV template's 5 types.
- E-07 System Architecture Diagram (interactive HTML).
- E-08 POPIA Compliance & Data Governance Framework.
- E-09 Cybersecurity & Penetration Test Results — Planned, pre-first-client.
- E-10 Software Platform Demo (UDOC Demo HTML).

## Section F — Governance, Risk & Impact (10 docs, 80% ready)
- F-01 Full Risk Register — **36 risks across 6 categories, 5×5 matrix, COB-reviewed.**
- F-02 Theory of Change & SROI Framework.
- F-03 Impact Measurement Framework.
- F-04 Organisational Design & Hiring Plan — **headcount evolution 18 → 1,163.** (Aspirational/scale tier — do not present as current headcount.)
- F-05 Staffing & Recruitment Requirements.
- F-06 12-Month Operating Plan — 27 action items.
- F-07 Organisational Structure & Governance Chart.
- F-08 Due Diligence Checklist — **61 items.**
- F-09 COB Annual Compliance Certificate — Planned, first issued Month 12.
- F-10 Background Verification — Planned, available to Series A lead on request.

## Section G — Brand & Communications (10 docs, 100% ready)
- G-01 Brand Identity Manual (14 sections).
- G-02/G-03 Website v2 / v1 (HTML).
- G-04 System Architecture Diagram.
- G-05 Institutional Brief v6.
- G-06 Data Room Index v1 — Superseded by the v2.0 doc this reference is built from.
- G-07 Institutional Brief PDFs.
- G-08 Institutional Proposal (HTML).
- G-09 Logo (PNG).
- G-10 Concept Visualisations (the cosmic/AI-generated images already flagged in MEMORY.md's brand section).

## Not yet read in depth (flagged for next pass, not done unprompted — ask Sashin which matters most)
- A-02 Founder Doctrine & Origin Paper — likely supersedes/formalises the 2016 handwritten pages.
- D-08 Full Manifesto (Complete, v5.0) — the complete public narrative document.
- d-24_gods_world_pledge_document_v1.docx (131KB, not yet in this index pass) — the actual "World Pledge" Sashin wants people to sign.

## Discrepancies to resolve with Sashin (do not silently pick one)
1. T.S Industries naming: v1 data room called it "Transition Systems"; v2 doesn't repeat a full name; Sashin told Claude directly this session it's "The Technological Sector." Going with Sashin's direct statement as most current — but the document trail itself is inconsistent.
2. Patent count: data room's B-03 says "5 priority filings" (portfolio-wide); Claude's separate memory references a UDOC-specific instrument with "4 core patents / 23 claims / 19 embodiments." Possibly different scopes, not confirmed.
3. T.S Industries sector count: B-08 (legal SPV template) lists 5 SPV types (Energy, Farming, Water, AI Governance, Digital Backbone); E-06 and the live site both say 7 subsidiaries (adds Construction, Manufacturing, Logistics; renames Farming→AgriTech). Likely the legal template is older/narrower — not confirmed.
4. World Problems Rollout (D-06): v1 index said "10 global problems," v2 index said "Eight structural crises" for what appears to be the same document.
