const H = require("/home/claude/helpers.js");
const { h1, h2, h3, body, bold, ital, plain, goldBold, flagBold, navyBold, bullet, hr, calloutBox, flagBox, spacer, makeTable, pageBreak, AlignmentType, Paragraph, TextRun } = H;

function buildRemainingSections() {
  const c = [];

  // ---------- 4. PATENT & PRIOR ART ----------
  c.push(h1("4.  The patent & prior-art reality"));
  c.push(body("This remains a research-based landscape scan, not a legal freedom-to-operate (FTO) opinion. The author is not a patent attorney and this is not legal advice. UDOC mostly assembles and orchestrates technologies that already exist as commodity hardware, open standards, or published research \u2014 which lowers infringement risk but also means broad claims would likely be narrowed or rejected over prior art. The strongest realistic IP position remains a system/combination patent plus copyright and trade-secret protection on the specific architecture, not a sweeping monopoly. This finding is unchanged from the original assessment and applies equally to S.E.T.H.S, T.S Industries, and M.A.D.I.B.A: their defensibility rests on operational methodology, brand, and execution speed \u2014 not on any patentable primitive. Workforce-assessment frameworks, SPV co-investment structures, and fund-management mechanics are not patentable subject matter in any of the jurisdictions G.O.D.S operates in; their protection, where it exists at all, is via trade secret, copyright on specific documentation, and trademark on the named methodology (e.g. \u201CS.E.T.H.S Certified\u201D)."));

  // ---------- 5. LIVE BUILD STATUS ----------
  c.push(h1("5.  Live build status \u2014 RESOLVED (confirmed by Sashin, 30 June 2026)"));
  c.push(body("This section existed in earlier drafts of this report as an unresolved contradiction. It is now resolved. The backend is confirmed live."));
  c.push(calloutBox([
    body([bold("Confirmed: "), plain("The UDOC backend is live and deployed at gods-platform-core.onrender.com, backed by a Neon Postgres database hosted on Render. 72 API routes are deployed and tested. An Android build has been compiled and installed on device. The Capstone Live tab on capstoneprojectsjs.netlify.app demonstrates the working system including governance routes and user interfaces for all divisions. This was built during an intensive development window and deployed before the site's prior suspension period. The founder confirmed this directly on 30 June 2026.")]),
  ]));
  c.push(body("What remained unresolved at the time of initial drafting, and is now the only remaining action item from this section, is the live website copy itself. The UDOC section of the live site currently states \u2014 in three separate places \u2014 \u201CArchitecture designed. No code written. No clients engaged. Build commences at seed capital close.\u201D This was accurate pre-build and was likely written during the planning phase; it was not updated after the build was completed. It now actively contradicts the confirmed live system and should be corrected before any press outreach, competition application, or investor diligence engagement takes place."));
  c.push(h3("Recommended replacement copy for the UDOC section of the live site"));
  c.push(calloutBox([
    body([bold("Replace: "), ital("\u201CArchitecture designed. No code written. No clients engaged. Build commences at seed capital close.\u201D")]),
    body([bold("With: "), ital("\u201CCapstone build live: 72 backend routes deployed and tested (gods-platform-core.onrender.com / Neon Postgres). Android build compiled and installed on device. Governance gate, EVA engine, and audit-chain issuing in production. Full commercial platform and enterprise multi-plane architecture build commences at seed capital close.\u201D")]),
  ]));

  c.push(h3("Three further minor reconciliations from this research pass"));
  c.push(bullet([bold("Unemployment statistic: "), plain("the live site leads with \u201C32.9% official \u00B7 43.1% expanded\u201D nationally, and \u201C62.4% expanded\u201D for youth 15\u201324. This report's primary research found 32.7% official, 43.7% LU3 expanded, and 60.9% official youth rate from the Stats SA Q1 2026 QLFS primary source. All figures are close; the small differences may reflect different publication timings or measure choices within the same survey. Recommend picking one primary source and one primary figure across all materials rather than allowing different numbers to appear in different documents.")]));
  c.push(bullet([bold("Patent claim count \u2014 resolved: "), plain("the authoritative figure, taken from the live site's own UDOC section and its IP instrument summary, is "), bold("24 patent claim families (4 core patent applications + 20 alternative embodiments, including zk-SOV)"), plain(", attorney-ready for CIPC provisional + PCT international filing, not yet filed. This supersedes the two earlier, inconsistent figures (4 core/19 embodiments from an earlier instrument draft; 5 portfolio filings from the data room B-03) \u2014 use 24 going forward.")]));
  c.push(bullet([bold("Document count: "), plain("the live site's individual document cards say \u201CFrom the 73-Doc Data Room\u201D; the site's own overview statistics say \u201C103 documents, 102 downloadable.\u201D Both numbers are accurate for different things (73 = unique registered documents in the formal data room index; 103 = total institutional documents including all versions and supporting files). A brief explanatory note on the site (\u201C103 total institutional documents, 73 formally registered in the master data room index\u201D) would close this ambiguity immediately.")]));

  // ---------- 6. GENUINE EDGE ----------
  c.push(h1("6.  G.O.D.S's genuine edge \u2014 updated across all four divisions"));
  c.push(body("Four things remain real after this expanded research pass; each is also unproven at scale, and this report continues to say so."));
  c.push(h2("6.1  The four-division closed loop (still the strongest differentiator)"));
  c.push(body("Confirmed again, more thoroughly, this pass: no single comparable researched across any of the four divisions \u2014 not Harambee, not Ninety One, not Credo AI, not Phatisa \u2014 combines AI governance, workforce reintegration, production infrastructure, and capital recycling as one self-reinforcing system. Every comparable found is a single-domain specialist, several of them very large ones. This remains G.O.D.S's most defensible claim and the one this expanded research did the most to stress-test \u2014 it held."));
  c.push(h2("6.2  Independent third-party validation of the core thesis, found this pass"));
  c.push(body([plain("The PIC's April 2026 TVET-as-investable-infrastructure paper (\u00A72.3) is the strongest piece of external validation found anywhere in this research \u2014 it was published independently, by Africa's largest asset manager, proposing close to G.O.D.S's own S.E.T.H.S\u2192T.S Industries logic, without any reference to G.O.D.S. This is worth leading with in future investor conversations: ")]));
  c.push(bullet("it is evidence the market thesis is being arrived at independently by serious institutional players, not just by G.O.D.S."));
  c.push(h2("6.3  Global-South / South-African sovereignty alignment (unchanged)"));
  c.push(body("UDOC's alignment to Gazette 54477, POPIA, FICA and FSCA remains a genuine, under-served niche \u2014 confirmed again this pass with no new contradicting evidence."));
  c.push(h2("6.4  A constitutional governance philosophy (unchanged)"));
  c.push(body("The Constitutional Oversight Board, the IP Trust, and the Founder Constraint pillar remain a coherent governance philosophy rather than a toolset \u2014 provided, as before, that it is delivered and not just described."));

  // ---------- 7. HONEST CONS AND RISKS ----------
  c.push(h1("7.  The honest cons and risks \u2014 expanded across divisions"));
  c.push(makeTable(
    ["Risk", "Division(s)", "Why it matters"],
    [
      ["Stage", "All four", "Pre-product-market-fit, pre-revenue, pre-registration, single founder, pre-funding across every division, not only UDOC."],
      ["Competition density", "All four, unevenly", "UDOC's governance core competes with USD 40m+-funded specialists. S.E.T.H.S competes with a grant-funded national platform reaching 5m+ youth. T.S competes with IPPs holding a decade of REIPPPP delivery history. M.A.D.I.B.A competes with fund managers holding R2.69 trillion (PIC) to ~$500m (Phatisa) in AUM."],
      ["Regulatory critical path", "UDOC, M.A.D.I.B.A", "SA AI policy enforcement lands 2027/28. M.A.D.I.B.A's FSCA FSP licence alone is a 12\u201318-month process that cannot legally begin raising capital until granted \u2014 a hard, undiscretionary delay regardless of funding availability."],
      ["Internal data inconsistencies", "All four", "This report surfaced four: the UDOC global TAM gap (7\u201315x between two G.O.D.S documents, resolved by defaulting to the competitive report\u2019s sourced figure); the unemployment-statistic framing gap (now understood \u2014 official vs expanded measures, should be standardised across materials); the document-count difference (73 registered vs 103 total, now understood as different things); and the Nova X Quantum\u2122 competitor citation on the live site (flagged for removal). All four are fixable; together they are still the single largest credibility risk because they are easy for any serious counterparty to find before they are corrected."],
      ["Capital fit", "All four", "Pure-play governance VC, workforce-reintegration grant funding, infrastructure project finance, and impact-fund LP capital are four different capital markets with four different expectations and timelines \u2014 M.A.D.I.B.A's role as a single interface to all four is itself unproven."],
      ["Operational complexity", "All four", "Four interdependent divisions, an FSP-licence critical path, a CIDB-grading critical path, and a governance product to ship simultaneously is a very large surface area for a single-founder team."],
    ],
    [1900, 1700, 5760]
  ));

  // ---------- 8. SCORECARD ----------
  c.push(h1("8.  G.O.D.S vs the world \u2014 the scorecard, by division"));
  c.push(makeTable(
    ["Dimension", "UDOC", "S.E.T.H.S", "T.S Industries", "M.A.D.I.B.A"],
    [
      ["Market real & growing?", "STRONG", "STRONG", "STRONG", "STRONG"],
      ["Technical/methodological novelty", "WEAK", "WEAK \u2014 method is sound, not patentable", "WEAK \u2014 SPV model is proven, not novel", "N/A \u2014 fund structures aren't patentable"],
      ["Named competition density", "HIGH (40+ players)", "HIGH (national-scale incumbent)", "HIGH per sub-sector", "HIGH (established GPs + DFIs)"],
      ["G.O.D.S's stage vs. competitors", "Capstone build confirmed live \u2014 72 routes, Android build, Render/Neon Postgres. Commercial platform builds at seed close.", "Design complete, zero participants", "Design complete, zero CIDB grading", "Design complete, no FSP licence"],
      ["Independent third-party validation found", "Moderate (regulatory alignment)", "Indirect (crisis scale is well-documented)", "STRONG \u2014 PIC's April 2026 paper", "Indirect (DFI appetite is well-documented)"],
      ["Realistic near-term path", "One regulated-sector wedge client", "One funded pilot cohort (50)", "One completed SPV project", "FSP licence granted, first LP close"],
    ],
    [2160, 1850, 1850, 1750, 1750]
  ));
  c.push(spacer(140));
  c.push(body("Read across, not down: every division shares the same shape \u2014 a real, validated market; a crowded competitive set; and a G.O.D.S entry that is currently design-complete rather than operational. The unevenness that matters most is not between divisions but within UDOC specifically, where this report's own research found the only outright factual contradiction (\u00A75)."));

  // ---------- 9. HONEST PROJECTIONS ----------
  c.push(h1("9.  Honest projections \u2014 what G.O.D.S could and should be"));
  c.push(body("Unchanged in substance from the original assessment, now explicitly extended to all four divisions: the fundable version of G.O.D.S is not \u201Cthe patented national AI governor,\u201D nor is it \u201Cthe next Harambee,\u201D nor \u201Cthe next Ninety One.\u201D It is a Global-South-focused, regulation-aligned, integration-first venture whose credible near-term sequence is to prove one wedge per division \u2014 one UDOC client, one S.E.T.H.S cohort, one T.S Industries SPV, one M.A.D.I.B.A licence milestone \u2014 rather than scaling any single division ahead of the others. The loop's value is in the connections between divisions; proving one division in isolation, however well, does not yet prove the loop."));

  // ---------- 10. CLOSING ----------
  c.push(h1("10.  Closing note"));
  c.push(body("This expanded version exists to make G.O.D.S stronger by being honest about all four of its divisions, not just one. The additional research did not find a reason to doubt the core combination thesis \u2014 if anything, the PIC's independent April 2026 paper strengthens it. What it did find is real: a genuine, fixable set of internal inconsistencies across G.O.D.S's own documents, the most serious being the live-build-status contradiction in \u00A75, which should be resolved before any of these materials go in front of an investor, a competition judge, or a journalist. None of these findings are reasons to stop. They are the specific, named items standing between the current draft and a document that survives real scrutiny."));

  // ---------- 11. SOURCES ----------
  c.push(h1("11.  Sources & methodology (this version's additions)"));
  c.push(body("Method: desk research across Stats SA primary releases, named-entity company and fund disclosures, government procurement and regulatory primary sources, and direct retrieval of G.O.D.S's own live website, conducted June 2026. All sources below are in addition to those already cited in the original UDOC-only assessment."));
  const srcs = [
    "Stats SA \u2014 QLFS Q1 2026 (national + youth release) \u2014 statssa.gov.za/?p=19526 and statssa.gov.za publications P0211",
    "Trading Economics \u2014 South Africa Unemployment Rate, incl. LU3 expanded measure \u2014 tradingeconomics.com/south-africa/unemployment-rate",
    "Department of Employment and Labour \u2014 official Q1 2026 QLFS statement \u2014 gov.za news/media-statements",
    "Harambee / Co-Impact \u2014 co-impact.org/program-partners/harambee-youth-employment-accelerator",
    "Harambee \u2014 Wikipedia, CB Insights company profile \u2014 cbinsights.com/company/harambee-youth-employment-accelerator",
    "REIPPPP Bid Window 7 \u2014 South African Government press release, gov.za; grantZA REIPPPP programme summary \u2014 grantza.org.za/energy/reippp",
    "Renewable Energy IPP Procurement Programme \u2014 Wikipedia (cumulative R256bn / 7,300MW figures)",
    "Ninety One \u2014 Emerging Africa & Asia Infrastructure Fund (EAAIF) \u2014 eaif.com; ninetyone.com infrastructure investing pages",
    "Moneyweb \u2014 \u201CNinety One plans R18bn infrastructure investment\u201D",
    "Public Investment Corporation \u2014 pic.gov.za; Wikipedia; PIC Corporate Plan 2025/26\u20132027/28FY",
    "IOL Business Report \u2014 \u201CPIC pushes for public-private partnership investment strategy to transform TVET sector\u201D (April 2026)",
    "Kwikspace \u2014 kwikspace.co.za; Afripanel \u2014 afripanels.co.za; Karmod \u2014 karmod.com (SA affordable/modular housing)",
    "AVCA (African Private Capital Association) \u2014 avca.africa member news (Phatisa, Metier, Vantage Capital, AHL Venture Partners, Africa Finance Corporation 2026 activity)",
    "Africa Global Funds \u2014 africaglobalfunds.com news (named African fund manager deal activity, 2026)",
    "Phatisa \u2014 phatisa.com; Goodwell Investments \u2014 goodwell.nl",
    "IMD \u2014 \u201CWorkplace trends for 2026 \u2014 the new labor market reality\u201D \u2014 imd.org/ibyimd/talent/workplace-trends-for-2026",
    "WebProNews \u2014 \u201CWhite-Collar Workers Shift to High-Paying Trades Amid AI Layoffs in 2026\u201D",
    "Memeburn \u2014 \u201CAI Reskilling 2026: Who's Actually Paying to Retrain Millions?\u201D",
    "G.O.D.S Holdings live website \u2014 capstoneprojectsjs.netlify.app (fetched directly, June 2026, for all live-site claims and contradictions cited in this report)",
  ];
  srcs.forEach(s => c.push(bullet(s)));

  c.push(spacer(200));
  c.push(hr());
  c.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 200 }, children: [new TextRun({ text: "G.O.D.S Holdings (Pty) Ltd  \u00B7  Good Orderly Directional Systems  \u00B7  Confidential", color: H.GREY, size: 18, italics: true })] }));

  return c;
}

module.exports = { buildRemainingSections };
