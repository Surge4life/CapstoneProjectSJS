// Shared helpers for G.O.D.S vs The World — Complete Four-Division Assessment
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  Header, Footer, AlignmentType, LevelFormat,
  HeadingLevel, BorderStyle, WidthType, ShadingType,
  VerticalAlign, PageNumber, PageBreak
} = require("docx");

const NAVY = "060E1C";
const NAVY_TEXT = "16233A";
const GOLD = "C9A84C";
const GOLD_DARK = "8C7330";
const GREY = "5B6472";
const LIGHT_GOLD_FILL = "F7F1E0";
const LIGHT_GREY_FILL = "F2F3F5";
const RED_FLAG = "9B2C2C";
const RED_FILL = "FBEAEA";
const WHITE = "FFFFFF";
const CONTENT_WIDTH = 9360;

function h1(text) { return new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun(text)] }); }
function h2(text) { return new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun(text)] }); }
function h3(text) { return new Paragraph({ heading: HeadingLevel.HEADING_3, children: [new TextRun(text)] }); }
function body(content, opts = {}) {
  const runs = typeof content === "string" ? [new TextRun({ text: content })] : content;
  return new Paragraph({ children: runs, spacing: { after: 160, line: 276 }, alignment: opts.align || AlignmentType.LEFT });
}
function bold(text) { return new TextRun({ text, bold: true }); }
function ital(text) { return new TextRun({ text, italics: true }); }
function plain(text) { return new TextRun({ text }); }
function goldBold(text) { return new TextRun({ text, bold: true, color: GOLD_DARK }); }
function flagBold(text) { return new TextRun({ text, bold: true, color: RED_FLAG }); }
function navyBold(text) { return new TextRun({ text, bold: true, color: NAVY_TEXT }); }

function bullet(content, level = 0) {
  const runs = typeof content === "string" ? [new TextRun(content)] : content;
  return new Paragraph({ numbering: { reference: "bullets", level }, children: runs, spacing: { after: 100, line: 276 } });
}
function numbered(content, level = 0) {
  const runs = typeof content === "string" ? [new TextRun(content)] : content;
  return new Paragraph({ numbering: { reference: "numbers", level }, children: runs, spacing: { after: 100, line: 276 } });
}
function hr() {
  return new Paragraph({ spacing: { before: 120, after: 120 }, border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: GOLD } }, children: [] });
}
function calloutBox(lines) {
  return new Table({
    width: { size: CONTENT_WIDTH, type: WidthType.DXA }, columnWidths: [CONTENT_WIDTH],
    rows: [new TableRow({ children: [new TableCell({
      width: { size: CONTENT_WIDTH, type: WidthType.DXA }, shading: { fill: LIGHT_GOLD_FILL, type: ShadingType.CLEAR },
      borders: { top: { style: BorderStyle.SINGLE, size: 4, color: GOLD }, bottom: { style: BorderStyle.SINGLE, size: 4, color: GOLD }, left: { style: BorderStyle.SINGLE, size: 4, color: GOLD }, right: { style: BorderStyle.SINGLE, size: 4, color: GOLD } },
      margins: { top: 160, bottom: 160, left: 200, right: 200 }, children: lines,
    })] })],
  });
}
function flagBox(titleText, lines) {
  return new Table({
    width: { size: CONTENT_WIDTH, type: WidthType.DXA }, columnWidths: [CONTENT_WIDTH],
    rows: [new TableRow({ children: [new TableCell({
      width: { size: CONTENT_WIDTH, type: WidthType.DXA }, shading: { fill: RED_FILL, type: ShadingType.CLEAR },
      borders: { top: { style: BorderStyle.SINGLE, size: 4, color: RED_FLAG }, bottom: { style: BorderStyle.SINGLE, size: 4, color: RED_FLAG }, left: { style: BorderStyle.SINGLE, size: 4, color: RED_FLAG }, right: { style: BorderStyle.SINGLE, size: 4, color: RED_FLAG } },
      margins: { top: 160, bottom: 160, left: 200, right: 200 },
      children: [new Paragraph({ children: [flagBold(titleText)], spacing: { after: 100 } }), ...lines],
    })] })],
  });
}
function spacer(h = 120) { return new Paragraph({ spacing: { after: h }, children: [] }); }

function makeTable(headers, rows, widths) {
  const w = widths || headers.map(() => Math.floor(CONTENT_WIDTH / headers.length));
  const cellBorder = { style: BorderStyle.SINGLE, size: 2, color: "CCCCCC" };
  const borders = { top: cellBorder, bottom: cellBorder, left: cellBorder, right: cellBorder };
  const headerRow = new TableRow({
    tableHeader: true,
    children: headers.map((hText, i) => new TableCell({
      width: { size: w[i], type: WidthType.DXA }, shading: { fill: NAVY, type: ShadingType.CLEAR }, borders,
      margins: { top: 100, bottom: 100, left: 120, right: 120 }, verticalAlign: VerticalAlign.CENTER,
      children: [new Paragraph({ children: [new TextRun({ text: hText, bold: true, color: WHITE, size: 19 })] })],
    })),
  });
  const bodyRows = rows.map((r, ri) => new TableRow({
    children: r.map((cell, ci) => {
      let content;
      if (typeof cell === "string") {
        content = [new Paragraph({ children: [new TextRun({ text: cell, size: 19 })], spacing: { after: 40 } })];
      } else if (Array.isArray(cell)) {
        content = cell.map(p => (p instanceof Paragraph ? p : new Paragraph({ children: [p], spacing: { after: 40 } })));
      } else {
        content = [new Paragraph({ children: [cell] })];
      }
      return new TableCell({
        width: { size: w[ci], type: WidthType.DXA }, shading: { fill: ri % 2 === 0 ? WHITE : LIGHT_GREY_FILL, type: ShadingType.CLEAR }, borders,
        margins: { top: 90, bottom: 90, left: 120, right: 120 }, verticalAlign: VerticalAlign.CENTER, children: content,
      });
    }),
  }));
  return new Table({ width: { size: CONTENT_WIDTH, type: WidthType.DXA }, columnWidths: w, rows: [headerRow, ...bodyRows] });
}
function pageBreak() { return new Paragraph({ children: [new PageBreak()] }); }

module.exports = {
  NAVY, NAVY_TEXT, GOLD, GOLD_DARK, GREY, LIGHT_GOLD_FILL, LIGHT_GREY_FILL, RED_FLAG, RED_FILL, WHITE, CONTENT_WIDTH,
  h1, h2, h3, body, bold, ital, plain, goldBold, flagBold, navyBold, bullet, numbered, hr, calloutBox, flagBox, spacer, makeTable, pageBreak,
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, Header, Footer, AlignmentType, LevelFormat,
  HeadingLevel, BorderStyle, WidthType, ShadingType, VerticalAlign, PageNumber, PageBreak,
};
