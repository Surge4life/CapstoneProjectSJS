const H = require("/home/claude/helpers.js");
const { h1, h2, h3, body, bold, ital, plain, goldBold, flagBold, navyBold, bullet, hr, calloutBox, flagBox, spacer, makeTable, pageBreak, AlignmentType, Paragraph, TextRun } = H;

function buildCompetitorsSection() {
  const c = [];
  c.push(h1("3.  The competitors: who is doing what each division would do"));
  c.push(body("No single company combines all four G.O.D.S divisions \u2014 that finding is unchanged and remains G.O.D.S's strongest claim. But each division individually overlaps with named, operating, sometimes well-funded players. This section gives each division the same tier-by-tier treatment."));

  // ---- 3.1 UDOC ----
  c.push(h2("3.1  UDOC \u2014 AI governance"));
  c.push(body("Four tiers, largely unchanged from the original assessment:"));
  c.push(bullet([bold("Tier 1 \u2014 Hyperscalers and incumbents: "), plain("IBM watsonx.governance (FedRAMP-authorised, AI FactSheets, March 2026 real-time generative-AI risk monitoring, partnered with NVIDIA at GTC 2026); Microsoft, Google, AWS, Oracle, SAP, Salesforce \u2014 each ships governance embedded in its cloud platform.")]));
  c.push(bullet([bold("Tier 2 \u2014 Pure-play governance leaders: "), plain("Credo AI (category leader, founded 2020, USD 41.3m raised, Forrester Leader, named alongside Google/NVIDIA/OpenAI/Anthropic on Fast Company's 2026 Most Innovative list); Holistic AI, OneTrust, ModelOp, Atlan, Securiti, 2021.AI, Saidot, Norm Ai, Monitaur, Fairly AI.")]));
  c.push(bullet([bold("Tier 3 \u2014 Monitoring/observability: "), plain("Fiddler, Arthur, Arize, WhyLabs \u2014 narrower than full lifecycle governance.")]));
  c.push(bullet([bold("Tier 4 \u2014 Closest direct analogs: "), plain("WalledAI (Singapore) \u2014 explicitly markets \u201CSovereign AI Governance Infrastructure,\u201D shipping today for a different region; ETHOS (academic) \u2014 a published blockchain-audit-trail framework that anticipates StayChain + EVA conceptually.")]));

  c.push(h3("A correction needed on the live site's Tier 4"));
  c.push(flagBox("\u201CNova X Quantum\u201D should not be cited as a credible competitor", [
    body("G.O.D.S's live website currently names \u201CNova X Quantum\u2122\u201D as UDOC's \u201Cclosest conceptual competitor.\u201D Direct research into this company's own public materials found significant overclaim red flags: trademarked, undefined terminology (\u201CImmortal Logic System\u2122,\u201D \u201CGenesis Vault\u2122,\u201D \u201Cresurrection-grade cognition\u201D), covenant-based rather than commercial licensing language, and claims spanning AI governance, humanoid robotics, quantum computing, and sovereign banking simultaneously \u2014 a breadth and tone inconsistent with a credible, fundable governance-sector peer. No independent press coverage, funding disclosure, or named enterprise client was found to corroborate the claims on the company's own site. This is exactly the kind of unverified claim G.O.D.S's own honesty discipline exists to catch before it reaches an investor's diligence team. Recommend removing this reference from the live site and any future pitch material; it does not survive even a single round of scrutiny and would cost more credibility than the comparison is worth."),
  ]));

  c.push(h3("UDOC patent claim count \u2014 a third inconsistency, not yet two"));
  c.push(flagBox("Three different patent counts now exist across G.O.D.S's own materials", [
    body([plain("An earlier UDOC-specific patent instrument referenced elsewhere in G.O.D.S's working documents: "), bold("4 core patents, 19 embodiments, 12 trademark applications.")]),
    body([plain("The institutional data room's portfolio-wide filing (B-03): "), bold("5 priority filings"), plain(" (quantum governance, bias detection, QKD integration, constitutional constraint satisfaction, workforce-infrastructure loop) \u2014 likely a different, broader scope, not confirmed.")]),
    body([plain("The live website's current copy: "), bold("24 patent claim families (4 core inventions + 20 alternative embodiments, including zk-SOV)."), plain(" This is the newest and most specific figure, but it does not match either of the above, and the live site's own document summary for the same instrument separately states \u201C4 core patent applications + 20 alternative embodiments.\u201D")]),
    body("This needs one authoritative number before it goes in front of a patent attorney or an investor \u2014 not because any individual figure looks dishonest, but because three different counts for the same instrument is precisely the kind of internal inconsistency this report's own discipline is built to catch."),
  ]));

  // ---- 3.2 S.E.T.H.S ----
  c.push(h2("3.2  S.E.T.H.S \u2014 workforce reintegration"));
  c.push(makeTable(
    ["Player", "Category & status", "Overlaps S.E.T.H.S on\u2026", "Where S.E.T.H.S differs"],
    [
      ["Harambee / SA Youth", "National-scale, grant-funded, government-adopted", "Youth employment pipeline, employer matching, work-readiness training", "Integrated four-division loop; explicit lifetime re-entry design (\u201Cdoor never closes\u201D); trauma-informed/recovery-specific intake stream"],
      ["WeThinkCode", "NQF5-accredited alt-education, ~1,867 graduates, 81% placement", "Accredited, stackable-skills structure; SETA-adjacent accreditation strategy", "Five parallel vocational streams vs. one tech vertical; explicit addiction/justice-system reintegration mandate"],
      ["YES4Youth", "Corporate-funded, B-BBEE-incentive-linked, 12-month placements", "Employer partnership model; B-BBEE scorecard alignment", "S.E.T.H.S's proposed lifetime continuity directly answers YES's structural weakness \u2014 support ending when the incentive period ends"],
      ["Zaio / Shaper / UVU Africa", "Single-vertical digital-skills bootcamps and NGOs", "Digital literacy and tech-pathway training (S.E.T.H.S Stream B)", "S.E.T.H.S is broader (5 streams: construction, digital, agriculture, health, logistics) but unproven at any of these players' existing scale"],
    ],
    [1700, 2200, 2630, 2830]
  ));

  // ---- 3.3 T.S Industries ----
  c.push(h2("3.3  T.S Industries \u2014 production & infrastructure"));
  c.push(makeTable(
    ["Player", "Category & status", "Overlaps T.S on\u2026", "Where T.S differs"],
    [
      ["Red Rocket, Mulilo, Scatec, ACWA Power", "Established REIPPPP IPPs, multiple completed bid windows, hundreds of MW each", "Solar/wind SPV development under the same REIPPPP co-investment framework T.S Energy proposes to use", "T.S Energy has zero CIDB grading and zero completed projects; these players have a decade of delivery history each"],
      ["Kwikspace / Afripanel / Karmod", "Established modular/prefab construction manufacturers, 14\u201350+ years operating, CIDB/NHBRC-certified", "Modular/prefab affordable housing delivery (T.S Construction's core model)", "T.S Construction is pre-registration with no NHBRC or CIDB grading; these players are already certified and delivering"],
      ["Ninety One (EAAIF + SA Infrastructure Credit Fund)", "Established infrastructure debt platform, $3bn+ committed since 2001, A2 Moody's rated", "The SPV co-investment / blended-capital structuring model T.S proposes to use across all 7 subsidiaries", "T.S would be a project sponsor/operator inside this kind of structure, not a fund manager \u2014 different role, same financing mechanism"],
      ["DBSA Ifisa / PIC", "Government and state-asset-manager infrastructure financing vehicles, live/active April 2026", "Government co-investment appetite for exactly the workforce-into-infrastructure model T.S + S.E.T.H.S propose", "These are T.S's most likely capital partners, not direct competitors \u2014 but they also fund other operators pursuing similar models"],
    ],
    [2000, 2630, 2530, 2200]
  ));

  // ---- 3.4 M.A.D.I.B.A ----
  c.push(h2("3.4  M.A.D.I.B.A \u2014 capital deployment & sovereignty alignment"));
  c.push(makeTable(
    ["Player", "Category & status", "Overlaps M.A.D.I.B.A on\u2026", "Where M.A.D.I.B.A differs"],
    [
      ["AIIM, Phatisa, Metier, Vantage Capital", "Established African PE/infrastructure/impact fund managers, decades of operating history, hundreds of millions to billions in AUM each", "GP-style capital deployment into African infrastructure and impact sectors", "M.A.D.I.B.A has no FSP licence, no fund closed, no LP commitments, and is not yet a registered entity"],
      ["LeapFrog Investments, Goodwell + Alitheia, AHL Venture Partners", "Pan-African impact-focused fund managers with active, recently-closed funds (2026 activity confirmed)", "Sovereign-aligned, impact-first capital deployment thesis", "Same stage gap as above; these are realistic co-investors or competitors for LP capital, not yet peers in scale"],
      ["DBSA, IDC, AfDB, IFC", "DFIs \u2014 M.A.D.I.B.A's primary intended capital sources, not direct competitors", "Target LP relationships; the capital M.A.D.I.B.A is built to access and channel", "M.A.D.I.B.A is positioned as an intermediary/interface to these institutions, not a substitute for them"],
      ["PIC", "Africa's largest asset manager, R2.69 trillion AUM, state-owned", "Already active in exactly the social-infrastructure/education space M.A.D.I.B.A targets (April 2026 TVET paper)", "Scale gap is categorical, not competitive \u2014 PIC is a plausible eventual LP or government-aligned partner, not a peer"],
    ],
    [2300, 2400, 2400, 2260]
  ));

  c.push(spacer(140));
  c.push(body("Bottom line across all four divisions: G.O.D.S's governance core, workforce core, infrastructure core, and capital core are each genuinely crowded by named, operating, often well-capitalised players. What is not crowded \u2014 in any division researched, in South Africa specifically \u2014 is the combination of all four into one closed, constitutionally-governed loop. That remains the real story. It should be told as exactly that: a combination thesis, not an empty-market thesis."));

  c.push(pageBreak());
  return c;
}

module.exports = { buildCompetitorsSection };
