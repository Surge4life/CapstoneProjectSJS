const H = require("/home/claude/helpers.js");
const { h1, h2, h3, body, bold, ital, plain, goldBold, flagBold, navyBold, bullet, hr, calloutBox, flagBox, spacer, makeTable, pageBreak, AlignmentType, Paragraph, TextRun, PageBreak } = H;

function buildCoverAndExecSummary() {
  const c = [];

  // ---------- COVER ----------
  c.push(
    new Paragraph({ spacing: { after: 60 }, alignment: AlignmentType.CENTER, children: [new TextRun({ text: "G . O . D . S", bold: true, color: H.GOLD_DARK, size: 22 })] }),
    new Paragraph({ spacing: { after: 360 }, alignment: AlignmentType.CENTER, children: [new TextRun({ text: "GOOD ORDERLY DIRECTIONAL SYSTEMS", color: H.GREY, size: 18 })] }),
    new Paragraph({ spacing: { after: 80 }, alignment: AlignmentType.CENTER, children: [new TextRun({ text: "G.O.D.S vs THE WORLD", bold: true, color: H.NAVY_TEXT, size: 48 })] }),
    new Paragraph({ spacing: { after: 60 }, alignment: AlignmentType.CENTER, children: [new TextRun({ text: "Complete Four-Division Assessment", italics: true, color: H.GOLD_DARK, size: 30 })] }),
    new Paragraph({ spacing: { after: 400 }, alignment: AlignmentType.CENTER, children: [new TextRun({ text: "Today's Reality versus the Projected Truth \u2014 UDOC \u00B7 S.E.T.H.S \u00B7 T.S Industries \u00B7 M.A.D.I.B.A", italics: true, color: H.GREY, size: 22 })] }),
    hr(), spacer(200),
    body([bold("Prepared by: "), plain("Sashin J. Singh \u2014 Founder & Systems Architect")]),
    body([bold("Entity: "), plain("G.O.D.S Holdings (Pty) Ltd (pre-registration)")]),
    body([bold("Audience: "), plain("Prospective investors, partners, and capstone review")]),
    body([bold("Date: "), plain("June 2026")]),
    body([bold("Supersedes: "), plain("\u201CG.O.D.S vs The World \u2014 Competitive, Patent & Market Assessment\u201D (June 2026), which covered UDOC only")]),
    body([bold("Classification: "), plain("Confidential \u00B7 evidence-based \u00B7 deliberately honest")]),
    spacer(160),
    calloutBox([
      body([bold("Why this version exists. ")]),
      body([plain("The original report assessed UDOC in real depth but left S.E.T.H.S, T.S Industries, and M.A.D.I.B.A unsized \u2014 a gap flagged in G.O.D.S\u2019s own working notes. This version closes it: every division now gets the same treatment \u2014 named competitors, sourced market figures, and an explicit live-vs-planned line. Where a figure inside G.O.D.S\u2019s own document set conflicts with another, this report says so rather than quietly picking one. Nothing here is inflated; where G.O.D.S is behind, it says so.")]),
    ]),
  );
  c.push(pageBreak());

  // ---------- 1. EXECUTIVE SUMMARY ----------
  c.push(h1("1.  Executive summary"));
  c.push(body("G.O.D.S's thesis is that four structural failures \u2014 unemployment without a pipeline into work, infrastructure without the workforce or capital to build it, AI deployed without sovereign governance, and capital without a trusted local deployment vehicle \u2014 are not four separate problems requiring four separate vendors. They are one compounding failure, and G.O.D.S is built as one closed loop to address it. That thesis is directionally well-supported: AI governance, infrastructure co-investment, workforce reintegration, and African impact capital are all real, growing, independently-validated categories in 2026. The harder truth, covered honestly in this report, is that every one of those four categories already has funded, operating, sometimes decades-old players in it \u2014 South Africa's REIPPPP alone has put R256 billion into private energy infrastructure since inception; Harambee has moved over 876,000 young South Africans into income opportunities; Ninety One's infrastructure platforms have deployed over $3 billion across the continent; the PIC alone manages more capital (R2.69 trillion) than every figure in G.O.D.S's 25-year financial model combined, several times over."));
  c.push(body("No single existing player combines all four divisions the way G.O.D.S proposes to. That remains G.O.D.S's most defensible claim, and this report continues to find no entity that disproves it. But \u201Cno one combines all four\u201D is a different and much narrower claim than \u201Cno one is doing this work\u201D \u2014 and the gap between those two claims is exactly where an investor's first hard question will land."));

  c.push(h2("The one-paragraph verdict"));
  c.push(calloutBox([
    body([ital("As a capstone, G.O.D.S is exceptional across all four divisions \u2014 not just UDOC. The S.E.T.H.S design (its five pillars, its phased curriculum, its lifetime-continuity proposal), the T.S Industries SPV model, and the M.A.D.I.B.A capital architecture are each coherent, well-researched, and honestly self-rated as planning-stage rather than operational. As a start-up, G.O.D.S is early-stage, pre-revenue, pre-registration, and single-founder, entering four real but separately crowded markets against opponents ranging from well-funded specialists to some of the largest asset managers and DFIs on the African continent. None of the four divisions should be sold to investors as uncontested. Each should be sold as a focused, regulation-aligned, honestly-staged entry into a real market \u2014 where G.O.D.S's actual edge is the combination, the founder's evidenced execution, and a constitutional governance model that is a philosophy, not a feature. Valued on execution, integration, and positioning across all four divisions \u2014 not on first-mover advantage in any single one \u2014 it remains a serious, unusually well-documented proposition.")]),
  ]));

  c.push(h2("The numbers that frame everything \u2014 all four divisions"));
  c.push(makeTable(
    ["Division", "2026 reality (sourced)", "Where G.O.D.S sits"],
    [
      ["UDOC \u2014 AI governance", "Global AI-governance software market ~USD 0.3\u20130.75bn (2025/26), forecast USD 2.6\u20135.9bn by 2030\u20132035. SA enforcement (Gazette 54477) lands 2027/28.", "Architecture designed, patent instrument authored. Build status disputed \u2014 see \u00A77."],
      ["S.E.T.H.S \u2014 workforce reintegration", "SA youth (15\u201324) unemployment 60.9% (Q1 2026, Stats SA); national official rate 32.7%, expanded (LU3) rate 43.7%. Harambee alone has created 876,131 income opportunities since 2011.", "Programme design complete (5 phases, 5 pillars). Zero participants enrolled, zero facility secured."],
      ["T.S Industries \u2014 production & infrastructure", "REIPPPP has attracted R256bn in private investment since inception; Bid Window 7 alone was R31.4bn for 1,760MW. SA's 2026/27 Budget commits R1.07 trillion to public infrastructure over 3 years.", "7 subsidiaries planned. No CIDB grading, no projects awarded, no SPVs formed."],
      ["M.A.D.I.B.A \u2014 capital deployment", "PIC alone manages R2.69 trillion (Africa's largest asset manager). African impact funds collectively manage an estimated USD 70\u201380bn.", "3-vehicle capital strategy designed. No FSP licence, no LP commitments, entity not yet registered."],
    ],
    [2400, 4400, 2560]
  ));
  c.push(spacer(160));
  c.push(body("Read conservatively: every market G.O.D.S has chosen is real, large, and growing \u2014 government and DFI-backed capital is actively being deployed into all four categories right now, in South Africa specifically. None of the four markets is invented or speculative. The honest qualifier is scale: G.O.D.S's entire 25-year base-case revenue trajectory (peaking around R60bn) is smaller than a single year of PIC's impact-allocation activity, and its R12\u201318m seed ask is a rounding error against the R256bn already committed to renewable energy alone. This is the correct frame for an investor conversation: a credible, evidenced entrant into four real markets \u2014 not a category-definer in any one of them yet."));

  c.push(pageBreak());
  return c;
}

module.exports = { buildCoverAndExecSummary };
