const fs = require("fs");
const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  Header, Footer, AlignmentType, LevelFormat, HeadingLevel,
  BorderStyle, WidthType, ShadingType, VerticalAlign, PageNumber, PageBreak } = require("docx");

// ── Brand (GODS_Brand_Manual v1.0 March 2026) ──
const N = "060E1C"; const NT = "16233A"; const GOLD = "C9A84C"; const GD = "8C7330";
const GREY = "5B6472"; const AQUA = "1A6B6B"; const LGF = "E8F4F1"; const LYF = "F7F1E0";
const LBF = "F2F3F5"; const WH = "FFFFFF"; const RED = "9B2C2C"; const CW = 9360;

const sp  = (h=100) => new Paragraph({ spacing:{after:h}, children:[] });
const pb  = ()      => new Paragraph({ children:[new PageBreak()] });
const hr  = (c=GOLD,sz=6) => new Paragraph({ spacing:{before:100,after:100}, border:{bottom:{style:BorderStyle.SINGLE,size:sz,color:c}}, children:[] });

const R  = (t,o={}) => new TextRun({text:t,font:"Arial",size:21,...o});
const B  = (t,o={}) => new TextRun({text:t,font:"Arial",size:21,bold:true,...o});
const BI = (t,o={}) => new TextRun({text:t,font:"Arial",size:21,bold:true,italics:true,...o});
const G  = (t,sz=21,bold=false) => new TextRun({text:t,color:GD,bold,size:sz,font:"Arial"});
const A  = (t,sz=21,bold=false) => new TextRun({text:t,color:AQUA,bold,size:sz,font:"Arial"});
const RD = (t,sz=21) => new TextRun({text:t,color:RED,size:sz,font:"Arial"});

const p  = (runs,opts={}) => new Paragraph({children:Array.isArray(runs)?runs:[R(runs)],spacing:{after:140,line:276},alignment:opts.align||AlignmentType.LEFT,...opts});
const ctr= (t,sz=22,bold=false,col=NT) => new Paragraph({alignment:AlignmentType.CENTER,spacing:{after:80},children:[new TextRun({text:t,size:sz,bold,color:col,font:"Arial"})]});

function h1(t){return new Paragraph({heading:HeadingLevel.HEADING_1,children:[new TextRun({text:t,font:"Arial"})],spacing:{before:320,after:180}});}
function h2(t){return new Paragraph({heading:HeadingLevel.HEADING_2,children:[new TextRun({text:t,font:"Arial"})],spacing:{before:260,after:140}});}
function h3(t){return new Paragraph({heading:HeadingLevel.HEADING_3,children:[new TextRun({text:t,font:"Arial"})],spacing:{before:200,after:100}});}

const blt=(t,lv=0)=>new Paragraph({numbering:{reference:"bullets",level:lv},children:Array.isArray(t)?t:[R(t)],spacing:{after:80,line:276}});

function box(lines,fill=LYF,bc=GOLD){
  return new Table({width:{size:CW,type:WidthType.DXA},columnWidths:[CW],rows:[new TableRow({children:[new TableCell({
    width:{size:CW,type:WidthType.DXA},shading:{fill,type:ShadingType.CLEAR},
    borders:Object.fromEntries(["top","bottom","left","right"].map(s=>[s,{style:BorderStyle.SINGLE,size:4,color:bc}])),
    margins:{top:160,bottom:160,left:220,right:220},children:lines})]})]});
}

function tbl(headers,rows,widths,hfill=N){
  const w=widths||headers.map(()=>Math.floor(CW/headers.length));
  const bd={style:BorderStyle.SINGLE,size:2,color:"CCCCCC"};
  const borders={top:bd,bottom:bd,left:bd,right:bd};
  const hRow=new TableRow({tableHeader:true,children:headers.map((h,i)=>new TableCell({width:{size:w[i],type:WidthType.DXA},shading:{fill:hfill,type:ShadingType.CLEAR},borders,margins:{top:100,bottom:100,left:120,right:120},children:[new Paragraph({children:[new TextRun({text:h,bold:true,color:WH,size:19,font:"Arial"})]})]}))}),
  bRows=rows.map((r,ri)=>new TableRow({children:r.map((cell,ci)=>new TableCell({width:{size:w[ci],type:WidthType.DXA},shading:{fill:ri%2===0?WH:LBF,type:ShadingType.CLEAR},borders,margins:{top:90,bottom:90,left:120,right:120},children:[new Paragraph({children:[new TextRun({text:cell,size:19,font:"Arial"})],spacing:{after:40}})]}))}));
  return new Table({width:{size:CW,type:WidthType.DXA},columnWidths:w,rows:[hRow,...bRows]});
}

// ─────────────────────────────────────────────────────────
const C = []; // all content elements

// ══════════════════════════════════════════════════════════
// COVER
// ══════════════════════════════════════════════════════════
C.push(
  sp(600),
  ctr("G . O . D . S  HOLDINGS",18,false,GD),
  ctr("GOOD ORDERLY DIRECTIONAL SYSTEMS",15,false,GREY),
  sp(200),
  ctr("GBS-SETHS",72,true,N),
  sp(60),
  ctr("Global Belief System",32,false,GD),
  ctr("Systematically Engineered Transfer of Human Systems",24,true,AQUA),
  sp(200),
  hr(GOLD,10),
  sp(120),
  ctr("VERSION 2.0  ·  MASTER INSTITUTIONAL FRAMEWORK  ·  JULY 2026",18,false,GREY),
  sp(80),
  ctr("The G.O.D.S. Holdings Constitutional Governance Infrastructure",20,false,NT),
  ctr("Development Model for Global Human Acceleration & Workforce Transition",20,false,NT),
  sp(240),
  hr(),sp(120),
  p([B("Architect & Founder:  "),R("Sashin J. Singh")]),
  p([B("Institution:  "),R("G.O.D.S Holdings (Pty) Ltd — Pre-Registration, Johannesburg, South Africa")]),
  p([B("IP Custodian:  "),R("G.O.D.S IP Trust — Trust Property Control Act 57 of 1988")]),
  p([B("Classification:  "),R("OPEN — Institutional Adoption Invitation")]),
  p([B("Conception:  "),R("2016 — Seth's Empire, Johannesburg (one decade of development)")]),
  p([B("Formalised:  "),R("2025–2026 via G.O.D.S Holdings institutional architecture")]),
  p([B("Version History:  "),R("v1.0 (July 2026) → v2.0 (July 2026) — expanded to full constitutional framework")]),
  sp(160),
  box([
    p([B("Authorship declaration. ")]),
    p([R("This framework represents a decade of original intellectual architecture by Sashin J. Singh — originating in 2016 as the Seth's Empire concept and continuously refined through personal experience, research, and systematic development. AI documentation tools were used to structure, clarify, and amplify the articulation of this work. Every concept, pillar, methodology, system, and framework described here originates from SJS's own design. AI made the work legible to a global audience — it did not create the work.")]),
  ],LYF,GOLD),
  pb()
);

// ══════════════════════════════════════════════════════════
// PART I — G.O.D.S. CONSTITUTIONAL FOUNDATION
// ══════════════════════════════════════════════════════════
C.push(
  ctr("PART  I",22,true,GD), ctr("G.O.D.S. HOLDINGS — CONSTITUTIONAL FOUNDATION",26,true,N), hr(AQUA), sp(200), pb(),
  h1("1.  Origin & Founding Mandate"),
  p("G.O.D.S Holdings was conceived in Johannesburg in 2016 by Sashin J. Singh — not as a technology company, not as a social enterprise, and not as a government programme. It was conceived as a civilisational infrastructure project: an institution designed to outlast its founder, its founding team, its founding government, and its founding era. The name carries a dual meaning: Good Orderly Directional Systems — and, at the level of general operating philosophy, a General Belief System built not on religion or ideology but on what connects human beings across every culture, language, and circumstance."),
  p("The triggering insight was simple but radical: with so many ways to make money in the world, it is absurd that people remain poor. The failure is not human intelligence — it is systematic. People do not lack potential. They lack structured access to the transfer of knowledge, skill, and opportunity. Fix the transfer mechanism. Fix everything downstream. That observation became the intellectual foundation of S.E.T.H.S, the operating methodology of GBS-SETHS, the governance architecture of UDOC, the capital engine of M.A.D.I.B.A, and the production infrastructure of T.S. Industries."),
  p("The 250-year mandate is not a marketing phrase. It is an engineering specification. Systems designed to last 250 years must be constitutionally governed, not personality-led. They must survive founder transitions, political cycles, economic crises, technological revolutions, and generational cultural shifts. G.O.D.S Holdings is designed accordingly — with a constitutional IP Trust that cannot be wound up, a Constitutional Oversight Board with removal authority over any founder, and governance principles that bind the institution regardless of who leads it."),
  sp(120),
  h2("1.1  The 250-Year Vision Statement"),
  box([
    p([BI("\"To build the permanent infrastructure through which human capability is continuously developed, transferred, and compounded — so that every generation, in every country, finds a system ready to transform their potential into measurable economic participation — for as long as human civilisation requires such infrastructure to function.\"\n— Sashin J. Singh, Founding Architect, G.O.D.S Holdings")]),
  ],LGF,AQUA),
  sp(140),
  h2("1.2  The Ten-Level G.O.D.S. System Architecture"),
  p("G.O.D.S. Holdings is not a single entity — it is a ten-level operating system. Each level is a distinct institutional function. Together they form the complete civilisational infrastructure the 250-year mandate requires."),
  tbl(
    ["Level","System","Function"],
    [
      ["0","G.O.D.S Holdings (Pty) Ltd","Institutional owner. Holds perpetual exclusive licence from the IP Trust. Governs all divisions. Constitutional authority."],
      ["1","GBS — Global Belief System","Constitutional doctrine layer. 7 Universal Principles. Franchise governance. Political neutrality architecture."],
      ["2","GBS Global Council","International standards body. Cross-national policy alignment. Treaty interface. Civilisational continuity governance."],
      ["3","GBS Franchise Network","National, provincial, and municipal licensed operators. Culturally adapted GBS-SETHS deployment."],
      ["4","S.E.T.H.S. Operations","Human acceleration engine. Participant intake, development, placement, and lifetime support. The operational core."],
      ["5","CET/CTE Engine","Educational methodology. Communication-Education-Transportation loop driving knowledge transfer at every layer."],
      ["6","G.O.D.S. Intelligence System","AI backbone. Supersedes EVA. Governs UDOC decisions. Powers participant navigation, assessment, and compliance across all levels."],
      ["7","UDOC — Unified Digital Oversight & Coordination","Governance technology layer. Sealed, auditable AI governance decisions. Constitutional enforcement. Regulatory compliance engine."],
      ["8","M.A.D.I.B.A Capital Engine","Capital deployment and sovereignty alignment. DFI interface. Impact bond structure. Revenue recycling."],
      ["9","T.S. Industries — Deployment Layer","Production and infrastructure. Primary employer for S.E.T.H.S. graduates. Seven-sector SPV co-ownership model."],
      ["10","Continental Deployment Framework","Regional implementation. Culturally adapted, locally governed, globally standardised."],
    ],
    [600,2600,6160]
  ),
  sp(160),
  pb()
);

// 12 Constitutional Pillars
C.push(
  h1("2.  The Twelve G.O.D.S. Constitutional Pillars"),
  p("The Twelve Constitutional Pillars are the non-negotiable governance principles of G.O.D.S Holdings and every system it operates. They bind every franchise node, every delivery operator, every employer partner, and every division — globally and permanently. They are not values aspirations. They are constitutional obligations, enforceable by the Constitutional Oversight Board."),
  tbl(
    ["#","Pillar","Constitutional Obligation"],
    [
      ["I","Human Dignity","Every participant, employee, partner, and stakeholder interaction must affirm and protect human dignity. No economic or operational pressure justifies its compromise."],
      ["II","Contribution First","Every individual possesses productive potential. GBS-SETHS's obligation is to find it, develop it, and connect it to economic opportunity — regardless of the individual's prior circumstances."],
      ["III","Sovereign Respect","G.O.D.S operates as a sovereign-aligned, politically neutral institution. It does not advocate partisan positions. It works with governments; it is not captured by them."],
      ["IV","Ethical Profitability","Financial returns are necessary for the institution's survival and growth. They must be earned ethically, transparently, and in ways that reinforce rather than undermine the mission."],
      ["V","Governance First","No decision, contract, partnership, or investment may proceed without constitutional governance review. The COB operates as the institution's supreme governance authority."],
      ["VI","Transparency","All institutional decisions, financial flows, outcome data, and constitutional compliance records are documented in verifiable form. G.O.D.S. does not have secrets — it has classified tiers."],
      ["VII","Founder Constraint","The founding architect may not unilaterally acquire Class A IP Trust shares, amend the Constitution, dissolve the COB, or override a COB halt decision. Governance authority supersedes founder authority in all constitutional matters."],
      ["VIII","Human Primacy in AI","AI tools may support GBS-SETHS administration, learning, and navigation. They may not replace human case management, facilitation, or mentorship. The human relationship is irreplaceable. The G.O.D.S Intelligence System is a tool for human enablement, not human replacement."],
      ["IX","Reintegration","The criminal justice-involved, substance-recovery, and long-term excluded population is a primary cohort of GBS-SETHS — not a tolerated edge case. The system is specifically designed to serve this population with structured, monitored, dignity-affirming support."],
      ["X","Long-Horizon Discipline","The 250-year mandate demands decisions calibrated to generational outcomes, not quarterly cycles. Short-term financial pressure does not justify programme compromise."],
      ["XI","Anti-Corruption","No GBS-SETHS franchise node, delivery operator, or employer partner may manipulate outcome data, extract learnership credits without genuine development intent, or engage in any practice that creates the appearance of compliance while defeating its purpose."],
      ["XII","Evidence-Driven","Every framework, methodology, programme design, and expansion decision must be grounded in evidence — measured outcomes, sourced data, and honest self-assessment against real-world results. G.O.D.S does not manage perceptions. It manages outcomes."],
    ],
    [480,2000,6880]
  ),
  sp(200),pb()
);

// G.O.D.S Intelligence System
C.push(
  h1("3.  The G.O.D.S. Intelligence System — Level 6"),
  p("The G.O.D.S. Intelligence System (GIS) is the artificial intelligence backbone of the entire G.O.D.S. ecosystem. It supersedes EVA (Engine for Verified Accountability) — the original UDOC-specific AI governance engine — by expanding its role from a single-division decision engine into a cross-institutional intelligence layer that serves all ten levels of the G.O.D.S. architecture simultaneously."),
  p("GIS is not a general-purpose AI chatbot. It is a constitutionally-governed, sovereign-aligned, domain-specific intelligence system designed to: govern, navigate, assess, verify, and report — at institutional scale, across all G.O.D.S. divisions and all franchise nodes globally."),
  sp(80),
  h2("3.1  GIS Core Functions"),
  tbl(
    ["Function","What GIS Does","Who It Serves"],
    [
      ["Digital Governor","Issues sealed, auditable governance decisions via UDOC. Applies constitutional pillar compliance checks to every institutional decision.","COB, Division Heads, National GBS Authorities"],
      ["Career Navigator","Assesses each GBS-SETHS participant's skills, goals, learning style, and employment barriers. Maps them to the optimal vocational pathway and employer ecosystem.","Participants (all four target cohorts)"],
      ["Digital Mentor","Provides on-demand learning support, progress monitoring, and motivational guidance to participants throughout their CET/CTE journey.","S.E.T.H.S. Participants"],
      ["Compliance Verifier","Verifies that delivery operators, employer partners, and franchise nodes are meeting constitutional and operational standards. Flags violations for COB review.","Regional GBS, Delivery Operators, Employer Ecosystem"],
      ["Research & Intelligence Engine","Tracks global AI displacement trends, labour market shifts, and regulatory developments. Surfaces intelligence to inform GBS methodology updates.","G.O.D.S. Holdings Leadership, GBS Global Council"],
      ["Outcome Auditor","Records, verifies, and reports all participant outcomes (employment, certification, retention, alumni re-entry) to UDOC's sealed audit trail.","M.A.D.I.B.A (for capital allocation), COB, DFI partners"],
      ["Franchise Intelligence","Monitors performance across all GBS franchise nodes globally. Identifies underperforming nodes, escalates to National/Regional GBS authorities.","GBS Global Council, Layer 2 National GBS"],
    ],
    [2200,3800,3360]
  ),
  sp(140),
  h2("3.2  GIS Architecture — Fail-Closed by Design"),
  box([
    p([B("Constitutional non-negotiable: "), R("G.O.D.S Intelligence System operates fail-closed. In the absence of verified sovereign authorisation, GIS defaults to BLOCK. No AI decision in the G.O.D.S. ecosystem is permitted to harm a participant, violate a constitutional pillar, or override a COB halt — regardless of system state, network condition, or operational pressure. Human primacy (Pillar VIII) is not a preference setting. It is a hard architectural constraint baked into GIS at the foundation layer.")]),
  ],LGF,AQUA),
  pb()
);

// ══════════════════════════════════════════════════════════
// PART II — GBS GLOBAL FRAMEWORK
// ══════════════════════════════════════════════════════════
C.push(
  ctr("PART  II",22,true,GD), ctr("GBS — THE GLOBAL BELIEF SYSTEM FRAMEWORK",26,true,N), hr(AQUA), sp(200), pb(),
  h1("4.  What GBS Is — and Is Not"),
  box([
    p([B("GBS is not: "), R("A religion. An ideology. A political movement. A charity. A social welfare programme.")]),
    sp(60),
    p([B("GBS is: "), R("A governance doctrine. A constitutional framework. A globally deployable standard for human development. A franchise infrastructure. The civilisational belief that every human being possesses transferable value and every society has an obligation to continuously transform human potential into measurable capability.")]),
  ],LYF,GOLD),
  sp(140),
  p("GBS operates by holding three things in tension that most institutions cannot: it is politically neutral (it works with any government), culturally adaptable (it operates within any cultural context), and constitutionally non-negotiable (its seven universal principles apply everywhere, always, without exception). The 20% localisation allowance means every franchise can adapt language, vocational pathways, and cultural delivery — the 80% constitutional framework never moves."),
  pb()
);

// 7 GBS Universal Pillars
C.push(
  h1("5.  The Seven GBS Universal Pillars"),
  p("The Seven GBS Universal Pillars define what the Global Belief System stands for at the civilisational level. They are the philosophical DNA of every GBS franchise, every GBS-SETHS cohort, every employer partner agreement, and every G.O.D.S. institutional decision. They are not S.E.T.H.S-specific (those have their own five foundational pillars). They are the human values that GBS holds as universal across every context in which it operates."),
  tbl(
    ["#","Pillar","Universal Principle","Why This Matters Globally (2026)"],
    [
      ["1","Human Value","Every individual possesses productive potential that can be developed and transferred into economic and social contribution — regardless of their prior circumstances, education level, or current situation.","In 2026, 1.2 billion young people globally are NEET (ILO). Human value is the counter-assertion to the world's growing practice of writing people off."],
      ["2","Continuous Education","Learning never ends. A qualification is not a destination — it is a milestone. The capacity to keep learning across an entire lifetime is the primary human competitive advantage against automation.","The WEF projects 44% of workers will need reskilling by 2030. Continuous education is not a GBS idealism — it is a structural economic necessity."],
      ["3","Capability Transfer","Knowledge that stays with one person has not yet fulfilled its function. The purpose of knowledge is transfer — teacher to student, mentor to mentee, generation to generation. The CET/CTE loop operationalises this principle.","Skills shortages are systemic globally. The problem is not lack of knowledge — it is inadequate transfer infrastructure. GBS fixes the infrastructure."],
      ["4","Economic Participation","Exclusion from formal economic participation is not a personal failure — it is a systemic design flaw. GBS-SETHS is designed to repair that flaw for every cohort it serves.","SA's expanded unemployment rate is 43.7% (Stats SA Q1 2026). Africa's youth bulge represents either the world's greatest opportunity or its greatest crisis — determined entirely by whether participation infrastructure exists."],
      ["5","Technological Adaptation","Technology, including AI, is a tool for human acceleration — not a replacement for human value. Every human being has the right to understand, work alongside, and benefit from technological advancement rather than be discarded by it.","85 million jobs will be displaced by automation by 2030 (WEF). The question is not whether to adapt — it is whether adaptation infrastructure exists at scale. GBS-SETHS is that infrastructure."],
      ["6","Sustainability","Human development systems that consume more than they regenerate cannot serve the 250-year mandate. The CTE loop's peer-mentor pipeline ensures GBS-SETHS grows its own delivery capacity organically, at lower marginal cost, with every cohort it serves.","Government-funded training programmes typically require perpetual budget injections. GBS-SETHS's self-replicating alumni-to-mentor pipeline is its structural sustainability mechanism."],
      ["7","Generational Continuity","The greatest measure of a human development system is not what it does in Year 1 — it is what the grandchildren of its first cohort inherit. Knowledge compounded across generations is the foundation of civilisational advancement.","The 250-year mandate exists precisely because generational continuity is the only timeframe at which systemic human exclusion can be permanently reversed, not just temporarily ameliorated."],
    ],
    [480,1800,2800,4280]
  ),
  sp(160),pb()
);

// GBS Franchise Architecture
C.push(
  h1("6.  GBS Franchise Architecture — Five Layers"),
  p("The GBS franchise model is the mechanism through which Sashin J. Singh's 2016 vision becomes a global institution. It is not a licensing arrangement in the conventional commercial sense. It is a constitutional adoption framework — every node that joins the GBS network adopts the constitutional framework and accepts the governance authority of GBS Global (Level 1)."),
  tbl(
    ["Layer","Entity","Role & Constitutional Obligations"],
    [
      ["Layer 1","GBS Global (G.O.D.S Holdings)","IP owner, constitutional authority, methodology custodian, global standards setter, royalty receiver, research engine. Every franchise node's licence flows from Layer 1. Any node not certified by Layer 1 is not a GBS node."],
      ["Layer 2","National GBS Authority","Country-level licensed operator. Localises policy, language, labour market requirements, and accreditation standards within the 20% adaptation allowance. Manages regional nodes below it. Reports all outcomes to GBS Global."],
      ["Layer 3","Regional GBS Authority","Province/state/metro operational entity. Sub-licensed from National GBS. Runs regional cohorts, manages local employer partnerships, coordinates the T.S. Industries workforce pipeline for that region."],
      ["Layer 4","S.E.T.H.S. Delivery Operators","Accredited training providers, NGOs, TVET colleges, corporate academies, rehabilitation centres, veterans programmes, prison reintegration programmes. Do not own the methodology — licensed to deliver it under Regional GBS supervision."],
      ["Layer 5","Certified Employer Ecosystems","Companies, co-operatives, government departments, T.S. Industries subsidiaries. Commit to preference-placement of GBS-SETHS graduates. Bound by the Absorption Commitment Clause. Do not hold a franchise licence but are constitutionally bound partners."],
    ],
    [900,2300,6160]
  ),
  sp(140),
  h2("6.1  GBS Franchise Governance — Audit, Compliance & Revocation"),
  tbl(
    ["Mechanism","Trigger","Process","Outcome"],
    [
      ["Annual Compliance Audit","All active nodes — mandatory","GIS-powered outcome review + COB-reviewed compliance certificate","Certification renewed or conditional status applied"],
      ["Outcome Underperformance Flag","Any node falling >20% below minimum placement benchmark for two consecutive cohorts","Regional GBS investigation + remediation plan required within 60 days","Node placed on probation; GIS monitoring intensified"],
      ["Constitutional Violation","Any breach of the 12 Pillars","Immediate COB review. GIS issues provisional BLOCK on affected node operations.","Remediation required; repeated violations = licence revocation"],
      ["Licence Revocation","Constitutional violation (repeated) or fraud","COB decision (3/5 majority). All participants transferred to adjacent node.","Node removed from GBS network; all branded materials retrieved"],
      ["Appeal Process","Any node subject to revocation","Formal submission to GBS Global within 30 days","COB final hearing; decision binding and permanent"],
    ],
    [2200,2400,2800,2160]
  ),
  sp(140),pb()
);

// ══════════════════════════════════════════════════════════
// PART III — S.E.T.H.S
// ══════════════════════════════════════════════════════════
C.push(
  ctr("PART  III",22,true,GD), ctr("S.E.T.H.S. — THE HUMAN ACCELERATION ENGINE",26,true,N), hr(AQUA), sp(200), pb(),
  h1("7.  S.E.T.H.S. — Origin, Evolution & Primary Identity"),
  p("S.E.T.H.S. began in 2016 as Seth's Empire — named for Sashin J. Singh's son, Seth, then aged three. The original concept was a recruiting agency and surety arrangement specialising in placing recovering drug addicts and parolees (minor, non-violent offences only) with client companies, using IoT-based monitoring and cyclical mental and physical stability reviews. Seth's Empire stood surety for these individuals against client contractual requirements. If no external client contracts were available, Seth's Empire would employ them directly — functioning as employer-of-last-resort, not merely placement agent."),
  p("Over the following decade, as SJS's institutional vision expanded and as AI displacement began reshaping global labour markets, S.E.T.H.S. evolved. The rehabilitation and reintegration mission remained intact — and is explicitly protected as a primary cohort in the 12 Constitutional Pillars (Pillar IX). But S.E.T.H.S.'s primary identity in the GBS-SETHS v2.0 framework is broader: it is the Human Acceleration Engine — a response to AI-driven workforce displacement that serves everyone the world's economic systems are failing to prepare for an automated future."),
  box([
    p([B("S.E.T.H.S. Primary Identity (2026 onwards): "), A("Not a skills development programme with a reintegration arm. The Human Acceleration Engine — a lifelong, constitutionally governed system that continuously moves individuals from exclusion, displacement, or stagnation toward productive participation, economic dignity, and generational contribution.")]),
  ],LGF,AQUA),
  sp(140),
  h2("7.1  The Four Target Cohorts"),
  tbl(
    ["Cohort","Population","Displacement Cause","Primary GBS-SETHS Entry Point"],
    [
      ["Cohort 1: Original (Rehabilitation & Reintegration)","People exiting the criminal justice system, substance recovery, mental health crises, domestic disruption, or long-term marginalisation","System-inflicted exclusion","Phase 0: Stabilisation & Assessment. IoT-monitored surety model. Case manager-led intake."],
      ["Cohort 2: AI Displacement","Clerks, call centre workers, bookkeepers, data entry workers, administrative staff, factory workers displaced by automation, robotics, and AI systems","Technological disruption","Phase 1: AI Awareness Module (Stage 1 of AI Workforce Adaptation Framework). Rapid pathway reassignment."],
      ["Cohort 3: Workforce Evolution","Teachers, nurses, accountants, engineers, managers, government employees — still employed but requiring adaptation skills to remain employable","Near-future technological disruption","Phase 2: AI Augmentation & Collaboration skills. Employer Ecosystem Partner delivery."],
      ["Cohort 4: Future Workforce","Students, graduates, apprentices entering a fundamentally different labour market than the one their training was designed for","Structural misalignment between education and economy","Phase 1 Stream alignment + AI Literacy Certification + Career Roadmap."],
    ],
    [1600,2400,2600,2760]
  ),
  sp(160),pb()
);

// 5 Foundational Pillars + 5 Methodology Pillars
C.push(
  h1("8.  The Complete Pillar Architecture of S.E.T.H.S."),
  p("S.E.T.H.S. operates with two distinct pillar sets — each serving a different structural function. The Five Foundational Pillars define the character of the system and the conditions under which it operates. The Five Methodology Pillars define how the system delivers its outcomes. Both sets are constitutionally binding on every GBS-SETHS delivery operator, every facilitator, and every employer partner."),
  sp(80),
  h2("8.1  The Five Foundational Pillars — Character & Commercial Foundation"),
  p([BI("\"This is what 10 years of refinement produced — not a list of values, but a structural commercial machine wearing the language of dignity.\" — Sashin J. Singh")]),
  sp(80),
  tbl(
    ["#","Pillar","Constitutional Definition","Commercial Mapping"],
    [
      ["I","HONESTY","The non-negotiable foundation. Honesty with self, employer, case manager, and system. No participant, operator, or employer can maintain an honest outcome record while falsifying it. Honesty is the only currency GBS-SETHS trades in — and it compounds.","→ Employer trust. → Contract reliability. → UDOC audit-trail integrity. → DFI confidence in outcomes data."],
      ["II","TOLERANCE","Belief cannot be imposed — only discovered. GBS-SETHS accepts every participant's belief system, background, lived failure, and personal starting point as the beginning, never a disqualifier. The system meets each person exactly where they are.","→ Cohort retention. → Long-term participant stability. → Cross-cultural franchise scalability. → Zero-attrition-for-ideology design."],
      ["III","BELIEF SYSTEMS","G.O.D.S. is a General Belief System built on what connects humanity, not what divides it. GBS-SETHS creates environments where participants of any faith, background, or worldview develop together. The system has no religious affiliation. It respects all of them.","→ Continental scalability (Africa, Asia, Middle East, Latin America). → No market access barriers based on religion or culture. → Universal adoption potential."],
      ["IV","EQUALITY","Every participant enters the programme as an equal — not in circumstance, but in potential and in how the system treats them. Structured equality in process produces measurable equality in outcome. Assessment tools are validated for cultural and demographic neutrality.","→ Certification integrity. → Credential credibility with employers. → Legal compliance (SA Employment Equity Act, international equivalents). → DFI impact measurement."],
      ["V","PRIDE","The output of the entire journey. Pride is the state in which a graduate becomes a mentor — someone who can look back at the distance they have travelled and choose to help the next person travel it too. Pride is the system's self-replication engine.","→ Long-term graduate retention in the alumni network. → Peer-mentor pipeline activation. → Brand ambassador network. → Phase 6 'door never closes' sustained engagement."],
    ],
    [480,1600,3200,4080]
  ),
  sp(160),
  h2("8.2  The Five GBS-SETHS Methodology Pillars — Operational Delivery"),
  p("The Five Methodology Pillars are the operational dimensions of the CET/CTE framework — the five things the system must build in every participant, and the five capabilities every GBS-SETHS delivery node must demonstrate it can provide. Together they spell C-E-T-H-S."),
  tbl(
    ["Pillar","Domain","Objectives","Outputs","CET/CTE Link"],
    [
      ["C — Communication","Language · Expression · Advocacy · AI Literacy","Communication literacy. Workplace language. Professional writing. Negotiation. AI interaction and prompt engineering. Team collaboration. Cultural intelligence. Leadership communication.","Graduates who can articulate their value, navigate workplace dynamics, and interface with AI tools professionally.","CET — Communicate: the act of knowledge transfer from facilitator to participant"],
      ["E — Education","Technical Skills · Certification · Career Pathways","Vocational skills in the participant's chosen stream. AI literacy. Industry certifications. Career pathway mapping. Registered under existing SAQA unit standards — evolving toward GBS-SETHS-specific accreditation as outcome data accumulates.","Competence certificates. Industry-aligned qualifications. AI Readiness Score.","CET — Educate: the structured transfer of knowledge that converts communication into capability"],
      ["T — Transportation","Physical · Digital · Opportunity Access","Employment access support. Digital connectivity access. AI and cloud tool access. Job matching and internship pipelines. T.S. Industries employment pathway for eligible graduates.","Opportunity Access: graduates connected to real employment pathways, not just qualifications without context.","CET — Transfer: technology and logistics carry the knowledge from learning environment to employment environment"],
      ["H — Human Capital","Identity · Professionalism · Entrepreneurship · Finance","Employment readiness. Entrepreneurship readiness. Financial literacy. Professional identity development. UDOC-verified digital credentials. Banking and formal economic inclusion.","Economic Capability: graduates who function as productive formal economic participants — employed, self-employed, or entrepreneurial.","CTE — Carry: the graduate carries their developed human capital into the economy"],
      ["S — Sustainability","Alumni · Mentorship · Re-entry · Lifelong Learning","Alumni network engagement. Peer mentor pathway access. Phase 6 re-entry guarantee. Continuous upskilling module access. GBS-SETHS 'Skills Passport' — a verifiable lifetime record of all development achieved.","Lifetime Adaptability: graduates who can navigate future disruption because the system never closed the door.","CTE — Evolve: the system evolves as alumni accumulate real-world experience and return it to the next cohort"],
    ],
    [1800,1900,2800,2000,960]
  ),
  sp(160),pb()
);

// CET/CTE + AI Framework
C.push(
  h1("9.  The CET/CTE Operating System"),
  p("The CET/CTE framework is the intellectual core of GBS-SETHS — a continuous knowledge transfer methodology first articulated in Chapter 10 of SJS's published memoir 'Confessions of an Addict (He'll Never Change)' (novum publishing, 2025) under the title 'The Theory of Exposure.' It is the framework that transforms a training programme into a living, self-replicating human acceleration engine."),
  box([
    p([B("CET — Knowledge Transfer Phase: "), R("A teacher communicates knowledge → Technology carries it → A student learns it.")]),
    sp(60),
    p([B("CTE — Opportunity Exposure Phase: "), R("A student carries knowledge into the world → Transfers it to the next learner → Evolves it through real-world application.")]),
    sp(60),
    p([B("Combined Loop: "), BI("CET → CTE → Reflection → Assessment → Upskilling → Repeat — until Employment, Entrepreneurship, Leadership, or Mentorship.")]),
    sp(60),
    p([BI("\"Not an AI engine. A human acceleration engine.\" — Sashin J. Singh, 2016")]),
  ],LGF,AQUA),
  sp(120),
  tbl(
    ["Stage","Name","Duration","Key Activity","Output"],
    [
      ["0","Stabilisation & Assessment","Weeks 1–2","Intake profiling. Safety assessment (Cohort 1). AI displacement mapping (Cohort 2/3). Cohort assignment. Self-Affirmation Contract.","Participant profile. Vocational pathway assignment."],
      ["01","CET — Communicate","Weeks 3–6","Foundation skills: literacy, numeracy, communication, AI literacy basics. Case manager relationship established.","Foundation competence. Communication baseline."],
      ["02","CET — Educate","Weeks 7–18","Core vocational stream + AI skills + financial literacy + professional identity. Mentorship matching.","Employer-readiness certification. Portfolio of evidence."],
      ["03","CET — Transfer","Weeks 19–24","Active placement support. Employer activation. Case manager monitoring. T.S. Industries pipeline.","Verified employment commencement."],
      ["04","Assessment","Week 25, Month 3, Month 6","30/60/90-day employment outcome verification. UDOC sealed audit trail. COB quarterly report.","Primary outcome metrics. GIS outcome record."],
      ["05","Deployment","Months 6–12","Upskilling module access. Employer check-ins. Cohort reunion. AI adaptation support.","Employment retention. Income growth. Skills Passport update."],
      ["06","Employment","Continuous","Participant in formal employment accessing ongoing support.","Economic participation data. M.A.D.I.B.A. impact metric."],
      ["07","Mentorship","Month 6 onwards","Eligible alumni invited to peer-mentor pathway. Stipended mentorship roles.","Peer mentor pool — the system's next CET delivery layer."],
      ["08","Phase 6: The Door Never Closes","Perpetual","Alumni re-entry at any life stage. No time limit. No reason required.","Generational knowledge transfer. System self-replication."],
    ],
    [600,2000,1500,2600,2660]
  ),
  sp(160),pb()
);

// AI Adaptation Framework
C.push(
  h1("10.  AI Workforce Adaptation Framework — Five Stages"),
  p("The AI Workforce Adaptation Framework is the structured response to AI-driven labour market displacement — applicable to Cohort 2 (displaced workers), Cohort 3 (adaptation-needing employed workers), and Cohort 4 (future workforce). It runs as a parallel track through the CET/CTE system, with each stage integrated into the relevant phase of the participant's development journey."),
  tbl(
    ["Stage","Name","Core Questions","GBS-SETHS Delivery","Output"],
    [
      ["1","AI Awareness","What jobs are changing? What tasks are automated? What skills remain valuable?","Phase 01 (CET-Communicate). Group sessions. GIS-powered sector displacement analysis specific to participant's prior field.","Personal AI Displacement Map. Sector-specific awareness."],
      ["2","AI Augmentation","How does AI assist? How does it accelerate? How does it complement human work?","Phase 02 (CET-Educate). Hands-on AI tool workshops. Prompt engineering basics. 'Human + AI' workflow design.","AI Augmentation Certification. Tool proficiency."],
      ["3","AI Collaboration","How do I redesign my workflow? How do I supervise AI outputs? How do I maintain oversight?","Phase 02-03. Advanced AI integration projects. UDOC governance literacy (how AI decisions are audited).","AI Collaboration Portfolio. Workflow redesign evidence."],
      ["4","Career Evolution","What adjacent careers are emerging? What new industries are growing? Where do my human skills transfer?","Phase 03-04 (CET-Transfer). GIS Career Navigator. T.S. Industries sector introduction. M.A.D.I.B.A entrepreneurship pathways.","Personal Career Roadmap. Adjacent pathway identified and activated."],
      ["5","Continuous Reinvention","How do I stay adaptable for the next decade? What does my lifelong learning plan look like?","Phase 05 onwards + Phase 6 (perpetual). Skills Passport. Annual AI Readiness Score update. GBS-SETHS upskilling module library access.","GBS-SETHS Skills Passport. Lifelong Learning Plan. AI Readiness Score (updated annually)."],
    ],
    [600,2000,2400,2600,1760]
  ),
  sp(160),
  h2("10.1  The GBS-SETHS Skills Passport"),
  box([
    p([B("Every GBS-SETHS participant receives a Skills Passport — a UDOC-issued, GIS-verified, digitally portable credential record that:")]),
    blt("Records every qualification, certification, and competency achievement across their lifetime"),
    blt("Is verifiable by any employer, education institution, or government agency via UDOC's sealed audit trail"),
    blt("Includes an annually-updated AI Readiness Score (baseline, augmentation, collaboration, evolution)"),
    blt("Travels with the participant permanently — regardless of which GBS-SETHS node they accessed or in which country"),
    blt("Cannot be falsified, deleted, or altered by any party other than GIS, under constitutional governance oversight"),
    blt("Is owned by the participant, not by the delivery operator, employer, or national GBS authority"),
  ],LGF,AQUA),
  pb()
);

// ══════════════════════════════════════════════════════════
// PART IV — UDOC & GIS
// ══════════════════════════════════════════════════════════
C.push(
  ctr("PART  IV",22,true,GD), ctr("UDOC — THE GOVERNANCE & INTELLIGENCE BACKBONE",26,true,N), hr(AQUA), sp(200), pb(),
  h1("11.  UDOC — Unified Digital Oversight & Coordination"),
  p("UDOC is GBS-SETHS's constitutional nervous system — the platform that makes every governance decision auditable, every outcome verifiable, and every constitutional obligation enforceable across all franchise nodes, all delivery operators, and all employer partnerships globally. UDOC transforms G.O.D.S.'s constitutional principles from words on paper into system-enforced operating standards."),
  p("UDOC's backend is live and confirmed operational: gods-platform-core.onrender.com, Neon Postgres, 72 API routes deployed and tested, governance-gate enforcement and sealed audit decisions issuing in production. The capstone-level build demonstrates the architecture; the commercial platform build commences at seed capital close."),
  sp(80),
  h2("11.1  UDOC Nine-Module Architecture"),
  tbl(
    ["Module","Name","Function in GBS-SETHS Context"],
    [
      ["M1","Identity Layer","Participant onboarding, profile creation, Skills Passport initialisation, cohort assignment. Verifies identity against applicable national KYC requirements."],
      ["M2","Education Layer","Curriculum delivery tracking, assessment recording, certification issuance, vocational pathway progression monitoring."],
      ["M3","Mentorship Layer","Peer mentor matching, mentorship session logging, alumni re-entry tracking, Phase 6 engagement management."],
      ["M4","Placement Layer","Employer ecosystem interface, job matching, internship pipeline management, T.S. Industries workforce pipeline."],
      ["M5","Analytics Layer","Cohort outcome tracking, delivery operator performance monitoring, franchise node benchmarking, GBS Global reporting dashboard."],
      ["M6","Certification Layer","UDOC-issued digital credentials, Skills Passport updates, AI Readiness Score tracking, employer-verifiable certification."],
      ["M7","Economic Layer","M.A.D.I.B.A capital allocation triggers, outcome-based funding verification, impact bond performance data, B-BBEE compliance tracking."],
      ["M8","AI Governance Layer","G.O.D.S. Intelligence System interface. Constitutional pillar compliance checks on all institutional decisions. Sealed governance decisions. COB dashboard."],
      ["M9","Compliance Layer","Delivery operator certification records, employer Absorption Commitment Clause compliance, franchise audit trail, constitutional violation flag system."],
    ],
    [500,2400,6460]
  ),
  sp(160),pb()
);

// ══════════════════════════════════════════════════════════
// PART V — M.A.D.I.B.A
// ══════════════════════════════════════════════════════════
C.push(
  ctr("PART  V",22,true,GD), ctr("M.A.D.I.B.A — THE CAPITAL ENGINE",26,true,N), hr(AQUA), sp(200), pb(),
  h1("12.  M.A.D.I.B.A — My African Dream Is Being Achieved"),
  p("M.A.D.I.B.A is the capital deployment and sovereignty alignment division of G.O.D.S Holdings. It serves as the institution's interface with DFIs, impact investors, government funders, and the broader African capital ecosystem — mobilising the patient, outcome-aligned capital that GBS-SETHS requires to operate at the scale its mission demands."),
  h2("12.1  The GBS-SETHS Capital Model"),
  tbl(
    ["Revenue Stream","Source","Structure","GBS-SETHS Link"],
    [
      ["National Franchise Licence","National GBS (Layer 2)","Upfront licence fee + annual renewal + cohort revenue share to GBS Global","Funds GBS Global research, methodology evolution, and constitutional governance"],
      ["Government Outcomes-Based Funding","SETA, EPWP, DSD, DCS, DoL","Per-verified-employment-outcome payment. PFMA/MFMA compliant. Section 217 Constitution of SA.","Primary funding for cohort delivery in South Africa Phase 1"],
      ["DFI & Impact Capital","DBSA, IDC, AfDB, IFC, PIC (Isibaya)","Impact bond structure. UDOC-verified outcome data triggers payment tranches.","Seed and scale capital. M.A.D.I.B.A holds the GP relationship."],
      ["Employer Partnership Fees","Layer 5 Certified Employer Ecosystem","Annual fee for preferred GBS-SETHS graduate pipeline access + UDOC-verified candidate assessments","Partial operational cost offset + employer relationship management"],
      ["B-BBEE Skills Development Credits","Host employers (SA)","Employers earn B-BBEE scorecard points. Absorption Commitment Clause mandatory.","Closes the learnership-credit-extraction gap SJS identified through lived experience"],
      ["Royalty Income","International GBS franchise network","% of cohort revenue from national franchise operators flowing to GBS Global","Long-term institutional sustainability; begins flowing from Phase 4 (international expansion)"],
    ],
    [2400,2600,3000,1360]
  ),
  sp(140),
  h2("12.2  Independent Validation — PIC April 2026"),
  box([
    p([B("Third-party validation (unsolicited, April 2026): "), R("The Public Investment Corporation — Africa's largest asset manager with R2.69 trillion under management — published a research paper proposing the transformation of TVET colleges into investable social infrastructure through blended PPP partnerships, with private operators paid against employment-outcome performance metrics.")]),
    sp(60),
    p([R("This is strikingly close to the GBS-SETHS/M.A.D.I.B.A model — human capital development funded through blended government/DFI/private capital, delivered via a constitutionally-governed franchise, with outcome-based payment structures. This paper did not reference G.O.D.S. or SJS. It arrived independently, from one of Africa's most credible institutional voices. It is the most powerful piece of external validation the GBS-SETHS thesis has, and should be cited prominently in every investor or government conversation.")]),
  ],LYF,GOLD),
  pb()
);

// ══════════════════════════════════════════════════════════
// PART VI — CONTINENTAL DEPLOYMENT
// ══════════════════════════════════════════════════════════
C.push(
  ctr("PART  VI",22,true,GD), ctr("CONTINENTAL DEPLOYMENT FRAMEWORK",26,true,N), hr(AQUA), sp(200), pb(),
  h1("13.  GBS Global Standard — Four Deployment Layers"),
  p("Every GBS franchise deployment — regardless of country, culture, or regulatory environment — operates across four layers of standard. The Core Layer is universal and non-negotiable. The three adaptive layers give franchise nodes the flexibility to be locally relevant without compromising constitutional integrity."),
  tbl(
    ["Layer","Name","What It Contains","Who Controls It"],
    [
      ["Core Layer","Universal GBS-SETHS Standard","7 GBS Universal Pillars. 5 S.E.T.H.S Foundational Pillars. 5 GBS-SETHS Methodology Pillars. CET/CTE Operating System. Skills Passport. UDOC governance requirements. Constitutional compliance obligations. Phase 6 guarantee.","GBS Global (Layer 1). Non-negotiable. Applies everywhere, always."],
      ["Country Layer","National Adaptation","Local language of delivery. Local labour law compliance. National accreditation framework alignment (SA: SAQA/SETA; Kenya: NITA; UAE: KHDA; Germany: BIBB). Local cultural protocols in facilitation style.","National GBS Authority (Layer 2). Within 20% adaptation allowance."],
      ["Industry Layer","Sector Adaptation","Vocational pathway alignment to dominant local industries. Mining (SA, Zimbabwe). Healthcare (UK, Germany). Digital (Kenya, India, UAE). Agriculture (SADC, Latin America). Manufacturing (Asia, Latin America).","Regional GBS Authority (Layer 3) + Employer Ecosystem input."],
      ["Community Layer","Micro-Context Adaptation","Rural vs urban delivery mode. Tribal community protocols. Remote digital delivery vs physical cohort. Refugee and asylum-seeker specific intake processes. Informal settlement specific support structures.","Delivery Operator (Layer 4) under Regional GBS supervision."],
    ],
    [1300,2400,3700,2160]
  ),
  sp(140),
  h2("13.1  Seven-Region Continental Deployment Strategy"),
  tbl(
    ["Region","Primary Deployment Challenge","GBS-SETHS Entry Strategy","T.S. Industries Alignment"],
    [
      ["Africa (SA, SADC, East Africa)","Youth unemployment crisis (SA: 60.9% ages 15-24, Q1 2026). NEET population. Skills mismatch. AI displacement of formal entry-level roles.","Phase 1: SA pilot. Phase 2: SADC expansion (Botswana, Zimbabwe, Namibia, Mozambique). Phase 3: East Africa (Kenya, Tanzania, Rwanda). Layer 2 licence to credible existing workforce authority.","Renewable energy (REIPPPP model). Construction (housing backlog). Agriculture. T.S. Industries SPVs are primary employer pipeline for African cohorts."],
      ["Europe (UK, Germany, Netherlands)","AI displacement of white-collar roles. Aging workforce. Migration integration. Reskilling demand from workers whose roles are being automated.","Social enterprise / CIC structure. Partner with national employment agencies (UK: DWP; Germany: Bundesagentur für Arbeit). Focus: AI Adaptation (Cohort 2 and 3).","Digital infrastructure. Green energy. Manufacturing (Industry 4.0 transition support)."],
      ["North America (USA, Canada)","Automation-driven workforce transition. Trade skills shortage. Veterans reintegration. Justice-involved population reintegration.","Strategic partnership with existing national workforce development organisations. Focus: AI Adaptation + Cohort 1 (justice-involved). GBS-SETHS as the quality/outcomes layer.","Construction (infrastructure investment cycles). Digital. Logistics."],
      ["Asia (India, Southeast Asia)","Mass capability development need. 1.4 billion population. Digital economy growth. Rural-urban skills transition.","National GBS licence to government-aligned workforce development authority. Focus: Cohort 4 (future workforce). Digital and manufacturing streams.","Digital infrastructure. Manufacturing. AgriTech."],
      ["Middle East (UAE, Saudi Arabia, Qatar)","Economic diversification away from oil dependency. Localisation mandates (SA's Vision 2030, UAE's Emiratisation). AI readiness agenda.","Strategic partnership with national workforce authorities. Shariah-compliant financial literacy module. UAE: KHDA accreditation pathway.","Digital infrastructure. Renewable energy. Smart city construction."],
      ["Latin America (Brazil, Colombia, Mexico)","Economic mobility. Informal economy formalisation. Youth unemployment. Rural-urban transition.","NGO consortium partnerships. Focus: Cohort 1 (reintegration) + Cohort 4 (future workforce). Spanish/Portuguese curriculum localisation.","Agriculture. Manufacturing. Logistics."],
      ["Oceania (Australia, Pacific Islands)","Remote community development. Indigenous community economic participation. Digital inclusion.","University partnership model. Focus: remote digital delivery. Indigenous community cultural protocols integrated into Community Layer adaptation.","Construction (remote infrastructure). Digital. Agriculture."],
    ],
    [1600,2600,2900,2260]
  ),
  pb()
);

// ══════════════════════════════════════════════════════════
// PART VII — 250-YEAR ROADMAP
// ══════════════════════════════════════════════════════════
C.push(
  ctr("PART  VII",22,true,GD), ctr("THE 250-YEAR STRATEGIC ROADMAP",26,true,N), hr(AQUA), sp(200), pb(),
  h1("14.  The 250-Year Strategic Roadmap — Five Civilisational Phases"),
  p("The 250-year mandate is not a guarantee of G.O.D.S. Holdings' survival — no institution can guarantee 250 years. It is a planning discipline. Systems designed for 250 years make fundamentally different architectural choices than systems designed for 5 years. The constitutional IP Trust, the COB with founder-removal authority, the Phase 6 lifetime re-entry guarantee, the franchise architecture with built-in succession protocols — these are 250-year engineering decisions, not marketing features."),
  tbl(
    ["Phase","Timeline","Name","Primary Objectives","Key Milestones"],
    [
      ["I","0–25 Years (2026–2051)","Foundation","Prove the model. Establish credibility. Build the evidence base. Secure the constitutional foundation.","First cohort of 50 (SA, Year 1). National scale SA (3 nodes, Year 3). First international node (Year 5). FSCA FSP licence granted. M.A.D.I.B.A first LP close. UDOC commercial platform live. First GBS Global Council constituted. SAQA petition for GBS-SETHS-specific unit standards filed. PIC, DBSA, IDC formal relationships established."],
      ["II","25–50 Years (2051–2076)","Expansion","Scale globally. Build the franchise network. Activate the peer-mentor replication engine. Establish GBS as a recognised global human development standard.","20+ National GBS nodes. 100,000+ graduates. GBS-SETHS accreditation recognised internationally (ILO framework partnership). GBS Global Council operating as a genuine international standards body. M.A.D.I.B.A endowment fund reaching self-sustaining scale. T.S. Industries operating in 5+ countries."],
      ["III","50–100 Years (2076–2126)","Institutionalisation","Embed GBS-SETHS into national education and workforce policy frameworks. Become the standard against which workforce development programmes are measured globally.","GBS-SETHS integrated into national skills development policy in 10+ countries. GIS updated to reflect five decades of outcome data. Second generation of founders succeeding the first. Constitutional amendments process first tested and passed. 1M+ lifetime graduates. First documented second-generation cohort members (grandchildren of original cohort)."],
      ["IV","100–150 Years (2126–2176)","Global Integration","Universal adoption framework. GBS principles embedded in international human development standards (UN SDGs successor frameworks). Cross-civilisational knowledge transfer at scale.","GBS represented at multilateral human development policy forums. GBS-SETHS Skills Passport recognised across 50+ national borders. Continental Deployment Framework covering all seven regions fully operational. M.A.D.I.B.A managing multi-billion AUM. 10M+ lifetime graduates."],
      ["V","150–250 Years (2176–2276)","Civilisational Continuity","The knowledge compounding function reaches generational depth. GBS-SETHS is no longer a programme — it is permanent civilisational infrastructure, as unremarkable and essential as roads, schools, and hospitals.","GBS-SETHS operates in most countries. Generational knowledge transfer measurable across 5+ generations. Outcomes data spanning centuries informs ongoing methodology evolution. The original 12 Constitutional Pillars remain the governing foundation — amended only through the constitutional process they specify."],
    ],
    [700,2200,1900,2400,2160]
  ),
  sp(160),
  box([
    p([B("On the 250-year mandate — a note from the architect: ")]),
    p([BI("\"I once told you I have an IQ higher than everything on earth combined but you failed to recognize it was far from being truth on your statistical evaluation off me. So why would I over inflate myself when I clearly expressed honestly truth? This project was built in honesty — and honesty is the only foundation on which a 250-year institution can be built.\"")]),
    sp(60),
    p([R("The 250-year mandate is the difference between a programme and infrastructure. Programmes solve today's problems. Infrastructure creates the conditions in which every generation can solve its own problems, with compounded advantage from every generation that came before it. That is what GBS-SETHS is designed to be.")]),
  ],LGF,AQUA),
  pb()
);

// CLOSING
C.push(
  h1("15.  Closing — What This Framework Is and Is Not"),
  tbl(
    ["This framework IS","This framework is NOT"],
    [
      ["The first complete institutional articulation of GBS-SETHS — v2.0, expanded from v1.0 to include the full 10-level G.O.D.S. architecture, 7 GBS Universal Pillars, AI Workforce Adaptation Framework, four-cohort model, GIS architecture, and seven-region deployment strategy","A final product. Every cohort run, every outcome measured, every country entered, and every mentor produced will enrich and evolve it."],
      ["A framework built on a decade of SJS's original intellectual development — grounded in lived experience, systematic research, and genuine conviction that the world's exclusion of its most marginalised people is a design failure, not a human failure","An AI-generated start-up. AI structured, clarified, and amplified this work. The ideas, the pillars, the conviction, and the decade of commitment belong to Sashin J. Singh."],
      ["A constitutionally governed, globally deployable, franchise-ready institutional framework capable of attracting DFI, government, and impact capital from Day 1","A guarantee of funding, scale, or success. G.O.D.S. holds the framework. The market holds the decision."],
      ["A framework designed to outlast its founder — by explicit architectural choice — so that Seth Singh and every generation after him inherits an institution, not a dependency","A personalised solution. GBS-SETHS is designed to work without SJS at the centre — and that is precisely the quality that makes it institutional rather than entrepreneurial."],
    ],
    [4680,4680]
  ),
  sp(200),hr(),sp(120),
  ctr("GBS-SETHS v2.0  ·  G.O.D.S Holdings (Pty) Ltd  ·  IP Trust Protected  ·  July 2026",17,false,GREY),
  ctr("All intellectual property held in the G.O.D.S. IP Trust under the Trust Property Control Act 57 of 1988",15,false,GREY),
  ctr("Founder & Architect: Sashin J. Singh  ·  sashin.singh@outlook.com  ·  capstoneprojectsjs.netlify.app",15,false,GREY),
);

// ─── ASSEMBLE ─────────────────────────────────────────────
const doc = new Document({
  numbering:{config:[{reference:"bullets",levels:[{level:0,format:LevelFormat.BULLET,text:"\u2022",alignment:AlignmentType.LEFT,style:{paragraph:{indent:{left:540,hanging:270}}}}]}]},
  styles:{
    default:{document:{run:{font:"Arial",size:21,color:NT}}},
    paragraphStyles:[
      {id:"Heading1",name:"Heading 1",basedOn:"Normal",next:"Normal",quickFormat:true,run:{size:32,bold:true,color:N,font:"Arial"},paragraph:{spacing:{before:360,after:200},border:{bottom:{style:BorderStyle.SINGLE,size:8,color:GOLD,space:4}}}},
      {id:"Heading2",name:"Heading 2",basedOn:"Normal",next:"Normal",quickFormat:true,run:{size:26,bold:true,color:GD,font:"Arial"},paragraph:{spacing:{before:280,after:140}}},
      {id:"Heading3",name:"Heading 3",basedOn:"Normal",next:"Normal",quickFormat:true,run:{size:22,bold:true,italics:true,color:NT,font:"Arial"},paragraph:{spacing:{before:200,after:100}}},
    ]
  },
  sections:[{
    properties:{page:{size:{width:12240,height:15840},margin:{top:1260,right:1440,bottom:1260,left:1440}}},
    headers:{default:new Header({children:[new Paragraph({alignment:AlignmentType.RIGHT,children:[new TextRun({text:"GBS-SETHS v2.0  ·  G.O.D.S. Holdings Global Human Acceleration Framework",size:15,color:GREY,italics:true,font:"Arial"})]})]})},
    footers:{default:new Footer({children:[new Paragraph({alignment:AlignmentType.CENTER,children:[new TextRun({text:"G.O.D.S Holdings (Pty) Ltd  ·  IP Trust Protected  ·  July 2026  ·  Page ",size:15,color:GREY,font:"Arial"}),new TextRun({children:[PageNumber.CURRENT],size:15,color:GREY,font:"Arial"})]})]})},
    children:C
  }]
});

Packer.toBuffer(doc).then(buf=>{
  fs.writeFileSync("/home/claude/GBS_SETHS_Framework_v2.docx",buf);
  console.log("GBS-SETHS v2.0 built. Elements: "+C.length);
}).catch(e=>{console.error("BUILD ERROR:",e);process.exit(1);});
