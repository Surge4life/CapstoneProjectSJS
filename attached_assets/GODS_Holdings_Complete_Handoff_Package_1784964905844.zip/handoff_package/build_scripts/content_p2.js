const H = require("/home/claude/helpers.js");
const { h1, h2, h3, body, bold, ital, plain, goldBold, flagBold, navyBold, bullet, hr, calloutBox, flagBox, spacer, makeTable, pageBreak, AlignmentType, Paragraph, TextRun } = H;

function buildMarketSection() {
  const c = [];
  c.push(h1("2.  The market: what is real today, division by division"));
  c.push(body("AI governance has crossed from concept to budget line; so have the other three categories G.O.D.S operates in, each years or decades ahead of UDOC's. The shift in every case is driven by enforcement deadlines, fiscal pressure, or both \u2014 not goodwill. That is what converts each category from a nice-to-have into a purchase order, an SPV term sheet, or an LP commitment."));

  // ---- 2.1 UDOC market ----
  c.push(h2("2.1  UDOC \u2014 AI governance software"));
  c.push(body("Gartner projects fragmented AI regulation will reach roughly 75% of the world's economies by 2030, and over 43% of public companies now disclose AI risk in annual filings."));
  c.push(makeTable(
    ["Source", "2025/26 size", "Forecast", "CAGR"],
    [
      ["Gartner (Feb 2026)", "~$492m (2026)", ">$1bn by 2030", "\u2014"],
      ["Grand View Research", "$417.8m (2026)", "$3.59bn by 2033", "36.0%"],
      ["Precedence Research", "$419.5m (2026)", "$5.88bn by 2035", "34.3%"],
      ["The Business Research Co.", "$0.61bn (2026)", "$2.63bn by 2030", "44.3%"],
      ["Wissen Research", "$750m (2024)", "$5.64bn by 2030", "40.0%"],
    ],
    [2600, 2400, 2400, 1960]
  ));
  c.push(spacer(120));
  c.push(body("Funded reality is more sober than the forecasts: ~USD 281m raised by pure-play AI-governance companies across 17 disclosed rounds in the 12 months to April 2026 \u2014 16 unique companies, median round USD 15m, only one deal above USD 50m. South Africa's own Draft National AI Policy (Gazette 54477, 10 April 2026) chooses a sector-specific, multi-regulator model with full implementation only in 2027/28 \u2014 a real tailwind, but not yet."));

  // ---- 2.2 S.E.T.H.S market ----
  c.push(h2("2.2  S.E.T.H.S \u2014 workforce reintegration & human-capacity acceleration"));
  c.push(body("The crisis underneath S.E.T.H.S is large and getting worse, not better, on the latest data. Stats SA's Q1 2026 Quarterly Labour Force Survey put the official national unemployment rate at 32.7%, up from 31.4% the previous quarter \u2014 8.1 million people unemployed on the narrow definition. Youth unemployment (ages 15\u201324) sits at 60.9%, with the 25\u201334 band at 40.6%. The expanded definition, which adds discouraged work-seekers to the count, runs materially higher: 43.7% nationally (the combined rate of unemployment and potential labour force, Stats SA's LU3 measure). Separately, the NEET rate \u2014 young people not in employment, education, or training, a different and broader measure than unemployment \u2014 stands at 37.6% for ages 15\u201324 (3.9 million people) and 45.6% for ages 15\u201334."));
  c.push(flagBox("Note on which figure to cite where", [
    body("This report uses the official rate (32.7% national, 60.9% youth) as the primary citation because it is the figure most consistently reported and most directly comparable across G.O.D.S's existing materials. The live website's investor-facing copy currently leads with the expanded rate (\u201C43.1% expanded\u201D), which is close to but not an exact match for the verified Stats SA LU3 figure of 43.7% found in this research pass. Both the official and expanded rates are real, named, dated Stats SA measures \u2014 they answer different questions. Recommend G.O.D.S standardise on one primary figure (with the other available as a footnote) across the website, this report, and all pitch materials, so the same number doesn't appear to shift between documents."),
  ]));
  c.push(body("This is not a market G.O.D.S would be entering uncontested. South Africa already has a national-scale, government-adopted workforce platform, several structurally similar alternative-education models, and an active government learnership/SETA apparatus that S.E.T.H.S itself plans to register under in its early years."));
  c.push(h3("Named comparables"));
  c.push(makeTable(
    ["Player", "Status & scale", "Funding model", "What S.E.T.H.S would need to differentiate on"],
    [
      ["Harambee / SA Youth", "Dominant national platform. Founded 2011. 5m+ youth engaged via the SA Youth platform; 876,131 verified new income opportunities created; ~4.5m work-seekers supported.", "Grant-funded: National Treasury Jobs Fund + Skoll Foundation + corporate partners. Disclosed VC total only ~$1.5m \u2014 this is not equity-raised capital.", "Scale. Harambee operates at a different order of magnitude; S.E.T.H.S cannot credibly claim to out-scale it."],
      ["WeThinkCode", "Closest structural analog. NQF5-accredited, ~2-year \u201Cstackable skills\u201D model. ~1,867 youth through the programme; 81% placement rate.", "Mixed: corporate sponsorship, donor funding, some fee-for-service.", "S.E.T.H.S is broader than coding \u2014 5 streams vs. one tech vertical \u2014 but is unproven at any scale WeThinkCode has already reached."],
      ["YES (Youth Employment Service) / YES4Youth", "Government-recognised national initiative; 12-month corporate-hosted placements tied to B-BBEE scorecard incentives.", "Corporate-funded via the same B-BBEE/learnership incentive structure S.E.T.H.S's own founder has lived the downside of.", "S.E.T.H.S's lifetime-continuity model (the proposed \u201Cdoor never closes\u201D phase) is a genuine point of difference \u2014 YES's incentive ends when the 12-month placement ends."],
      ["Zaio / Shaper (Digital Academy) / UVU Africa", "Sector-specific bootcamps and digital-skills NGOs, single-vertical (mostly tech/digital), smaller cohort sizes.", "Mixed donor, corporate, and fee-for-service.", "Narrower scope than S.E.T.H.S's 5-stream model; not direct competitors so much as adjacent single-vertical players."],
      ["Government BEEI Phase V", "State-run basic education employment initiative, 200,000+ job target.", "Public budget (EPWP-linked).", "Public-sector scale S.E.T.H.S cannot match without becoming a government programme itself \u2014 which is explicitly not the model."],
    ],
    [1750, 2850, 2300, 2460]
  ));
  c.push(spacer(120));
  c.push(body("Bottom line: S.E.T.H.S cannot credibly position itself as filling an empty category \u2014 workforce reintegration in South Africa is served, at scale, by grant-funded national infrastructure. The defensible position, consistent with G.O.D.S's own four-division thesis, is that S.E.T.H.S is not a standalone bootcamp competing with Harambee for the same funders; it is the human-supply leg of an integrated loop feeding T.S Industries, governed by UDOC, capitalised by M.A.D.I.B.A \u2014 a combination none of the comparables above attempt."));

  c.push(h3("A genuine, current tailwind worth using: AI-driven trade redirection"));
  c.push(body("One emerging 2026 labour-market narrative is directly useful to S.E.T.H.S's positioning and is not yet reflected anywhere in G.O.D.S's existing documents. Multiple independent 2026 sources \u2014 IMD's workplace trends report, WEF's Future of Jobs data, and direct commentary from technology executives \u2014 converge on the same observation: white-collar, entry-to-mid-level office roles are the segment most exposed to near-term AI displacement, while skilled trades remain comparatively insulated. IMD's 2026 report states plainly that \u201Cskilled trades \u2014 plumbers, electricians, farmers, cement masons \u2014 remain largely insulated from AI disruption,\u201D and cites Nvidia CEO Jensen Huang's remark that \u201Cthe next millionaires will be plumbers and electricians rather than techies.\u201D A documented \u201Ccollar switch\u201D trend is visible in 2026 reporting \u2014 white-collar workers retraining into trades amid layoffs and AI-driven wage compression in routine cognitive roles. Even Meta has launched a dedicated reskilling-to-trades initiative (\u201CAmerica's Workforce Academy\u201D) in direct response to its own AI-driven white-collar headcount reductions."));
  c.push(body([plain("This is "), bold("global context, not South African data"), plain(" \u2014 it should not be cited as if it were a measured local trend. But as a positioning thesis, it sharpens S.E.T.H.S's existing pitch (\u201Caccreditation for redundant office tasks is a wasted opportunity; trade and infrastructure skills are not\u201D) with real, dated, named 2026 sources, and it is a framing none of S.E.T.H.S's South African comparables above are currently using.")]));

  // ---- 2.3 T.S Industries market ----
  c.push(h2("2.3  T.S Industries \u2014 production & infrastructure"));
  c.push(body("T.S Industries is not entering a single market \u2014 it spans seven planned subsidiaries (Energy, Construction, AgriTech, Water, Digital Infrastructure, Manufacturing, Logistics), each with its own established players. The honest framing is that no single comparable spans all seven the way T.S claims it eventually will; T.S's edge, if it has one, is the integration and the dedicated S.E.T.H.S workforce pipeline \u2014 not first-mover status in any one subsector."));
  c.push(makeTable(
    ["Sub-sector", "Sourced market reality", "Named established players"],
    [
      ["Energy (REIPPPP)", "R256bn in private investment committed since inception; 7,300+MW installed across 95+ projects. Bid Window 7 alone: R31.4bn, 1,760MW, 8 preferred bidders, 49% SA equity participation, 46% average B-BBEE participation, 6,971 job-years.", "Red Rocket, Mulilo, Scatec, ACWA Power, Pele Green Energy, Abo Wind \u2014 all multi-hundred-MW developers with completed REIPPPP rounds behind them."],
      ["Construction (modular/affordable housing)", "SA's housing backlog is measured in millions of units; the 2026/27 Budget commits R1.07 trillion to public infrastructure over 3 years against an estimated ~R4 trillion infrastructure funding gap (STANLIB).", "Kwikspace (Africa's largest modular/prefab manufacturer, 50+ years operating), Afripanel (CIDB/NHBRC/Agr\u00E9ment-certified, claims ~30% cost reduction vs. traditional builds), Karmod (international, 3,000\u20135,000-unit pipelines across several African countries)."],
      ["Digital Infrastructure / sovereign cloud", "Directly adjacent to UDOC's own sovereignty thesis; competes for the same government-trust narrative UDOC relies on.", "Hyperscalers (AWS, Azure, Google Cloud) dominate by default; no Africa-sovereign equivalent currently operates at scale \u2014 this is the one T.S sub-sector where the \u201Cempty niche\u201D claim is closest to true, mirroring UDOC's own sovereignty argument."],
      ["AgriTech, Water, Manufacturing, Logistics", "Each individually has active commercial players (vertical farming operators, NRW/smart-metering specialists, local-content manufacturers, last-mile logistics platforms) \u2014 not separately profiled here given T.S has not yet activated any of these (Year 2+ in its own roadmap).", "Not yet researched at the same depth \u2014 flagged for a future pass once T.S's own sequencing reaches these sub-sectors."],
    ],
    [2000, 3600, 3760]
  ));
  c.push(spacer(120));
  c.push(body("The SPV co-ownership model T.S proposes \u2014 government and/or fund co-investment alongside T.S equity \u2014 is not a novel structure. It is the same model REIPPPP itself runs on, and the same model Ninety One's Emerging Africa & Asia Infrastructure Fund (EAAIF) has used since 2001 to commit over $3bn in loans to 125+ infrastructure projects across 25+ countries, carrying an A2 Moody's rating. The Development Bank of Southern Africa's new Ifisa vehicle (live from April 2026) exists specifically to mobilise exactly this kind of blended private capital into infrastructure. None of this invalidates T.S's model \u2014 if anything, it validates the mechanism \u2014 but it means T.S is proposing to use a proven structure, not invent one, and will be evaluated against operators who have been running that structure for two decades."));
  c.push(body([plain("The strongest third-party validation found for the S.E.T.H.S\u2192T.S Industries thesis specifically: in April 2026 the "), bold("Public Investment Corporation (PIC)"), plain(" \u2014 Africa's largest asset manager, with R2.69 trillion under management \u2014 published a research paper proposing exactly this combination: transforming TVET colleges into investable social infrastructure through blended PPP partnerships, with private operators paid against employment-outcome performance metrics. This is a striking, independent, dated (April 2026) endorsement of the workforce-into-infrastructure logic G.O.D.S has built its loop around \u2014 worth citing directly and prominently in any future investor conversation, since it did not come from G.O.D.S itself.")]));

  // ---- 2.4 M.A.D.I.B.A market ----
  c.push(h2("2.4  M.A.D.I.B.A \u2014 capital deployment & sovereignty alignment"));
  c.push(body("M.A.D.I.B.A is positioned as a capital intermediary \u2014 a GP-style vehicle and government interface \u2014 not as a DFI itself. Its real competitive set is therefore twofold: the DFIs whose capital it hopes to access as an LP-facing channel, and the established African fund managers it would compete with for the same LP and government-co-investment dollars."));
  c.push(makeTable(
    ["Tier", "Players", "Scale (sourced)"],
    [
      ["DFIs M.A.D.I.B.A targets as capital sources", "DBSA, IDC, AfDB, IFC", "DBSA's Ifisa vehicle launched April 2026 specifically to mobilise blended private infrastructure capital; IDC and AfDB run established, multi-billion-rand infrastructure and industrial financing books."],
      ["Established African infrastructure/impact fund managers \u2014 the real GP-level competitive set", "AIIM (African Infrastructure Investment Managers), Ninety One (EAAIF + a separate SA Infrastructure Credit Fund targeting R5\u201315bn AUM), Metier Private Equity, Vantage Capital (Africa's largest mezzanine debt fund manager)", "Ninety One alone: $3bn+ committed since 2001, A2 Moody's-rated. Vantage Capital: R635m+ single-deal cheque sizes already in market in 2026."],
      ["Pan-African impact-focused managers", "Phatisa (~$500m AUM, food value chain + affordable housing, est. 2005), LeapFrog Investments, Goodwell Investments + Alitheia Capital (gender-lens, financial inclusion), AHL Venture Partners", "Phatisa alone manages roughly 30\u201340\u00D7 the entire seed round G.O.D.S is currently raising."],
      ["South Africa's own state asset manager (context, not a direct competitor)", "PIC (Public Investment Corporation)", "R2.69 trillion AUM \u2014 Africa's largest asset manager. Its Isibaya impact-investment vehicle alone runs to roughly R55\u201360bn. Already invested >R7bn in education-focused social infrastructure."],
    ],
    [2300, 3700, 3360]
  ));
  c.push(spacer(120));
  c.push(body("South Africa's impact-investing market is forecast to reach ~USD 1.5bn by 2030 (~21% CAGR); African impact funds collectively manage an estimated USD 70\u201380bn, with SA-domiciled funds controlling roughly 43% of that pool. M.A.D.I.B.A's FSCA Financial Service Provider (FSP) licence \u2014 a hard regulatory gate, not a formality \u2014 sits on the critical path before any of this capital can be legally raised: G.O.D.S's own data room correctly sequences this as a Month 3 application with a 12\u201318-month FSCA processing timeline, meaning M.A.D.I.B.A cannot legally hold third-party capital until roughly Month 15\u201320 at the earliest, even in an optimistic scenario."));

  c.push(pageBreak());
  return c;
}

module.exports = { buildMarketSection };
