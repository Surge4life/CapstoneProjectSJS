const fs = require("fs");
const H = require("/home/claude/helpers.js");
const {
  Document, Packer, Paragraph, TextRun, Header, Footer, AlignmentType, LevelFormat,
  HeadingLevel, PageNumber, BorderStyle, WidthType, ShadingType,
} = H;

const { buildCoverAndExecSummary } = require("/home/claude/content_p1.js");
const { buildMarketSection } = require("/home/claude/content_p2.js");
const { buildCompetitorsSection } = require("/home/claude/content_p3.js");
const { buildRemainingSections } = require("/home/claude/content_p4.js");

const allChildren = [
  ...buildCoverAndExecSummary(),
  ...buildMarketSection(),
  ...buildCompetitorsSection(),
  ...buildRemainingSections(),
];

const doc = new Document({
  numbering: {
    config: [
      { reference: "bullets", levels: [
        { level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 540, hanging: 270 } } } },
        { level: 1, format: LevelFormat.BULLET, text: "\u25E6", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 900, hanging: 270 } } } },
      ] },
      { reference: "numbers", levels: [
        { level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 540, hanging: 270 } } } },
      ] },
    ],
  },
  styles: {
    default: { document: { run: { font: "Arial", size: 21, color: H.NAVY_TEXT } } }, // 10.5pt body
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 30, bold: true, font: "Arial", color: H.NAVY_TEXT },
        paragraph: { spacing: { before: 360, after: 200 }, outlineLevel: 0,
          border: { bottom: { style: BorderStyle.SINGLE, size: 8, color: H.GOLD, space: 4 } } } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 25, bold: true, font: "Arial", color: H.GOLD_DARK },
        paragraph: { spacing: { before: 280, after: 160 }, outlineLevel: 1 } },
      { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 22, bold: true, italics: true, font: "Arial", color: H.NAVY_TEXT },
        paragraph: { spacing: { before: 220, after: 120 }, outlineLevel: 2 } },
    ],
  },
  sections: [{
    properties: {
      page: {
        size: { width: 12240, height: 15840 },
        margin: { top: 1260, right: 1440, bottom: 1260, left: 1440 },
      },
    },
    headers: {
      default: new Header({
        children: [new Paragraph({
          alignment: AlignmentType.RIGHT,
          children: [new TextRun({ text: "G.O.D.S vs THE WORLD \u2014 Complete Four-Division Assessment", size: 15, color: H.GREY, italics: true })],
        })],
      }),
    },
    footers: {
      default: new Footer({
        children: [new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [
            new TextRun({ text: "G.O.D.S Holdings (Pty) Ltd  \u00B7  Confidential  \u00B7  June 2026  \u00B7  Page ", size: 15, color: H.GREY }),
            new TextRun({ children: [PageNumber.CURRENT], size: 15, color: H.GREY }),
          ],
        })],
      }),
    },
    children: allChildren,
  }],
});

Packer.toBuffer(doc).then(buffer => {
  fs.writeFileSync("/home/claude/GODS_vs_The_World_Complete_v2.docx", buffer);
  console.log("Document written. Total top-level children: " + allChildren.length);
}).catch(err => {
  console.error("BUILD ERROR:", err);
  process.exit(1);
});
