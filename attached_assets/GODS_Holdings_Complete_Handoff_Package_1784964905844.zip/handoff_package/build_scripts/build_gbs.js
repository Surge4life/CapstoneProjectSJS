const fs = require("fs");
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  Header, Footer, AlignmentType, LevelFormat, HeadingLevel,
  BorderStyle, WidthType, ShadingType, VerticalAlign,
  PageNumber, PageBreak, ImageRun,
} = require("docx");

// ─── Brand constants (GODS_Brand_Manual_v2.pdf) ───────────────────────
const N     = "060E1C"; // Navy
const NT    = "16233A"; // Navy-text
const GOLD  = "C9A84C"; // Brand gold
const GD    = "8C7330"; // Gold-dark (text on light)
const GREY  = "5B6472"; // Muted
const AQUA  = "1A6B6B"; // S.E.T.H.S. division accent
const LGF   = "E8F4F1"; // Light green-fill (S.E.T.H.S. callout)
const LYF   = "F7F1E0"; // Light gold-fill
const LBF   = "F2F3F5"; // Light grey-fill
const WH    = "FFFFFF";
const CW    = 9360;     // Content width in DXA (Letter, 1in margins)
const FONT  = "Arial";

// ─── Helpers ─────────────────────────────────────────────────────────
const spacer = (h = 100) =>
  new Paragraph({ spacing: { after: h }, children: [] });

const hr = () =>
  new Paragraph({
    spacing: { before: 100, after: 100 },
    border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: GOLD } },
    children: [],
  });

const thickHr = (color = N) =>
  new Paragraph({
    spacing: { before: 120, after: 120 },
    border: { bottom: { style: BorderStyle.SINGLE, size: 14, color } },
    children: [],
  });

const pb = () => new Paragraph({ children: [new PageBreak()] });

const p = (runs, opts = {}) =>
  new Paragraph({
    children: Array.isArray(runs) ? runs : [new TextRun({ text: runs })],
    spacing: { after: 140, line: 276 },
    alignment: opts.align || AlignmentType.LEFT,
    ...opts,
  });

const centered = (text, sz = 22, bold = false, color = NT) =>
  new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { after: 80 },
    children: [new TextRun({ text, size: sz, bold, color, font: FONT })],
  });

const R  = (text, opts = {}) => new TextRun({ text, font: FONT, size: 21, ...opts });
const B  = (text, opts = {}) => new TextRun({ text, font: FONT, size: 21, bold: true, ...opts });
const BI = (text, opts = {}) => new TextRun({ text, font: FONT, size: 21, bold: true, italics: true, ...opts });
const G  = (text, sz = 21, bold = false) => new TextRun({ text, color: GD, bold, size: sz, font: FONT });
const A  = (text, sz = 21, bold = false) => new TextRun({ text, color: AQUA, bold, size: sz, font: FONT });

function h1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    children: [new TextRun({ text, font: FONT })],
    spacing: { before: 320, after: 180 },
  });
}
function h2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    children: [new TextRun({ text, font: FONT })],
    spacing: { before: 260, after: 140 },
  });
}
function h3(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_3,
    children: [new TextRun({ text, font: FONT })],
    spacing: { before: 200, after: 100 },
  });
}

function bullet(content, level = 0) {
  const runs = typeof content === "string" ? [R(content)] : content;
  return new Paragraph({
    numbering: { reference: "bullets", level },
    children: runs,
    spacing: { after: 80, line: 276 },
  });
}

function shadeBox(lines, fill = LYF, borderColor = GOLD) {
  return new Table({
    width: { size: CW, type: WidthType.DXA },
    columnWidths: [CW],
    rows: [new TableRow({ children: [new TableCell({
      width: { size: CW, type: WidthType.DXA },
      shading: { fill, type: ShadingType.CLEAR },
      borders: Object.fromEntries(["top","bottom","left","right"].map(s =>
        [s, { style: BorderStyle.SINGLE, size: 4, color: borderColor }])),
      margins: { top: 160, bottom: 160, left: 220, right: 220 },
      children: lines,
    })]})],
  });
}

function makeTable(headers, rows, widths, headerFill = N) {
  const w = widths || headers.map(() => Math.floor(CW / headers.length));
  const bdr = { style: BorderStyle.SINGLE, size: 2, color: "CCCCCC" };
  const borders = { top: bdr, bottom: bdr, left: bdr, right: bdr };
  const hRow = new TableRow({
    tableHeader: true,
    children: headers.map((h, i) => new TableCell({
      width: { size: w[i], type: WidthType.DXA },
      shading: { fill: headerFill, type: ShadingType.CLEAR }, borders,
      margins: { top: 100, bottom: 100, left: 120, right: 120 },
      children: [new Paragraph({ children: [new TextRun({ text: h, bold: true, color: WH, size: 19, font: FONT })] })],
    })),
  });
  const bodyRows = rows.map((r, ri) => new TableRow({
    children: r.map((cell, ci) => new TableCell({
      width: { size: w[ci], type: WidthType.DXA },
      shading: { fill: ri % 2 === 0 ? WH : LBF, type: ShadingType.CLEAR }, borders,
      margins: { top: 90, bottom: 90, left: 120, right: 120 },
      children: [new Paragraph({ children: [new TextRun({ text: cell, size: 19, font: FONT })], spacing: { after: 40 } })],
    })),
  }));
  return new Table({ width: { size: CW, type: WidthType.DXA }, columnWidths: w, rows: [hRow, ...bodyRows] });
}

function pillarsTable() {
  const data = [
    ["I", "HONESTY", "The non-negotiable foundation. Honesty with self, employer, and system. Enables trust, which is the only currency S.E.T.H.S trades in. Commercial mapping: employer trust and contractual reliability."],
    ["II", "TOLERANCE", "Belief cannot be imposed — only discovered. S.E.T.H.S accepts every participant's belief system, background, and personal failure as the starting point, never a disqualifier. Commercial mapping: retention and long-term participant stability."],
    ["III", "BELIEF SYSTEMS", "G.O.D.S is a General Belief System (GBS) — built on what connects humanity, not what divides it. S.E.T.H.S. operationalises this by creating environments where participants of any faith, background, or worldview can grow together. Commercial mapping: continental scalability and cross-cultural deployment."],
    ["IV", "EQUALITY", "Every participant enters the programme as an equal — not in circumstance, but in potential and in how the system treats them. Structured equality in process produces measurable equality in outcome. Commercial mapping: certification integrity and credential value."],
    ["V", "PRIDE", "The output of the entire journey. Pride is the state in which a graduate becomes a mentor — someone who can look back and see the distance travelled, and choose to help the next person travel it too. Commercial mapping: long-term retention, alumni network activation, peer-mentor pipeline."],
  ];
  return makeTable(
    ["#", "PILLAR", "DEFINITION & COMMERCIAL MAPPING"],
    data,
    [480, 1500, 7380]
  );
}

// ─── BUILD CONTENT ───────────────────────────────────────────────────
const children = [];

// ══════════════════════════════════════════════════════════
// COVER
// ══════════════════════════════════════════════════════════
children.push(
  spacer(480),
  centered("G . O . D . S  HOLDINGS", 18, false, GD),
  centered("GOOD ORDERLY DIRECTIONAL SYSTEMS", 16, false, GREY),
  spacer(240),
  centered("GBS-SETHS", 64, true, N),
  centered("Global Belief System", 28, false, GD),
  centered("Systematically Engineered Transfer of Human Systems", 22, true, AQUA),
  spacer(200),
  thickHr(GOLD),
  spacer(120),
  centered("VERSION 1.0  ·  INSTITUTIONAL FRAMEWORK  ·  JULY 2026", 18, false, GREY),
  spacer(80),
  centered("A Complete Operational Framework for Lifelong Human Acceleration,", 20, false, NT),
  centered("Workforce Transition, Reintegration, and Generational Knowledge Transfer", 20, false, NT),
  spacer(240),
  hr(),
  spacer(120),
  p([B("Architect & Founder:  "), R("Sashin J. Singh")]),
  p([B("Institution:  "), R("G.O.D.S Holdings (Pty) Ltd — Pre-Registration")]),
  p([B("IP Custodian:  "), R("G.O.D.S IP Trust — Trust Property Control Act 57 of 1988")]),
  p([B("Document Classification:  "), R("OPEN — Institutional Use")]),
  p([B("Conception:  "), R("2016 (Seth's Empire, Johannesburg) — Decade of development and refinement")]),
  p([B("Formalised:  "), R("2025–2026 via G.O.D.S Holdings institutional architecture build")]),
  spacer(160),
  shadeBox([
    p([B("Authorship note. ")]),
    p([R("This framework represents a decade of original thinking, lived experience, and structured development by Sashin J. Singh, originating in 2016 from the Seth's Empire concept and continuously refined through personal, academic, and institutional development. AI documentation tools have been used to clarify, structure, and amplify the articulation of this work — not to generate it. Every concept, pillar, methodology, and framework described here originates from SJS's own intellectual architecture, grounded in his lived reality and his 10-year commitment to building systemic solutions for the people who need them most.")]),
  ], LYF, GOLD),
  pb(),
);

// ══════════════════════════════════════════════════════════
// SECTION 1 — EXECUTIVE SUMMARY
// ══════════════════════════════════════════════════════════
children.push(
  h1("1.  Executive Summary"),
  p([R("S.E.T.H.S. began in 2016 as Seth's Empire — a personal conviction that the people most written off by society are precisely the people most capable of being transformed by a system designed to believe in them from day one. Over a decade, that conviction became a methodology. The methodology became a programme. The programme became a division. And the division became the human-supply engine of a four-part institutional ecosystem designed to address four compounding structural failures simultaneously: workforce displacement, infrastructure deficit, unaccountable AI, and absent patient capital.")]),
  p([R("The world has changed dramatically since 2016. Artificial intelligence is no longer a distant concept — it is actively displacing white-collar, entry-to-mid-level workers across every industry, every economy, every generation. The World Economic Forum's Future of Jobs 2025 report projects that 85 million jobs will be displaced by automation by 2030. IMD's 2026 workplace trends research confirms that skilled trades — construction, agriculture, electrical, plumbing, food systems — remain comparatively insulated. The opportunity for S.E.T.H.S. is not merely to retrain the unemployed. It is to redirect an entire generation of displaced workers toward the skills the world will always need, while the skills AI is replacing go vacant.")]),
  p([R("GBS-SETHS is the global institutional expression of that mission. It is a franchise-ready, constitutionally governed, lifelong human acceleration infrastructure — designed to operate in any country, across any cultural context, for any population cohort experiencing displacement, marginalisation, or transition. It is not a training programme. It is a human operating system — one that begins at intake, ends never, and continuously transforms participants into mentors who transform the next generation.")]),
  spacer(120),
  shadeBox([
    p([B("What GBS-SETHS is not: "), R("A bootcamp. A learnership. A social welfare programme. A once-and-done job placement service.")]),
    p([B("What GBS-SETHS is: "), R("A lifelong human acceleration engine. A constitutional framework. A global franchise infrastructure. A closed loop that turns graduates into mentors, and mentors into the system's greatest asset.")]),
  ], LGF, AQUA),
  spacer(120),
  h2("The Numbers That Frame the Mandate"),
  makeTable(
    ["Dimension", "South Africa (2026)", "Global Context"],
    [
      ["Youth unemployment (15–24)", "60.9% official rate\n(Stats SA Q1 2026)", "NEET population: 1.2 billion globally (ILO 2026)"],
      ["AI-displaced jobs forecast", "3.4M SA formal jobs at medium-to-high automation risk (World Bank)", "85M global jobs displaced by automation by 2030 (WEF Future of Jobs 2025)"],
      ["Skills shortage — trades", "Critical shortage in construction, solar installation, agriculture, community health", "Nvidia CEO Jensen Huang (2026): 'Next millionaires will be plumbers and electricians'"],
      ["Learnership abuse", "R12–30B in annual SETA/B-BBEE learnership spend — majority producing no absorbed employment", "GBS-SETHS is specifically designed to close this gap: graduates feed directly into T.S. Industries"],
      ["Market validation", "PIC (April 2026) proposed TVET-as-investable-infrastructure PPP — directly validates GBS-SETHS logic", "DFI appetite for blended workforce-infrastructure deals is confirmed and growing"],
    ],
    [2200, 3200, 3960]
  ),
  pb(),
);

// ══════════════════════════════════════════════════════════
// SECTION 2 — CONSTITUTIONAL FRAMEWORK
// ══════════════════════════════════════════════════════════
children.push(
  h1("2.  Constitutional Framework"),
  p([R("The GBS-SETHS Constitutional Framework is the governance backbone of the entire system. It defines who GBS-SETHS is, what it stands for, what it will never do, and how every franchise node — regardless of country or context — must operate. It is not aspirational. It is binding.")]),

  h2("2.1  Mission Statement"),
  shadeBox([
    p([BI("GBS-SETHS exists to continuously move individuals — across their entire lifetime — from exclusion, displacement, or stagnation toward productive participation, economic dignity, leadership, and mentorship. We are not in the business of job placement. We are in the business of human transformation.")]),
  ], LGF, AQUA),

  h2("2.2  The Seven Core Mission Domains"),
  p([R("GBS-SETHS operates across seven interconnected mission domains. No participant is served by one domain alone — the system is designed to move each person through multiple domains simultaneously, and to return to earlier domains when life requires it.")]),
  makeTable(
    ["#", "Domain", "What it means in practice"],
    [
      ["1", "Rehabilitation & Reintegration", "For individuals exiting the criminal justice system, substance recovery, mental health crises, or domestic disruption. The original S.E.T.H.S. DNA — structured surety, monitored reintegration, employer preparation."],
      ["2", "Workforce Development", "Core vocational skills in four streams: Construction & Infrastructure, Digital Operations, Agriculture & Food Systems, Community Health & Social Support. Aligned directly with T.S. Industries' seven subsidiaries."],
      ["3", "AI Adaptation", "Equipping every participant — regardless of prior education — with AI literacy, prompt skills, and the understanding of which roles AI is replacing and which it is creating. Not fear; readiness."],
      ["4", "Human Capital Acceleration", "Moving participants beyond employment into growth — supervisory skills, entrepreneurship pathways, financial literacy, personal leadership. The 'fish' is a job; the 'fishing skill' is economic self-sufficiency."],
      ["5", "Economic Participation", "Formal inclusion in the economy — banking, tax registration, credit access, insurance literacy. Many GBS-SETHS participants are economically invisible. This domain makes them formally visible."],
      ["6", "Lifelong Learning", "The Phase 6 architecture — the door never closes. Alumni access upskilling, reskilling, and re-entry at any point in life. No time limit. No judgement for returning."],
      ["7", "Generational Knowledge Transfer", "The culmination of the CET/CTE loop: graduates become mentors. Parents transform their households. Communities compound their human capital across generations."],
    ],
    [480, 2200, 6680]
  ),
  spacer(140),

  h2("2.3  The Five Constitutional Pillars"),
  p([R("The Five Pillars of GBS-SETHS are not values statements. They are structural operating conditions — the five things that must be true about how a GBS-SETHS node operates for it to be constitutionally compliant and commercially viable. They were developed over ten years by Sashin J. Singh through lived experience, programme design, and deep engagement with the populations GBS-SETHS serves.")]),
  p([B("As Sashin J. Singh stated: "), BI("\"This is what 10 years of refinement produced — not a list of values, but a structural commercial machine wearing the language of dignity.\"")]),
  spacer(80),
  pillarsTable(),
  spacer(160),

  h2("2.4  The Twelve G.O.D.S. Constitutional Pillars — Governing GBS-SETHS"),
  p([R("GBS-SETHS operates within the broader G.O.D.S. constitutional governance framework. All twelve G.O.D.S. Constitutional Pillars apply to every GBS-SETHS node globally. The four most directly operational for GBS-SETHS are highlighted:")]),
  makeTable(
    ["Pillar", "Name", "GBS-SETHS Relevance"],
    [
      ["I", "Human Dignity", "Every participant interaction — intake, assessment, facilitation, exit — must be designed to affirm and protect human dignity."],
      ["VIII", "Human Primacy in AI", "AI tools may support GBS-SETHS administration and learning but may never replace human case management, facilitation, or mentorship. The human relationship is the programme."],
      ["IX", "Reintegration", "The criminal justice and substance recovery population is explicitly protected as a primary cohort — not tolerated, actively designed for."],
      ["X", "Long-Horizon Discipline", "GBS-SETHS is a 250-year institutional mandate. No short-term financial pressure justifies compromising programme integrity or participant outcomes."],
    ],
    [700, 2400, 6260]
  ),
  pb(),
);

// ══════════════════════════════════════════════════════════
// SECTION 3 — FRANCHISE MODEL
// ══════════════════════════════════════════════════════════
children.push(
  h1("3.  The GBS Franchise Model"),
  p([R("GBS-SETHS is built for scale — not through a single national programme, but through a franchise architecture that allows the methodology to be licensed, deployed, and governed across regions, countries, and cultural contexts while maintaining constitutional integrity. The franchise model is the mechanism by which SJS's 2016 vision becomes a global institution.")]),

  h2("3.1  The Five-Layer Global Architecture"),
  makeTable(
    ["Layer", "Name", "Role & Mandate"],
    [
      ["Layer 1", "GBS Global (Head Office)", "G.O.D.S Holdings (Pty) Ltd + GBS-SETHS IP Trust. Holds all intellectual property, sets constitutional standards, certifies national operators, receives royalty streams, manages global research and methodology evolution. Non-negotiable: any node not certified by Layer 1 is not a GBS-SETHS node."],
      ["Layer 2", "National GBS", "Country-level licensed operator. Holds a national franchise licence from Layer 1. Adapts the methodology for local language, culture, legislation, and accreditation standards (e.g. SA: SAQA/SETA system; Kenya: NITA; UAE: KHDA). Reports outcomes to Layer 1. Manages regional nodes below it."],
      ["Layer 3", "Regional GBS", "Province/state/metropolitan-level operational entity. Sub-licensed from the National GBS. Runs regional cohorts, manages local employer partnerships, coordinates regional T.S. Industries workforce pipeline. First point of contact for local participants."],
      ["Layer 4", "Delivery Operators", "Accredited training providers, NGOs, corporate skills development departments, government TVET colleges, or social enterprises that are certified to deliver the GBS-SETHS curriculum. They do not own the methodology — they are licensed to deliver it under Regional GBS supervision."],
      ["Layer 5", "Employer Ecosystems", "Companies, co-operatives, government departments, T.S. Industries subsidiaries, and social enterprises that commit to receiving GBS-SETHS graduates as preference-placement employers. They are not part of the franchise structure but are bound by employer partnership agreements with outcome-reporting obligations."],
    ],
    [900, 2200, 6260]
  ),
  spacer(140),

  h2("3.2  Franchise Licensing Economics"),
  p([R("The GBS franchise model is designed to be financially self-sustaining at scale while keeping participant costs at zero. The economic model is built on licensing fees from operators, outcome-based government funding, employer partnership fees, and philanthropic/DFI capital for startup cohorts.")]),
  makeTable(
    ["Revenue Stream", "Source", "Structure"],
    [
      ["National Franchise Licence", "National GBS (Layer 2)", "Upfront licence fee + annual renewal + % of cohort revenue shared upward to GBS Global. Rate negotiated per country based on GDP/capita and market size."],
      ["Regional Sub-Licence", "Regional GBS (Layer 3)", "Annual fee paid to National GBS. Includes use of branded curriculum, case management systems (UDOC-governed), and certified facilitator pool."],
      ["Delivery Operator Certification", "Layer 4 operators", "Annual certification fee. Recertification every 24 months. Revoked for constitutional violations or persistent poor outcomes."],
      ["Government Outcomes-Based Funding", "SETA, EPWP, DSD, DCS, Provincial Skills Development", "Per-outcome payment structure: X per verified 90-day employment placement. Fundable under PFMA/MFMA procurement frameworks (Section 217 Constitution of SA)."],
      ["Employer Partnership Fee", "Layer 5 employers", "Annual fee for preferred access to GBS-SETHS graduate pool, co-branded employer profile, priority matching, and UDOC-verified candidate assessments."],
      ["B-BBEE Skills Development Credits", "Host employers (Layer 5)", "Employers who host GBS-SETHS learnerships earn B-BBEE scorecard points. Unlike conventional learnership models, GBS-SETHS includes an absorption commitment clause in employer agreements — deliberately closing the SJS-identified gap where companies extract credits without creating real employment."],
    ],
    [2400, 2600, 4360]
  ),
  spacer(140),

  h2("3.3  The GBS Absorption Commitment Clause"),
  shadeBox([
    p([B("This clause is non-negotiable in every GBS-SETHS employer partnership agreement: ")]),
    p([BI("\"An employer who participates in GBS-SETHS as a B-BBEE skills development host commits to offering formal absorption consideration to every participant who completes the programme within their sector. 'Absorption consideration' means a documented interview process and a written decision letter within 30 days of programme completion. This does not guarantee employment — it guarantees that the participant is formally considered. The commitment letter forms part of the employer's UDOC-verified compliance record.\"\n")]),
    p([R("This clause directly addresses the learnership abuse dynamic SJS identified through his own lived experience with the Terraco/Progression learnership model — where companies extract B-BBEE credits without ever intending to create employment. It does not prohibit non-absorption; it requires transparency and documented accountability. The UDOC governance engine enforces this through sealed, auditable employer compliance records.")]),
  ], LGF, AQUA),
  pb(),
);

// ══════════════════════════════════════════════════════════
// SECTION 4 — OPERATING MANUAL: CET/CTE METHODOLOGY
// ══════════════════════════════════════════════════════════
children.push(
  h1("4.  Operating Manual — The CET/CTE Methodology"),
  p([R("The intellectual core of GBS-SETHS is the CET/CTE loop — a continuous knowledge transfer methodology first articulated in Chapter 10 of SJS's published memoir 'Confessions of an Addict (He'll Never Change)' (novum publishing, 2025) under the title 'The Theory of Exposure.' It is the framework that transforms a training programme into a living, self-replicating human acceleration engine.")]),

  h2("4.1  The CET Loop — Communicate, Educate, Transfer"),
  shadeBox([
    p([B("A teacher communicates knowledge."), R(" Technology carries it. A student learns it. Then —")]),
    p([B("The student becomes the teacher."), R(" Knowledge is transferred again. Then —")]),
    p([B("The cycle repeats."), R(" Every iteration deepens the knowledge, widens the network, and grows the system.")]),
    spacer(60),
    p([BI("\"Not an AI engine. A human acceleration engine.\" — Sashin J. Singh, 2016")]),
  ], LGF, AQUA),
  spacer(100),
  makeTable(
    ["Phase", "Element", "Who", "What happens"],
    [
      ["CET", "Communicate", "Facilitator / Case Manager", "Knowledge, skills, and lived experience are communicated in a structured, trauma-informed, participant-centred environment. Not lecture — dialogue."],
      ["CET", "Educate", "Curriculum delivery", "The structured skills programme: vocational pathway + transferable skills + AI literacy + financial literacy. Assessment-verified learning outcomes."],
      ["CET", "Transfer", "Technology + Assessment", "UDOC-governed assessment infrastructure verifies that knowledge has genuinely transferred. Certification is the evidence of transfer — not attendance."],
      ["CTE", "Carry", "Graduate / Alumnus", "The graduate carries the knowledge into employment, community, family. The knowledge does not stay in the classroom — it lives in the person."],
      ["CTE", "Transfer", "Peer Mentor", "Phase 5/6: the graduate returns as a mentor. Knowledge is transferred to the next cohort. The system grows without requiring proportional staff increases."],
      ["CTE", "Evolve", "Alumni Network", "The knowledge pool evolves as alumni accumulate real-world experience and bring it back into the programme. GBS-SETHS gets smarter with every cohort."],
    ],
    [700, 1600, 2200, 4860]
  ),
  spacer(140),

  h2("4.2  The Five Methodology Pillars"),
  p([R("The Five Methodology Pillars are the operational dimensions of the CET/CTE framework — the five things the system must build in every participant, and the five things every GBS-SETHS node must be capable of delivering.")]),
  makeTable(
    ["Pillar", "Domain", "CET/CTE Link", "Operational Expression"],
    [
      ["Communication", "Language / Expression / Advocacy", "CET — Communicate", "Every participant exits GBS-SETHS able to articulate their value, navigate workplace communication, write professionally, and advocate for themselves. Communication is not a soft skill — it is the primary employability variable."],
      ["Education", "Knowledge / Skills / Certification", "CET — Educate", "Structured, accredited, competency-based learning across four vocational streams. Registered under existing SAQA unit standards; evolving toward new GBS-SETHS-specific accreditation standards as outcome data accumulates."],
      ["Transportation", "Movement / Delivery / Technology", "CET — Transfer", "Technology carries the knowledge — UDOC-governed LMS, mobile access, community platforms, employer-matching system. Transportation is the infrastructure of learning at scale."],
      ["Human Capital", "People / Potential / Network", "CTE — Carry & Transfer", "The investment in the participant as a long-term asset — not a training cost. Human capital appreciation is the primary return on GBS-SETHS investment. Every graduate is a node in a growing network."],
      ["Sustainability", "Self-Replication / Long-Horizon / Reinvestment", "CTE — Evolve", "The system is financially, socially, and intellectually self-sustaining. Graduates become mentors. Employer fees fund new cohorts. Knowledge deepens with every cycle. Phase 6 ensures the loop never closes."],
    ],
    [1500, 2200, 1800, 3860]
  ),
  spacer(140),

  h2("4.3  The Full Operating Cycle"),
  p([R("The complete GBS-SETHS operating cycle runs eight stages, designed to be continuous rather than terminal. No participant permanently exits the system — they move to a lower-intensity phase and retain re-entry rights indefinitely.")]),
  makeTable(
    ["Stage", "Name", "Duration", "Key Activity", "Output"],
    [
      ["01", "CET — Communicate", "Weeks 1–4", "Intake, assessment, stabilisation, foundation", "Participant profile, vocational pathway assignment"],
      ["02", "CET — Educate", "Weeks 5–18", "Core skills + vocational pathway + AI literacy + mentorship matching", "Employer-readiness certification, portfolio of evidence"],
      ["03", "CET — Transfer", "Weeks 19–24", "Active placement, employer activation, case manager monitoring", "Verified employment commencement"],
      ["04", "Assessment", "Week 25, Month 3, Month 6", "30/60/90-day employment outcome verification. UDOC audit trail.", "Primary outcome metrics logged to COB"],
      ["05", "Deployment", "Ongoing", "Upskilling module access, employer check-ins, cohort reunion sessions", "Employment retention, income growth"],
      ["06", "Employment", "Continuous", "Participant in formal employment, accessing Phase 5 ongoing support", "Economic participation data"],
      ["07", "Mentorship", "Month 6 onwards", "Eligible alumni invited onto peer-mentor pathway. Stipended mentorship roles.", "Peer mentor pool — the system's next CET delivery layer"],
      ["08", "Reinvestment & Repeat", "Perpetual (Phase 6)", "Alumni re-entry at any life stage. New cohort mentored by prior graduates. No file ever closed.", "Generational knowledge transfer"],
    ],
    [600, 1900, 1500, 2700, 2660]
  ),
  pb(),
);

// ══════════════════════════════════════════════════════════
// SECTION 5 — CERTIFICATION STANDARDS
// ══════════════════════════════════════════════════════════
children.push(
  h1("5.  Certification Standards"),
  p([R("GBS-SETHS operates a multi-tier certification architecture — for participants, for facilitators, for Delivery Operators, and for national franchise nodes. Certification is not a paper exercise. It is a UDOC-governed, audit-trail-backed, outcome-verified process.")]),

  h2("5.1  Participant Certification Tiers"),
  makeTable(
    ["Tier", "Certification", "Trigger", "Standard"],
    [
      ["Bronze", "GBS Foundation Certificate", "Completion of Phases 1–2 (Weeks 1–12)", "Core transferable skills + digital literacy + AI literacy. Registered against SAQA unit standards for workplace readiness."],
      ["Silver", "GBS Employment-Ready Certificate", "Completion of Phase 3 (Week 18 assessment passed)", "Employer-readiness: CV, interview, sector-specific competency. UDOC-issued, employer-verifiable digital credential."],
      ["Gold", "GBS Verified Employment Certificate", "90-day verified employment outcome (Phase 4)", "The primary credential. Verifiable by any employer against the UDOC audit trail. Includes employment sector, role type, and outcome rating."],
      ["Platinum", "GBS Alumni Mentor Certification", "Phase 6 peer mentor pathway completion", "Certified capacity to facilitate Phase 1–2 elements under supervision. Unlocks stipended mentorship roles within GBS-SETHS nodes."],
      ["Specialist", "Stream-Specific Trade Certification", "Stream A/B/C/D advanced completion", "Pathway-specific: Construction (CIDB Entry Level), Digital (CompTIA/Microsoft equivalent), Agriculture (SETA-aligned), Community Health (HPCSA CHW category)."],
    ],
    [900, 2200, 2300, 3960]
  ),
  spacer(140),

  h2("5.2  Operator Certification"),
  p([R("Every GBS-SETHS Delivery Operator (Layer 4) must achieve and maintain operator certification. Certification is issued by the Regional GBS (Layer 3), audited by the National GBS (Layer 2), and held on record by GBS Global (Layer 1). UDOC provides the audit infrastructure.")]),
  makeTable(
    ["Requirement", "Standard", "Frequency"],
    [
      ["Facilitator qualifications", "Minimum NQF4 equivalent + GBS Mentor certification (Platinum tier)", "At appointment + biennial renewal"],
      ["Venue / facility standards", "Physical or digital delivery environment meeting GBS-SETHS minimum specifications (safety, accessibility, connectivity)", "Initial certification + annual inspection"],
      ["Curriculum fidelity", "Minimum 90% adherence to the GBS-SETHS core curriculum framework. Adaptations permitted within the 20% localisation allowance.", "Every cohort — UDOC-verified"],
      ["Outcome reporting", "All participant data submitted to UDOC within 7 days of each milestone. No data manipulation permitted.", "Continuous — UDOC-enforced"],
      ["Constitutional compliance", "Annual self-assessment + COB-reviewed compliance certificate. Any Pillar violation triggers suspension pending investigation.", "Annual"],
    ],
    [2800, 3800, 2760]
  ),
  spacer(140),

  h2("5.3  The Self-Affirmation Contract — Intake Commitment"),
  shadeBox([
    p([B("Design principle (SJS, June 2026): "), BI("\"The student's contract is to themselves, signed with their coordinated entrance assessment.\"")]),
    spacer(60),
    p([R("Every participant entering GBS-SETHS signs a Self-Affirmation Contract at intake — not a legal document of obligation, but a personal commitment they make to themselves in the presence of their intake case manager. It is witnessed, held in the participant's portfolio of evidence, and revisited at every major milestone. It asks three questions drawn directly from the Founders Doctrine:")]),
    spacer(60),
    p([B("1.  What do you want to change about your life?")]),
    p([B("2.  Why now?")]),
    p([B("3.  What does the person you are becoming look like?")]),
    spacer(60),
    p([R("The Self-Affirmation Contract is not used as leverage or enforced. It is the participant's own words — held for the participant, by the participant. Its purpose is to create a documented starting point that graduates can look back on as evidence of how far they have travelled.")]),
  ], LGF, AQUA),
  pb(),
);

// ══════════════════════════════════════════════════════════
// SECTION 6 — IMPLEMENTATION ROADMAP
// ══════════════════════════════════════════════════════════
children.push(
  h1("6.  Implementation Roadmap"),
  p([R("The GBS-SETHS implementation roadmap is phased across six stages, aligned with the G.O.D.S. Holdings funding and operational timeline. The roadmap is structured to prove the methodology before scaling it — outcome data from the pilot cohort becomes the evidence base for national and international expansion.")]),

  makeTable(
    ["Stage", "Name", "Timeline", "Key Milestones"],
    [
      ["Stage 0", "Pre-Launch Infrastructure", "Months 1–3 post-seed", "Secure pilot facility (Johannesburg). Recruit Programme Director + 2 Senior Facilitators + 4 Stream Facilitators + 2 Case Managers. Complete SETA registration for applicable unit standards. Deploy UDOC participant management module. Sign first 3 employer partnerships (Layer 5)."],
      ["Stage 1", "Pilot Cohort — South Africa", "Months 4–12", "First cohort of 50 participants across all four streams. Full CET/CTE operating cycle. Intensive case management and outcome monitoring. Employer partner activation. 90-day employment outcome data collected. COB first compliance report issued."],
      ["Stage 2", "Pilot Review & Methodology Refinement", "Month 13–15", "Full analysis of pilot cohort outcomes against all primary, secondary, and social impact metrics. Curriculum adjustments based on data. Facilitator feedback integration. UDOC audit trail first external review. Begin SAQA unit standard petition process for GBS-SETHS-specific accreditation."],
      ["Stage 3", "National Scale — South Africa", "Months 16–30", "Expand to 3 regional nodes (Johannesburg, Cape Town, Durban). 3 cohorts running simultaneously (150 participants). Layer 3 Regional GBS structures formally constituted. First Delivery Operator certifications issued. B-BBEE employer partnership programme live."],
      ["Stage 4", "First International Node", "Months 30–42", "Layer 2 National GBS licence issued for first international market (priority: Botswana, Zimbabwe, or Namibia based on regulatory readiness and T.S. Industries expansion alignment). Curriculum localisation for first international deployment. SADC regional employer network activation."],
      ["Stage 5", "BRICS Expansion", "Years 4–7", "National GBS nodes constituted in BRICS-adjacent economies (India, UAE, Brazil node assessment). G.O.D.S. BRICS Strategic Relations division (under T.S.) coordinates. International accreditation partnerships sought (e.g. City & Guilds, ILO recognised framework)."],
      ["Stage 6", "Global GBS Network", "Years 7–25", "20+ National GBS nodes. Self-sustaining royalty model funding GBS Global operations. Annual World GBS Summit — methodology evolution, cross-national peer learning. CTE Generational Knowledge Transfer in first markets beginning to produce second-generation programme graduates."],
    ],
    [900, 2200, 2000, 4260]
  ),
  spacer(140),

  h2("6.1  Phase 6 — The Door Never Closes"),
  shadeBox([
    p([B("Principle: "), R("No graduate of GBS-SETHS is ever permanently off the system's books.")]),
    spacer(60),
    p([R("Phase 6 is not a formal programme phase with a timetable. It is the permanent infrastructure of re-entry. Any graduate — regardless of how long they have been out, what they have been through, or how many times they have fallen — can contact their originating GBS-SETHS node and receive:")]),
    spacer(60),
    bullet("A case manager conversation within 5 business days"),
    bullet("Access to the upskilling module library — no fees, no re-assessment required"),
    bullet("Referral to re-placement support if needed"),
    bullet("Emergency support fund access (where available) for immediate crisis stabilisation"),
    bullet("Peer mentor network connection — other alumni who have experienced similar transitions"),
    spacer(60),
    p([R("Phase 6 does not require a reason. It does not require a minimum time away or a minimum time clean. The only requirement is that the person asks. No competitor in the South African or African workforce development market has been found to offer this. It is GBS-SETHS's most significant structural differentiator.")]),
  ], LGF, AQUA),
  pb(),
);

// ══════════════════════════════════════════════════════════
// SECTION 7 — GLOBAL SCALING STRATEGY
// ══════════════════════════════════════════════════════════
children.push(
  h1("7.  Global Scaling Strategy"),

  h2("7.1  Country-Specific Deployment Framework"),
  p([R("Every GBS-SETHS national deployment adapts within the 20% localisation allowance while holding 80% of the constitutional framework unchanged. The 80% that never changes: the Five Pillars, the CET/CTE methodology, the UDOC outcome governance architecture, the Self-Affirmation Contract, and the Phase 6 lifetime re-entry commitment. The 20% that adapts: language of delivery, vocational pathway alignment (e.g. Stream A in SADC may emphasise solar; in Southeast Asia, aquaculture), regulatory accreditation pathway, and employer ecosystem composition.")]),

  makeTable(
    ["Region", "Priority Markets", "Key Adaptation", "Entry Strategy"],
    [
      ["South Africa (Phase 1)", "Johannesburg, Cape Town, Durban, Tshwane", "Pilot market. SAQA/SETA accreditation. B-BBEE employer framework. CoJ government partnership.", "Seed capital. Direct G.O.D.S. Holdings operation. No franchise layer yet."],
      ["SADC (Phase 2)", "Botswana, Zimbabwe, Namibia, Mozambique, Zambia", "English/Portuguese adaptation. Mining and agriculture stream emphasis. AfDB and DFI co-funding alignment.", "National GBS licence to credible local NGO or government agency with G.O.D.S. advisory support."],
      ["East Africa (Phase 3)", "Kenya, Tanzania, Uganda, Rwanda", "NITA/NVCET accreditation alignment. Digital operations stream emphasis (Nairobi tech ecosystem). M-Pesa financial literacy integration.", "GSMA and Mastercard Foundation ecosystem leverage. GEC+Africa competition platform as entry point."],
      ["BRICS Adjacent (Phase 4)", "India, UAE, Brazil", "Country-specific vocational qualification authority. Language localisation. Shariah-compliant financial literacy module (UAE). Caste-neutral intake design (India).", "Strategic partnership with existing at-scale workforce development institutions in each market."],
      ["Global English Markets (Phase 5)", "UK, Australia, Canada", "Asylum seeker and refugee cohort focus. Integration with national employment services. International Skills Recognition pathways.", "Social enterprise / CIC structure for these markets given regulatory environments."],
    ],
    [1800, 2200, 2800, 2560]
  ),
  spacer(140),

  h2("7.2  AI Displacement — The Global Tailwind"),
  p([R("GBS-SETHS's 2026 positioning as a response to AI-driven workforce displacement is not a marketing choice — it is a structural reality. The IMD 2026 Workplace Trends Report, the WEF Future of Jobs 2025, and multiple independent 2026 labour market analyses all confirm the same pattern: white-collar, routine cognitive roles are the most exposed to near-term AI displacement; skilled trades are comparatively insulated. This is the 'collar switch' — white-collar workers retraining into trades, and GBS-SETHS is designed to be the infrastructure that enables that switch at scale.")]),
  shadeBox([
    p([B("The G.O.D.S. Positioning: ")]),
    p([R("Most organisations building AI are optimising for replacement. GBS-SETHS is building the human infrastructure for what comes after replacement — the skills that AI cannot perform, the connections that AI cannot forge, and the lifelong support that AI cannot provide. In a world of accelerating automation, GBS-SETHS is not competing with AI. It is the human acceleration engine that AI makes necessary.")]),
  ], LYF, GOLD),
  spacer(140),

  h2("7.3  Third-Party Validation of the Core Thesis"),
  p([R("The GBS-SETHS workforce-into-infrastructure thesis received independent, unsolicited validation in April 2026 from an unlikely source: the Public Investment Corporation (PIC) — Africa's largest asset manager, with R2.69 trillion under management. The PIC published a research paper proposing the transformation of TVET colleges into investable social infrastructure through blended PPP partnerships, with private operators paid against employment-outcome performance metrics.")]),
  p([R("This is strikingly close to the GBS-SETHS model — human capital development funded through blended government/DFI/private capital, delivered via a constitutionally-governed franchise, with outcome-based payment structures. This paper did not reference G.O.D.S. or SJS. It arrived independently, from one of Africa's most credible institutional voices. It is the most powerful piece of external validation the GBS-SETHS thesis has.")]),
  pb(),
);

// ══════════════════════════════════════════════════════════
// SECTION 8 — VISUAL ARCHITECTURE
// ══════════════════════════════════════════════════════════
children.push(
  h1("8.  Visual Architecture Diagram (Text Representation)"),
  p([R("The following diagram maps the complete GBS-SETHS ecosystem — from the individual participant journey through the franchise architecture to the global network. This representation is designed for clarity in document form; the full interactive visual architecture is available on the live G.O.D.S. platform (capstoneprojectsjs.netlify.app).")]),
  spacer(80),
  shadeBox([
    centered("───────────────────────────────────────────────────────────────────", 18, false, GOLD),
    centered("G B S  G L O B A L   (LAYER 1)", 22, true, N),
    centered("G.O.D.S Holdings (Pty) Ltd + IP Trust · Methodology · Standards · Certification · Royalties", 17, false, GREY),
    centered("─────────────────────┬───────────────────────", 18, false, GOLD),
    centered("NATIONAL GBS  (LAYER 2)", 20, true, AQUA),
    centered("Country Licence · Local Accreditation · Government Interface · DFI Capital", 17, false, GREY),
    centered("──────────┬──────────────────────┬──────────", 18, false, GOLD),
    centered("REGIONAL GBS  (LAYER 3)", 19, true, AQUA),
    centered("Province / Metro Operation · Cohort Management · Employer Partnerships", 17, false, GREY),
    centered("────────┬────────────────────────┬────────", 18, false, GOLD),
    centered("DELIVERY OPERATORS  (LAYER 4)", 18, true, GD),
    centered("Accredited Training Providers · NGOs · TVET Colleges · Corporate Skills Departments", 17, false, GREY),
    centered("────────┬────────────────────────┬────────", 18, false, GOLD),
    centered("THE PARTICIPANT JOURNEY", 20, true, N),
    centered("INTAKE → Phase 1 → Phase 2 → Phase 3 → Phase 4 → Phase 5 → Phase 6 → MENTOR", 18, false, NT),
    centered("(Foundation) (Skills) (Readiness) (Placement) (Alumni) (Never Closes)", 16, false, GREY),
    centered("──────────────────────────────────────────", 18, false, GOLD),
    centered("CET LOOP:  Communicate → Educate → Transfer", 18, true, AQUA),
    centered("CTE LOOP:  Carry → Transfer → Evolve → [Repeat]", 18, true, AQUA),
    centered("──────────────────────────────────────────", 18, false, GOLD),
    centered("EMPLOYER ECOSYSTEMS  (LAYER 5)", 18, true, GD),
    centered("T.S. Industries (primary) · Partner Employers · Co-ops · Government Departments", 17, false, GREY),
    centered("UDOC GOVERNANCE BACKBONE  (VERIFIED AUDIT TRAIL — ALL LAYERS)", 17, true, N),
    centered("M.A.D.I.B.A CAPITAL ENGINE  (OUTCOME-BASED FUNDING DEPLOYMENT)", 17, true, N),
    centered("───────────────────────────────────────────────────────────────────", 18, false, GOLD),
  ], LGF, AQUA),
  pb(),
);

// ══════════════════════════════════════════════════════════
// SECTION 9 — NOTES: BUG & OUTSTANDING ITEMS
// ══════════════════════════════════════════════════════════
children.push(
  h1("9.  System Notes — Open Items & Bug Log"),
  p([R("This section documents open operational items and known bugs relevant to the GBS-SETHS digital infrastructure. Maintained for continuity across development sessions.")]),

  h2("9.1  Known Bug — Pledge Counter Not Updating"),
  shadeBox([
    p([B("Symptom: "), R("The World Pledge form on capstoneprojectsjs.netlify.app receives submissions correctly — backend email notifications and notification receipts fire successfully, confirming the backend pledge API route is functioning. However, the pledge count displayed on the frontend does not update when new pledges are submitted.")]),
    spacer(60),
    p([B("Root cause hypothesis: "), R("The pledge count display is likely either (a) hardcoded in the frontend HTML/JS rather than fetched dynamically from the backend on page load, or (b) the frontend pledge count component is calling the correct API route but failing silently — possibly a CORS issue, an incorrect endpoint URL in the frontend config, or a missing error handler that prevents the displayed number from refreshing. The backend is recording pledges correctly. This is a frontend display issue, not a data integrity issue.")]),
    spacer(60),
    p([B("Next step: "), R("In a future dedicated debugging session — locate the pledge count display element in index.html, confirm whether it calls a backend API route on page load, and if so trace the API call response. If it is hardcoded, replace with a dynamic fetch call to the confirmed backend pledge count endpoint.")]),
  ], "FFF8E1", "C9A84C"),

  h2("9.2  Live Site — Two Minor Fixes Outstanding"),
  makeTable(
    ["Fix", "What", "Status"],
    [
      ["Nova X Quantum™ removal", "Remove from UDOC competitor comparison table on live site. Table is stronger without it. No replacement needed.", "Outstanding — SJS to implement"],
      ["Document count clarification", "Add one line explaining 73 (data room registered docs) vs 103 (total institutional documents including versions). Site shows both numbers on same page with no explanation.", "Outstanding — SJS to implement"],
    ],
    [2800, 4300, 2260]
  ),
  pb(),
);

// ══════════════════════════════════════════════════════════
// SECTION 10 — CLOSING
// ══════════════════════════════════════════════════════════
children.push(
  h1("10.  Closing — What This Document Is and Is Not"),
  shadeBox([
    p([B("This document is: "), R("The first complete institutional articulation of the GBS-SETHS framework — a decade of SJS's original thinking, lived experience, and systematic development, structured into a world-class operational framework suitable for presentation to DFIs, government partners, franchise operators, and international stakeholders.")]),
    spacer(80),
    p([B("This document is not: "), R("A final product. Version 1.0 is the foundation. Every cohort run, every outcome measured, every country entered, and every mentor produced will enrich and evolve the framework. The 250-year mandate means GBS-SETHS will be refined, expanded, and deepened by people who haven't been born yet — building on the foundation SJS laid in 2016.")]),
    spacer(80),
    p([B("On AI assistance: "), R("This framework was documented, structured, and amplified with AI assistance tools. The ideas, the pillars, the methodology, the lived grounding, and the decade of commitment belong entirely to Sashin J. Singh. AI made the work clearer, broader in its documentation, and more capable of reaching the audience it deserves. It did not generate the work. SJS did — and has the 10 years of boxes of notes to prove it.")]),
  ], LGF, AQUA),
  spacer(200),
  hr(),
  spacer(120),
  centered("GBS-SETHS v1.0  ·  G.O.D.S Holdings (Pty) Ltd  ·  IP Trust Protected  ·  July 2026", 17, false, GREY),
  centered("All intellectual property held in the G.O.D.S. IP Trust under the Trust Property Control Act 57 of 1988", 15, false, GREY),
  centered("Founder & Architect: Sashin J. Singh  ·  sashin.singh@outlook.com", 15, false, GREY),
);

// ─── ASSEMBLE DOCUMENT ───────────────────────────────────
const doc = new Document({
  numbering: {
    config: [{
      reference: "bullets",
      levels: [{ level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.LEFT,
        style: { paragraph: { indent: { left: 540, hanging: 270 } } } }],
    }],
  },
  styles: {
    default: { document: { run: { font: FONT, size: 21, color: NT } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 32, bold: true, color: N, font: FONT },
        paragraph: { spacing: { before: 360, after: 200 },
          border: { bottom: { style: BorderStyle.SINGLE, size: 8, color: GOLD, space: 4 } } } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 26, bold: true, color: GD, font: FONT },
        paragraph: { spacing: { before: 280, after: 140 } } },
      { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 22, bold: true, italics: true, color: NT, font: FONT },
        paragraph: { spacing: { before: 200, after: 100 } } },
    ],
  },
  sections: [{
    properties: {
      page: { size: { width: 12240, height: 15840 }, margin: { top: 1260, right: 1440, bottom: 1260, left: 1440 } },
    },
    headers: { default: new Header({ children: [new Paragraph({
      alignment: AlignmentType.RIGHT,
      children: [new TextRun({ text: "GBS-SETHS v1.0  ·  Global Belief System — Systematically Engineered Transfer of Human Systems", size: 15, color: GREY, italics: true, font: FONT })],
    })] }) },
    footers: { default: new Footer({ children: [new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [
        new TextRun({ text: "G.O.D.S Holdings (Pty) Ltd  ·  Confidential  ·  July 2026  ·  Page ", size: 15, color: GREY, font: FONT }),
        new TextRun({ children: [PageNumber.CURRENT], size: 15, color: GREY, font: FONT }),
      ],
    })] }) },
    children,
  }],
});

Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync("/home/claude/GBS_SETHS_Framework_v1.docx", buf);
  console.log("Built. Children: " + children.length);
}).catch(e => { console.error("BUILD ERROR:", e); process.exit(1); });
