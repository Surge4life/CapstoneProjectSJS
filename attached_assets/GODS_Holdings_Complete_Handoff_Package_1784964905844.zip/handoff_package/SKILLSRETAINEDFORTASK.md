# SKILLS RETAINED FOR TASK — G.O.D.S Holdings Build Continuation
Last updated: 01 July 2026
Purpose: Picked up by any new session after usage limit reset to continue builds without re-deriving technical patterns.

---

## ENVIRONMENT FACTS
- OS: Ubuntu 24 (sandbox), /home/claude is writable scratch space, resets between sessions
- /mnt/user-data/outputs = permanent outputs (persists, user can download)
- /mnt/project/ = read-only project files (SJS's uploaded source docs)
- /mnt/user-data/uploads = read-only user uploads this session
- /mnt/skills/public/docx/SKILL.md = docx skill (READ BEFORE ANY .docx build)
- /mnt/skills/public/pptx/SKILL.md = pptx skill (READ BEFORE ANY .pptx build)
- Node.js + npm available globally. docx@9.6.1 and pptxgenjs already installed globally
- python3 + python-docx, pypdf, pillow/PIL, sharp available
- soffice (LibreOffice headless) available for docx→PDF conversion
- pdftoppm available for PDF→image rasterisation (QA checks)
- Network: allowed domains include api.anthropic.com, pypi.org, registry.npmjs.org, raw.githubusercontent.com — NOT gods-platform-core.onrender.com (blocked by robots.txt), NOT github.com repo cloning (no credentials)

## BRAND CONSTANTS (GODS_Brand_Manual_v2.pdf v1.0 March 2026)
```
NAVY     = "060E1C"   // primary background (NO leading #)
NAVY_TEXT= "16233A"   // slightly lighter body text
GOLD     = "C9A84C"   // brand gold
GOLD_DARK= "8C7330"   // darkened gold for text on light backgrounds
GREY     = "5B6472"   // muted/caption text
WHITE    = "FFFFFF"
RED_FLAG = "9B2C2C"   // flag/warning boxes
FONT     = "Arial"
```
Compass mark (clean crop, no white box): /home/claude/compass_mark_raw.png — RE-EXTRACT if sandbox reset:
```python
from PIL import Image
im = Image.open('/mnt/user-data/uploads/g-02_g_o_d_s_logo.jpeg')
crop = im.crop((295, 40, 520, 225))
crop.save('/home/claude/compass_mark_raw.png')
```
Or from project file: /mnt/project/G_O_D_S_LOGO.jpeg (same image, different path).

## DOCX BUILD PATTERN (docx@9.6.1 via Node.js)
```javascript
const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  HeadingLevel, BorderStyle, WidthType, ShadingType, VerticalAlign,
  AlignmentType, LevelFormat, PageNumber, PageBreak, Header, Footer } = require("docx");
```
- Heading styles defined in Document({ styles: { paragraphStyles: [...] } })
- Numbering config in Document({ numbering: { config: [...] } })
- Write: Packer.toBuffer(doc).then(buf => fs.writeFileSync(path, buf))
- Validate: python3 /mnt/skills/public/docx/scripts/office/validate.py file.docx
- Convert to PDF: python3 /mnt/skills/public/docx/scripts/office/soffice.py --headless --convert-to pdf file.docx
- Rasterise for QA: pdftoppm -jpeg -r 130 file.pdf rpage → rpage-01.jpg etc.
- CONTENT_WIDTH = 9360 DXA (Letter, 1in margins)
- All color fields in docx: hex WITHOUT # prefix
- Table column widths: must sum to CONTENT_WIDTH; use makeTable(headers, rows, widths)
- CalloutBox and flagBox: single-cell tables with shaded fill and border

## PPTX BUILD PATTERN (pptxgenjs via Node.js)
```javascript
const pptxgen = require("pptxgenjs");
let pres = new pptxgen(); pres.layout = "LAYOUT_WIDE"; // 13.3 x 7.5
```
- Color fields: hex WITHOUT # prefix in pptxgenjs
- Icon rendering: react-icons SVGs use fill="currentColor" → sharp/librsvg CANNOT resolve currentColor at rasterisation time. Fix:
  ```javascript
  svg = svg.replace(/fill="currentColor"/g, `fill="${svgColor}"`)
           .replace(/stroke="currentColor"/g, `stroke="${svgColor}"`);
  // svgColor MUST have a # prefix for valid SVG: "#E8C97A" not "E8C97A"
  // pptxgenjs image data: "image/png;base64," + buf.toString("base64")
  ```
- QA icons: view the rasterised slide image — invisible icon on dark bg = the above fix wasn't applied
- Repack: python3 /mnt/skills/public/pptx/scripts/rezip.py file.pptx
- Convert: python3 /mnt/skills/public/pptx/scripts/office/soffice.py --headless --convert-to pdf file.pptx

## PYTHON DOCX READING (python-docx)
```python
import docx
d = docx.Document('/mnt/project/some_file.docx')
text = [p.text.strip() for p in d.paragraphs if p.text.strip()]
tables = [[[ c.text.strip() for c in row.cells ] for row in t.rows] for t in d.tables]
```

## HTML STRIPPING FROM NETLIFY DOCS
```python
import re, html
def strip_tags(s):
    s = re.sub(r'<script.*?</script>', '', s, flags=re.S)
    s = re.sub(r'<style.*?</style>', '', s, flags=re.S)
    s = re.sub(r'<[^>]+>', ' ', s)
    s = html.unescape(s)
    s = re.sub(r'[ \t]+', ' ', s)
    s = re.sub(r'\n\s*\n+', '\n\n', s)
    return s.strip()
```

## LIVE SITE & BACKEND
- Frontend: https://capstoneprojectsjs.netlify.app/ — fetchable, returns full HTML
- Backend: https://gods-platform-core.onrender.com — blocked by robots.txt from Claude fetch
- Backend is CONFIRMED LIVE (72 routes, Render, Neon Postgres) per Sashin's direct confirmation 30 June 2026
- Capstone Live tab on frontend shows API routes and working UIs
- GitHub: Surge4life/CapstoneProjectSJS (private, no sandbox access — SJS pushes himself)

## KEY DOCUMENT LOCATIONS (project files, read-only)
- /mnt/project/MEMORY.md — may be stale (use /mnt/user-data/outputs/MEMORY.md as authoritative)
- /mnt/project/GODS_DataRoom_Reference.md — may be stale
- /mnt/project/e-01_gods_seths_complete_program.docx — v1.0 March 2026 (SJS says he updated it but it has NOT synced — ask him to resend before working from it)
- /mnt/project/GODS_vs_The_World_Complete_Four_Division_Assessment.docx — OLD version (UDOC-only); the new four-division version is in /mnt/user-data/outputs/
- /mnt/user-data/uploads/ — session uploads (reset on new session — SJS must re-upload)

## NETLIFY ZIP EXTRACTED LOCATION (sandbox, may not persist to next session)
- /home/claude/netlify_inspect/ — extracted NETLIFY_DEPLOY_website.zip
- /home/claude/netlify_inspect/docs/ — 73-document data room HTML + docx files
- If gone: re-extract from /mnt/user-data/uploads/NETLIFY_DEPLOY_website.zip (if still in uploads)
- index.html is the live site deployment HTML (may differ from current live site)

## BUILD HELPERS (may not persist to next session — recreate if needed)
- /home/claude/helpers.js — shared docx brand constants + helper functions
- /home/claude/content_p1.js through content_p4.js — report content sections
- /home/claude/build_main.js — report assembly + Packer call
- /home/claude/compass_mark_raw.png — cropped brand compass mark

## RENDER INTEGRATION RULES (per SJS standing instruction)
- All code/scripts for backend must be production-grade and deployable to Render without credential changes
- SJS handles the actual push to GitHub + Render deploy — Claude produces the files
- FastAPI (Python 3.12) is the confirmed backend stack
- Never build mock/stub API endpoints — only real, functional routes
- If a backend change is needed, produce a complete file (not a diff) unless the file is >200 lines, in which case produce a targeted diff with exact line numbers

## HONESTY DISCIPLINE (non-negotiable, from the report standard)
- Every market figure needs a named source and a date
- Separate three tiers explicitly: proven/live | production-designed/emulated | aspirational
- Never claim virality, guaranteed reach, or engineered outcomes for content
- If two G.O.D.S documents conflict, say so explicitly rather than picking one quietly
- Do not fabricate competitor names, funding figures, or market sizes to fill gaps

## MULTI-SESSION TASK MANAGEMENT
1. Before any large task: create/update MEMORYRETAINEDFORTASK.md (what state we're in) and this file (SKILLSRETAINEDFORTASK.md)
2. At natural break points (before usage warning): update both files, present any completed deliverables
3. On session resume: read both files first, confirm with SJS what was truncated before continuing
4. If sandbox has reset and files are gone from /home/claude: rebuild from /mnt/user-data/outputs/ and /mnt/project/ — both persist
5. If SJS says "continue" without a specific task: check MEMORYRETAINEDFORTASK.md for the in-flight task before asking
