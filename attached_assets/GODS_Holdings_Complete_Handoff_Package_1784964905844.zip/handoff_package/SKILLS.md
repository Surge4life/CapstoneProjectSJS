# G.O.D.S. Holdings — Master Skills & Working Patterns
**Version:** Final handoff — July 2026
**Purpose:** Technical build patterns, brand constants, environment facts, and working principles for seamless session continuation. Read alongside MEMORY.md on any new session.

---

## ENVIRONMENT

| Item | Value |
|---|---|
| OS | Ubuntu 24 (sandbox) — resets between sessions |
| Permanent outputs | /mnt/user-data/outputs/ |
| Project files (read-only) | /mnt/project/ |
| Session uploads (read-only) | /mnt/user-data/uploads/ |
| Skills reference (read-only) | /mnt/skills/public/ |
| Node.js | v22+ available globally |
| Python | 3.12 available; pip install uses --break-system-packages |
| docx (Node) | docx@9.6.1 — globally installed |
| pptxgenjs (Node) | globally installed |
| react-icons | globally installed |
| sharp | globally installed |
| LibreOffice headless | soffice — available for docx→PDF conversion |
| pdftoppm | available for PDF→JPG rasterisation (QA checks) |
| python-docx | installed (pip install python-docx --break-system-packages) |
| Network | Allowed: npmjs.org, pypi.org, api.anthropic.com, raw.githubusercontent.com |
| Network | BLOCKED: gods-platform-core.onrender.com (robots.txt) |
| ALWAYS read skill before building | /mnt/skills/public/docx/SKILL.md, /mnt/skills/public/pptx/SKILL.md |

---

## BRAND CONSTANTS

```javascript
// pptxgenjs and docx — hex WITHOUT # prefix
const N    = "060E1C";  // Navy (primary background)
const NT   = "16233A";  // Navy-text (body text, slightly lighter)
const GOLD = "C9A84C";  // Brand gold (primary accent)
const GD   = "8C7330";  // Gold-dark (text on light backgrounds)
const GREY = "5B6472";  // Muted / caption text
const AQUA = "1A6B6B";  // S.E.T.H.S. division accent (teal)
const WH   = "FFFFFF";  // White
const RED  = "9B2C2C";  // Flag/warning colour
const LYF  = "F7F1E0";  // Light gold fill (callout boxes)
const LGF  = "E8F4F1";  // Light green fill (S.E.T.H.S. boxes)
const LBF  = "F2F3F5";  // Light grey fill (table alternating rows)
const CW   = 9360;      // Content width in DXA (Letter paper, 1in margins)
```

```css
/* Web / HTML equivalents */
--navy: #060E1C;
--gold: #C9A84C;
--grey: #5B6472;
--aqua: #1A6B6B;
```

**Typography:** Arial (in documents — Cormorant Garamond/Barlow Condensed on web)
**Lockup minimums:** Full lockup 180px · mark+name 120px · stacked 80px · mark-only 32px
**Never:** glow, bevel, drop shadow, distort, recolour, crop the compass mark

---

## DOCX BUILD PATTERN (Node.js, docx@9.6.1)

### Imports
```javascript
const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  Header, Footer, AlignmentType, LevelFormat, HeadingLevel,
  BorderStyle, WidthType, ShadingType, VerticalAlign,
  PageNumber, PageBreak, ImageRun } = require("docx");
```

### Essential Helpers (always define these)
```javascript
const sp = (h=100) => new Paragraph({ spacing:{after:h}, children:[] });
const pb = () => new Paragraph({ children:[new PageBreak()] });
const hr = (c="C9A84C",sz=6) => new Paragraph({
  spacing:{before:100,after:100},
  border:{bottom:{style:BorderStyle.SINGLE,size:sz,color:c}},
  children:[]
});
const R = (t,o={}) => new TextRun({text:t,font:"Arial",size:21,...o});
const B = (t,o={}) => new TextRun({text:t,font:"Arial",size:21,bold:true,...o});
```

### Heading Styles (in Document config)
```javascript
paragraphStyles:[
  {id:"Heading1", name:"Heading 1", run:{size:32,bold:true,color:"060E1C",font:"Arial"},
   paragraph:{spacing:{before:360,after:200}, border:{bottom:{style:BorderStyle.SINGLE,size:8,color:"C9A84C",space:4}}}},
  {id:"Heading2", name:"Heading 2", run:{size:26,bold:true,color:"8C7330",font:"Arial"},
   paragraph:{spacing:{before:280,after:140}}},
  {id:"Heading3", name:"Heading 3", run:{size:22,bold:true,italics:true,color:"16233A",font:"Arial"},
   paragraph:{spacing:{before:200,after:100}}},
]
```

### Headers/Footers (CRITICAL — bracket order is exact, don't deviate)
```javascript
headers:{default:new Header({children:[new Paragraph({
  alignment:AlignmentType.RIGHT,
  children:[new TextRun({text:"Header text here",size:15,color:"5B6472",italics:true,font:"Arial"})]
})]})},
footers:{default:new Footer({children:[new Paragraph({
  alignment:AlignmentType.CENTER,
  children:[
    new TextRun({text:"Footer text here  ·  Page ",size:15,color:"5B6472",font:"Arial"}),
    new TextRun({children:[PageNumber.CURRENT],size:15,color:"5B6472",font:"Arial"})
  ]
})]})},
```
**⚠️ KNOWN GOTCHA:** Headers/footers use `headers:{default:...}` NOT `headers:{default:...})` — the stray `)` will break the build with "Unexpected token ']'" at the sections array close. Always count: `{default: new Header({children:[...]})}` = the `}` closes `headers:{}`, no extra `)`.

### Shaded Box Helper
```javascript
function box(lines, fill="F7F1E0", bc="C9A84C"){
  return new Table({
    width:{size:9360,type:WidthType.DXA}, columnWidths:[9360],
    rows:[new TableRow({children:[new TableCell({
      shading:{fill,type:ShadingType.CLEAR},
      borders:Object.fromEntries(["top","bottom","left","right"].map(s=>[s,{style:BorderStyle.SINGLE,size:4,color:bc}])),
      margins:{top:160,bottom:160,left:220,right:220},
      children:lines
    })]})]
  });
}
```

### Build + Validate + Convert
```bash
node build_script.js                     # Build
python3 /mnt/skills/public/docx/scripts/office/validate.py output.docx
python3 /mnt/skills/public/docx/scripts/office/soffice.py --headless --convert-to pdf output.docx
pdftoppm -jpeg -r 130 output.pdf prefix   # → prefix-01.jpg, prefix-02.jpg...
# Visual QA key pages before copying to /mnt/user-data/outputs/
```

---

## PPTX BUILD PATTERN (pptxgenjs)

```javascript
const pptxgen = require("pptxgenjs");
let pres = new pptxgen();
pres.layout = "LAYOUT_WIDE"; // 13.3 x 7.5 inches
```

**Color fields in pptxgenjs:** hex WITHOUT # prefix (same as docx)

### ⚠️ CRITICAL: react-icons + sharp color fix
react-icons SVGs output `fill="currentColor"` resolved via a `style="color:..."` attribute. `sharp`/`librsvg` does NOT resolve CSS `currentColor` when rasterizing standalone SVGs. Fix:
```javascript
async function iconToBase64Png(IconComponent, color, size=256){
  const svgColor = color.startsWith("#") ? color : `#${color}`; // SVG needs # prefix
  let svg = ReactDOMServer.renderToStaticMarkup(
    React.createElement(IconComponent, { color:svgColor, size:String(size) })
  );
  // Bake hex directly into fill/stroke — currentColor won't resolve
  svg = svg.replace(/fill="currentColor"/g, `fill="${svgColor}"`)
           .replace(/stroke="currentColor"/g, `stroke="${svgColor}"`);
  const pngBuffer = await sharp(Buffer.from(svg)).png().toBuffer();
  return "image/png;base64," + pngBuffer.toString("base64");
}
// NOTE: pptxgenjs image data format: "image/png;base64," + base64string
// NOTE: pptxgenjs color fields use hex WITHOUT # prefix
// NOTE: SVG fill/stroke use hex WITH # prefix — these are DIFFERENT constants
```

---

## PYTHON PATTERNS

### Reading .docx files in project
```python
import docx
# Many "docx" files in /mnt/project/ are actually UTF-8 text/JSON, not real docx
# Always check: file "/mnt/project/e-01_gods_seths_complete_program.docx"
# If "Unicode text, UTF-8" → cat or open() directly
# If "Zip archive data" → use python-docx

d = docx.Document('/mnt/project/some_file.docx')
text = [p.text.strip() for p in d.paragraphs if p.text.strip()]
tables = [[[c.text.strip() for c in row.cells] for row in t.rows] for t in d.tables]
```

### HTML stripping
```python
import re, html
def strip_tags(s):
    s = re.sub(r'<script.*?</script>', '', s, flags=re.S)
    s = re.sub(r'<style.*?</style>', '', s, flags=re.S)
    s = re.sub(r'<[^>]+>', ' ', s)
    s = html.unescape(s)
    s = re.sub(r'[ \t]+', ' ', s)
    s = re.sub(r'\n\s*\n+', '\n\n', s)
    return s.strip()
```

---

## LIVE SITE ARCHITECTURE

| Item | Value |
|---|---|
| Frontend URL | https://capstoneprojectsjs.netlify.app/ |
| Frontend file | Single-file index.html (~6,100 lines, 1.75MB, vanilla JS/JSON/DOM) |
| Backend URL | https://gods-platform-core.onrender.com |
| Backend status | CONFIRMED LIVE (72 routes, FastAPI/Python 3.12, Neon Postgres, Render) |
| Android | APK compiled and installed on device |
| GitHub | Surge4life/CapstoneProjectSJS (private — SJS pushes; no sandbox access) |

**⚠️ Live site editing:** SJS cannot "copy-paste into Netlify" — the site is a single large script where text is embedded in JS variables, template literals, and JSON data objects. All live site edits require providing exact before/after text with enough surrounding context to locate in the file safely. Never assume a simple find-replace is safe.

---

## NETLIFY DEPLOY ZIP (uploaded this chat)

Location in uploads: `/mnt/user-data/uploads/NETLIFY_DEPLOY_website.zip`
Extract: `unzip -o -q NETLIFY_DEPLOY_website.zip -d /home/claude/netlify_inspect/`

Key contents:
- `index.html` — the full live site (single file)
- `docs/` — 73-document data room HTML + docx files
- `capstone-source/gods/gods-platform.js` — platform JS
- `capstone-source/eva/eva-engine-complete.js` — EVA engine
- `capstone-source/udoc/udoc-orchestrator.js` — UDOC orchestrator
- `netlify/functions/get-pledge-count.js` — pledge count serverless function

**Important:** The zip snapshot may differ from the CURRENT live site. Fetch the live URL directly for current state rather than relying on the zip for "what's live now."

---

## RESEARCH AND MARKET DATA PATTERNS

### Hierarchy for market sizing
1. Pull the most current official stats first — quarter-specific (Stats SA QLFS), not last year's headline number
2. Find 2–4 named, operating direct comparables before citing aggregate market-size ranges
3. Separate grant/non-profit-funded competitors from VC-funded ones — different capital markets
4. If a division can't be sized (vague category), say so and ask rather than inventing a number

### Key authoritative sources for G.O.D.S. context
- Stats SA (statssa.gov.za) — Q1 QLFS for unemployment figures — CONFIRM QUARTERLY
- REIPPPP official (gov.za) — for T.S. Industries energy market context
- PIC (pic.gov.za) — R2.69 trillion AUM, April 2026 TVET paper
- DBSA Ifisa — active April 2026, private infrastructure mobilisation
- Ninety One EAAIF — $3bn+, 125 projects, A2 Moody's rated
- WEF Future of Jobs — automation displacement projections
- IMD workplace trends 2026 — trades insulation from AI

---

## MULTI-SESSION TASK MANAGEMENT

### Before any large task
1. Create/update MEMORYRETAINEDFORTASK.md (what state we're in, what's in-flight)
2. Update SKILLSRETAINEDFORTASK.md (technical patterns for the specific build)
3. Present any completed deliverables before starting the next phase

### On session resume (after usage reset)
1. Read MEMORYRETAINEDFORTASK.md FIRST — confirms what was in progress
2. Read SKILLSRETAINEDFORTASK.md — confirms the technical approach
3. Confirm with SJS what was truncated before consuming usage on the wrong continuation
4. If sandbox has reset (files gone from /home/claude/): rebuild from /mnt/user-data/outputs/ and /mnt/project/ — both persist

### "Continue" rule
When SJS sends "Continue" after a usage reset:
- It means: resume the task in progress from where it was cut off
- Read MEMORYRETAINEDFORTASK.md to determine exact state
- Do NOT restart from scratch or ask SJS to re-explain
- Do NOT fabricate completion of steps that weren't actually done

### Fabrication prohibition
NEVER fabricate deliverables to appear complete. If a sandbox reset wiped a build in progress, say so plainly and ask for the continuation files or confirm the approach before rebuilding. The cost of honesty (one message clarifying) is always lower than the cost of a fabricated deliverable SJS has to reject.

---

## HONESTY DISCIPLINE (SJS's stated non-negotiable)

- Every market figure needs a named source and a date
- Separate three tiers in every document: **proven/live** | **designed/emulated** | **aspirational/future**
- If two G.O.D.S. documents conflict, say so explicitly — never quietly pick one
- Never claim virality, guaranteed reach, or "world leaders will debate this" outcomes
- All AI assistance is documentation and amplification — the ideas, architecture, and decade of work are SJS's. Every deliverable must make this clear.

---

## AUTHORSHIP CLARITY (NB from SJS — non-negotiable)

SJS stated explicitly: "I don't want people thinking I just had a few ideas and over time AI actually made it what it is currently. I earned my recognition due just deserved receipt for this project that AI assisted tool usage clearly just made the work clearer and capable to be massive audience penetration."

Every document must:
- Credit SJS as architect, originator, and decade-long developer
- Frame AI as the documentation/amplification tool — not the idea generator
- Record the 2016 origin (Seth's Empire) as the founding concept predating all AI tool use

---

## COMMON BUILD ERRORS ENCOUNTERED (avoid repeating)

| Error | Cause | Fix |
|---|---|---|
| "Unexpected token ']'" at sections close | Stray `)` in headers/footers line | Count: `{default: new Header({...})}` — no extra `)` after the headers property object |
| react-icons icons black/invisible on dark background | `currentColor` not resolved by sharp/librsvg | See icon color fix above — bake hex directly, SVG needs `#` prefix |
| docx "file in use" or corrupted output | rezip.py not called after build | Run `python3 /mnt/skills/public/docx/scripts/office/rezip.py output.docx` before conversion |
| Grep returns entire file content | File is JSON-like, single-line format | Use Python script with line-by-line parsing instead of grep |
| "Unicode text UTF-8" when opening .docx | File is actually text/JSON not real docx | Use `cat` or `open()` directly, not `docx.Document()` |
