# G.O.D.S. Holdings — 9-Month Traction & Marketing Plan
**Period:** July 2026 → March 2027 (Capstone Submission)
**Architect:** Sashin J. Singh | **Compiled:** July 2026

---

## Governing Principles

1. **Marketing is currently PAUSED** — per SJS's explicit instruction. No external push until he personally confirms the S.E.T.H.S. framework is at his vision level. This plan activates when he says go.
2. **Honesty is the moat.** Every piece of external communication must separate proven/live (UDOC backend, 72 routes, Android build) from designed/planned (T.S. 7 subsidiaries, M.A.D.I.B.A. FSP licence). Overclaiming destroys the credibility the investor report and GBS-SETHS framework were built on.
3. **Two valid outcomes:** G.O.D.S. traction AND a permanent job are both fully valid results of this 9 months. Marketing serves both — building visibility for G.O.D.S. while simultaneously making SJS more employable as a systems architect/software developer.
4. **Resources are constrained.** Everything here is free, time-intensive rather than capital-intensive, and executable solo. Nothing here requires funding first.

---

## Month 1–2: July–August 2026 — Activate the Ready Work

### Priority 1: Post the LinkedIn Carousel (cleared to post)
The 8-slide deck (GODS_LinkedIn_Carousel.pptx) is built, validated, and ready. Upload directly to LinkedIn as a document post — it renders as a swipeable carousel. The backend is confirmed live so the deck is accurate as-is.

**Post with this caption (final version — confirm before posting):**
> Most of AI is built to give better answers. This was built to ask what happens next.
> Link to live system in the comments. Thoughts? ↓

**Timing:** Post Tuesday or Wednesday morning (SA time), 8–10am — peak LinkedIn engagement windows.

### Priority 2: Fix the Live Site Before Press Goes Out
These four fixes take less than 30 minutes total and must happen before any journalist or investor sees the site:
1. Replace UDOC "No code written" copy with confirmed live build language
2. Remove Nova X Quantum™ from competitor table
3. Standardise unemployment stats (32.7% official / 60.9% youth)
4. Add document count clarification (73 registered / 103 total)

### Priority 3: Send the Press Pitches (drafts ready in this chat)
- VentureBurn (tips@ventureburn.com — verify current address)
- Disrupt Africa (editor@disrupt-africa.com — verify)
- TechCentral (news@techcentral.co.za — verify)

All three drafts are complete. The angle: a decade-long personal project, a published memoir, and a working AI-governance system — one SA founder's capstone. Send individually, not bulk. Follow up after 10 business days if no response.

### Priority 4: Begin DFI Relationship Initiation (doesn't require funding yet)
All three outreach drafts are ready:
- **DBSA** — Social Infrastructure/Digital Transformation desk (dbsa.org → contact)
- **IDC** — Agro-processing/Digital Economy/Social Impact desk (idc.co.za → contact)
- **City of Johannesburg** — Economic Development MMC

Ask for a 20-minute exploratory call, not funding. "I want to understand your process before submitting anything formal." This is what your own D-02 GTM Strategy document says to do in Month 1–3 — it doesn't require capital in hand.

### LinkedIn Content: Month 1–2
Post 1 (carousel — already described above)
Post 2 (S.E.T.H.S. Pillar post): Pick one of the five foundational pillars and explain it with the lived context — Tolerance ("belief must be self-motivated, one person's truth cannot be imposed on another as fact") + the AI displacement angle
Post 3 (stat post): SA Q1 2026 — 60.9% youth unemployment — the problem S.E.T.H.S. is built to solve

---

## Month 3–4: September–October 2026 — Compete and Connect

### GEC+Africa Regional Pitch Competition
SJS is registered on the Innovation Bridge portal. No current deadline. This is the priority competition — pre-seed/MVP eligible, explicitly not requiring revenue, run by GEN South Africa and SEDA. Cape Town showcase is typically September.

**When deadline is confirmed**, build the application from existing data room materials:
- Pitch deck: UDOC_Pitch_Deck_v9_3.pdf (already exists)
- Business case: C-04/C-06 investment memos (already in data room)
- Problem/value prop: Use the G.O.D.S. vs The World document executive summary
- Financial model: C-02 5-year model (already exists)
- Team: Founder biography + the World Pledge as proof of interest

### DFI Follow-up
If DBSA/IDC/CoJ responded in Month 1–2 → schedule the calls and prepare for them using the G.O.D.S. vs The World competitive assessment as the briefing document.

### LinkedIn Content: Month 3–4
Post 4 (build update): "Here's what's actually live vs. what we're building toward" — the honesty post that sets you apart from every deck-only startup
Post 5 (S.E.T.H.S. pillar 2): Belief Systems pillar + GBS-SETHS as the General Belief System that builds on what connects people rather than what divides them
Post 6 (AI displacement angle): The IMD/WEF data on trades insulation — the macro tailwind that makes S.E.T.H.S. exactly right for 2026

---

## Month 5–6: November–December 2026 — Revenue Milestone Target

### develoPPP Ventures December 2026 Cycle
**Requirements to be eligible:** Initial revenue generated + €100K private investment matched. December call is realistic IF:
- At least one paying UDOC client OR one paid S.E.T.H.S. pilot placement exists
- Any angel investment commitment (even small — the €100K matching is the gate, not a minimum investment size)

**Path to a December application:** City of Joburg pilot conversation in Month 3–4 → formal pilot agreement in Month 5 → this qualifies as "initial revenue generated"

### Terraco Contract Decision (December 2026)
The current contract ends December 2026. Extended by 6 months to ~June 2027. By December, SJS will know whether: (a) absorption into Terraco is on the table (likely no based on current signals), (b) Progression has another placement, (c) G.O.D.S. has traction that creates alternative income. Plan for all three scenarios.

### LinkedIn Content: Month 5–6
Post 7 (milestone reactive): Post only if something real has happened — GEC+Africa acceptance, DFI response, pilot agreement
Post 8 (GBS-SETHS launch frame): "Here's the framework I've been building for a decade — and why it's finally the right time for it" — the AI displacement + Freedom Charter + 250-year mandate narrative

---

## Month 7–8: January–February 2027 — Capstone Build Final Stretch

### Capstone Submission Preparation
The qualification submission is the primary obligation for these two months. Everything else supports or aligns with it.

**UDOC as capstone evidence:**
- 72 live backend routes (documented)
- Sealed governance decisions in production
- Android APK installed and functional
- GBS-SETHS framework as the business architecture the system serves
- The G.O.D.S. vs The World competitive assessment as market context
- The institutional documentation package (103 documents) as proof of scope

**The press pitch "qualification complete" angle:** In January/February, update the press pitch to include "completing a Software Developer qualification while building a working AI-governance system" — it's a more complete story than what was pitched in Month 1.

### LinkedIn Content: Month 7–8
Post 9 (qualification angle): "I'm finishing a software developer qualification. My capstone project is a working AI governance platform. Here's what I learned about building while studying."
Post 10 (the S.E.T.H.S. decade): The origin story — 2016, Seth's Empire, the decade of boxes of handwritten notes, the book, and where it's arrived

---

## Month 9: March 2027 — Capstone Submission and New Chapter

### Submit and Celebrate What Was Built
The qualification submission marks the close of this phase. Regardless of G.O.D.S. traction, SJS will have:
- Two NQF qualifications completed
- A working AI-governance backend with 72 live routes
- A 38-page world-class institutional framework for GBS-SETHS
- An 18-page investor-grade competitive assessment
- A published memoir
- 103+ institutional documents
- An Android application
- A live website with a pledge system
- Outreach in flight to DFIs, government, and press

**The press pitch evolves:** "SA software developer completes qualification while building Africa's first constitutionally-governed AI platform" — this is the headline for the March press push.

### LinkedIn: Month 9 (milestone post)
"The qualification is submitted. The system is live. The framework is built. What's next?" — open-ended, invites the network in.

---

## Competition Pipeline Summary

| Competition | Status | Deadline | Eligibility | Action |
|---|---|---|---|---|
| GEC+Africa (GEN SA + SEDA) | Registered | Not yet showing | Pre-seed, MVP required (✅ UDOC live) | Monitor Innovation Bridge portal — build application when deadline confirmed |
| develoPPP Ventures | Target Dec 2026 | Dec 2026 | Requires initial revenue + €100K matched investment | Not viable now. Target Dec cycle after pilot revenue |
| Pitch Africa | Watch | Unknown | Varies | Monitor pitchafrica.com for 2026/27 call |
| SEDA Innovation Awards | Watch | Unknown | SA-based, early-stage | Monitor seda.org.za |

---

## LinkedIn Content Calendar — Full 4-Pillar Framework

Rotate across four pillar types, ~1 post per 1–2 weeks:

| Pillar | What it is | Example |
|---|---|---|
| The Stat | Opens with a sourced, dated number — the problem is real and now | "60.9%. Youth unemployment ages 15–24, SA, Q1 2026. Not a forecast." |
| The Build | Proof-of-life — honest about what's live vs. planned | "Here's what's actually deployed today, and what's still on the roadmap." |
| The Pillar | One S.E.T.H.S. or GBS pillar, explained with personal context | "S.E.T.H.S. Pillar I: Honesty. Here's why this isn't just a value — it's a commercial mechanism." |
| The Milestone | Reactive — only when something real happens | "The GEC+Africa shortlist is out. We're on it." |

**Do not pre-write posts for things that haven't happened.** Write each post when the moment is right. The carousel is the exception — it's already done and cleared to post.

---

## Outreach Tracking Template (copy to a spreadsheet)

| Target | Type | Draft Ready | Sent Date | Response | Follow-up Date | Status |
|---|---|---|---|---|---|---|
| VentureBurn | Press | ✅ | | | | Pending |
| Disrupt Africa | Press | ✅ | | | | Pending |
| TechCentral | Press | ✅ | | | | Pending |
| DBSA | DFI | ✅ | | | | Pending |
| IDC | DFI | ✅ | | | | Pending |
| City of Joburg | Government | ✅ | | | | Pending |
| GEC+Africa | Competition | In progress | | | | Registered, deadline pending |
